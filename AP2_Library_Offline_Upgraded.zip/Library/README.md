---
title: AP2 Library (Offline)
tags: []
priority: P2
exam_relevance: mittel
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: pruefung
---
# AP2 Library (Offline)

## Was ist das?
Diese Library ist fuer eine Offline-KI/RAG gedacht (z.B. Raspberry Pi 5). Sie enthaelt kurze, saubere Lernnotizen fuer die AP2 (IT-System-Elektroniker, Fokus Netzwerktechnik + Elektrotechnik).

## Wie sind die Notizen aufgebaut?
- Jede Datei startet mit YAML-Frontmatter (Metadaten: subject, tags, level, priority, exam_relevance, source, source_path, updated).
- Danach folgen mehrere kurze Abschnitte (Chunks) mit Ueberschriften.

## Was bedeuten die "Wiki-Links"?
Du siehst Links wie:
- [[subnetting-ipv4|Subnetting IPv4]]

Das ist ein simples Link-Format (z.B. aus Obsidian/Wikis):
- Links-Ziel: "subnetting-ipv4" (Dateiname ohne .md)
- Anzeigename: "Subnetting IPv4" (nur fuer Lesbarkeit)

Wenn du kein Tool nutzt, das Wiki-Links versteht, kannst du sie einfach als Text ignorieren.
Fuer RAG sind sie trotzdem praktisch, weil sie Zusammenhaenge zwischen Themen markieren.

## Einstiegspunkte
- [[map-themen|Map: Themenuebersicht]]
- [[glossary|Glossary (alle Notizen)]]
- [[tags|Tags Index]]

## Hinweis zu den Quellen
Die Notizen sind keine 1:1 Kopien von Pruefungen. Bei Altklausuren gibt es nur "Musteranalysen" (Themen/Skill-Fokus). Original-Dateien bleiben im Quellpaket.


## Kontext & Grundlagen (Voraussetzungen)
- (Ergaenzen: kurz und pruefungsnah)


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Typische Fehler & Stolperfallen
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
