---
title: External Reference Map
tags:
- external
- reference
- map
priority: P2
exam_relevance: mittel
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: map
topic_area: pruefung
---
## Kontext & Grundlagen (Voraussetzungen)
Diese Map ist eine reine Referenzliste (Keywords -> Quelle). Kein Volltext.

## Pruefungsnahe Anwendung
Wenn ein Begriff fehlt, kann die Offline-KI hier Kandidaten finden und (wenn lokal vorhanden) nachschlagen.

## Typische Fehler & Stolperfallen
- Verlassen auf externe Quellen statt die eigene kuratierte Notiz zu verbessern.
- Lizenzstatus ignorieren.

## Mini-Beispiel
Keyword: "Ohmsches Gesetz" -> Quelle: Wikipedia (CC BY-SA) -> nur als Referenz/Importplan.

## Reference Entries (Beispiele)
- Keyword: "Kabelkennzeichnung NYM" | Source: Wikipedia/Norminfo (license: unknown) | Action: review
- Keyword: "U/UTP Schirmung" | Source: ISO/IEC Overview (license: unknown) | Action: review
- Keyword: "DHCP" | Source: RFC Overview (license: unknown) | Action: metadata only
