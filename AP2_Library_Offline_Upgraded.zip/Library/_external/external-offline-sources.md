---
title: External Offline Sources (Plan)
tags:
- external
- license
- plan
priority: P2
exam_relevance: mittel
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: map
topic_area: pruefung
---
## Kontext & Grundlagen (Voraussetzungen)
Externe Inhalte koennen als Fallback helfen, wenn die kuratierte Library etwas nicht enthaelt. Wichtig: Lizenz/Urheberrecht.

## Pruefungsnahe Anwendung
Offline-RAG Prioritaet:
1) /Library/ (kuratiert)
2) /Library/_templates/ und /Library/_questionbank/
3) /Library/_external/ (nur lizenzsaubere Referenzen)

## Typische Fehler & Stolperfallen
- Volltextimport aus kommerziellen Seiten ohne klare Lizenz.
- Attribution vergessen (CC BY-SA benoetigt Nennung und Hinweis auf Lizenz).

## Mini-Beispiel
Wikipedia (CC BY-SA) darf genutzt werden, aber nur mit Attribution und sauberem Importprozess.

## Regeln (kurz)
- Erlaubt: CC BY-SA, public domain, echte OER.
- Unklar: license unknown -> nur Metadaten/Keywords, kein Volltext.
