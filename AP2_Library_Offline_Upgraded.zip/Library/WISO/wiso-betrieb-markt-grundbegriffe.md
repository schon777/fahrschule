---
title: 'WISO: Betrieb & Markt - Grundbegriffe (Kosten, Umsatz, Gewinn, Unternehmensformen)'
tags:
- wiso
- bwl
- kosten
- umsatz
- gewinn
- unternehmensformen
priority: P2+P3
exam_relevance: mittel
sources:
- internal:Altklausur-implizit
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: wiso
---
## Kontext & Grundlagen (Voraussetzungen)
WISO-Aufgaben drehen sich oft um einfache BWL-Logik, Rechnen mit Prozenten und Begriffe rund um Betrieb/Markt. Konkrete Zahlen variieren je nach Klausur.

## Grundbegriffe
- **Umsatz** = Preis x Menge (Erloese)
- **Kosten** = Ressourcenverbrauch (z.B. Material, Personal)
- **Gewinn** = Umsatz - Kosten

## Kostenarten (grob)
- Fixkosten (z.B. Miete)
- Variable Kosten (z.B. Material pro Stueck)

## Unternehmensformen (Kurz)
- Einzelunternehmen
- Personengesellschaften (z.B. GbR, OHG, KG)
- Kapitalgesellschaften (z.B. GmbH, AG)
In Pruefungen zaehlt meist: Haftung, Kapital, Entscheidungstraeger (Grundidee).

## Typische Fehler & Stolperfallen
- Umsatz mit Gewinn gleichsetzen.
- Prozentrechnung ohne Einheit/Plausibilitaet.

## Siehe auch
- [[wiso-arbeitsrecht-sozialversicherung|Arbeitsrecht & Sozialversicherung]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
