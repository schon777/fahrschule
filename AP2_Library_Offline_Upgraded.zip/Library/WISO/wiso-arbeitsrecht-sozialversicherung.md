---
title: 'WISO: Arbeitsrecht & Sozialversicherung - pruefungsnaher Ueberblick'
tags:
- wiso
- arbeitsrecht
- sozialversicherung
- ausbildung
- ap2
priority: P2+P3
exam_relevance: mittel
sources:
- internal:Altklausur-implizit
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: wiso
---
## Kontext & Grundlagen (Voraussetzungen)
In PoWi/WISO-Aufgaben geht es haeufig um Rechte/Pflichten, Vertraege, Sozialversicherung und betriebliche Mitbestimmung. Konkrete Paragraphen werden selten auswendig verlangt, aber Begriffe und Logik schon.

## Arbeitsvertrag & Ausbildung (Kernpunkte)
- Inhalte: Taetigkeit, Verguetung, Arbeitszeit, Urlaub, Kuendigungsfristen (je nach Kontext).
- Pflichten Arbeitnehmer/Azubi: Sorgfalt, Weisungen, Berichtsheft, Verschwiegenheit.
- Pflichten Arbeitgeber: Ausbildung ermoeglichen, Verguetung zahlen, Arbeitsschutz.

## Mitbestimmung (Kurz)
- Betriebsrat: Interessenvertretung, Mitbestimmung in bestimmten Bereichen.
- Tarifvertrag: regelt z.B. Loehne/Arbeitsbedingungen fuer Tarifgebundene.

## Sozialversicherung (5 Saeulen)
- Kranken-, Pflege-, Renten-, Arbeitslosen-, Unfallversicherung  
Merksatz: *Unfallversicherung traegt der Arbeitgeber.*

## Typische Fehler & Stolperfallen
- Begriffe Tarifvertrag" vs. Betriebsvereinbarung" verwechseln.
- Unfallversicherung falsch zuordnen.

## Siehe auch
- [[wiso-betrieb-markt-grundbegriffe|Betrieb & Markt]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
