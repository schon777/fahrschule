---
title: Questionbank (Mehrfachangabe)
tags:
- questionbank
- map
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: map
topic_area: pruefung
---
## Kontext & Grundlagen (Voraussetzungen)
Diese Questionbank dient zum Wiederholen in Mehrfachangabe-Form (mehrere Antworten koennen korrekt sein).

## Pruefungsnahe Anwendung
Wichtig: Optionen niemals "richtig" markieren. Loesung immer als Klartext separat lesen.

## Typische Fehler & Stolperfallen
- Zu schnell raten ohne Begruendung.
- Einzelfallwissen statt Grundprinzip.

## Mini-Beispiel
Frage zu VLAN: erst Layer2/L3 trennen, dann Antwort waehlen.

## Bereiche
- Netzwerk: Ordner /_questionbank/netzwerk/
- Elektrotechnik: Ordner /_questionbank/elektrotechnik/
- IT-Systeme: Ordner /_questionbank/it-systeme/
