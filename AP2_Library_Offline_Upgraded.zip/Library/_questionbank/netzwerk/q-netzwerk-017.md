---
title: 'Question net-017: Backup 3-2-1'
tags:
- questionbank
- netzwerk
- backup-3-2-1
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- RAID als Backup ansehen.

## Mini-Beispiel
NAS + USB Disk + Cloud/Offsite.

## Frage
Welche Aussagen zur 3-2-1 Regel sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) 3 Kopien der Daten
- B) 2 verschiedene Medien/Typen
- C) 1 Kopie extern/offsite
- D) 1 Kopie muss immer im gleichen Rack liegen
- E) 3-2-1 ersetzt RAID

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: 3 Kopien, 2 Medientypen, 1 offsite. Nicht 'im gleichen Rack'. RAID ersetzt Backup nicht.
