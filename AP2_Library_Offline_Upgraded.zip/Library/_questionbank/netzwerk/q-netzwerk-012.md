---
title: 'Question net-012: PoE'
tags:
- questionbank
- netzwerk
- poe
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- PoE ohne Budgetplanung.

## Mini-Beispiel
Switch hat 370W PoE Budget, mehrere APs.

## Frage
Welche Aussagen zu PoE sind typisch korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) PoE kann Endgeraete ueber Ethernet mit Strom versorgen.
- B) PoE ist nuetzlich fuer APs/VoIP-Telefone/Kameras.
- C) PoE ersetzt immer ein Netzteil, egal wie hoch die Leistung.
- D) PoE-Budget am Switch kann limitieren.
- E) PoE funktioniert nur ueber Glasfaser.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Strom ueber Ethernet; typische Geraete; Switch-Budget kann limitieren. Nicht immer beliebig und nicht ueber Glasfaser.
