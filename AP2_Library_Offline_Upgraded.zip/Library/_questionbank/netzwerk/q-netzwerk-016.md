---
title: 'Question net-016: Switch Port Security'
tags:
- questionbank
- netzwerk
- switch-port-security
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- 802.1X mit DHCP verwechseln.

## Mini-Beispiel
Bueronetz nur fuer bekannte Clients.

## Frage
Welche Ziele hat Port Security/802.1X (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Zugriffskontrolle am Switchport.
- B) Verhindert ungewollte Geraete im Netz.
- C) Ersetzt VLAN Planung.
- D) Kann MAC/Authentifizierung nutzen.
- E) Vergibt IP-Adressen.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Zugriffskontrolle; verhindert fremde Geraete; kann Auth nutzen. Ersetzt VLAN nicht und vergibt keine IP.
