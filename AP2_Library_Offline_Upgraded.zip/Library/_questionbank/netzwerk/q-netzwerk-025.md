---
title: 'Question net-025: MAC vs IP'
tags:
- questionbank
- netzwerk
- mac-vs-ip
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- MAC und IP als gleich ansehen.

## Mini-Beispiel
Packet von A nach B: auf jedem Hop andere MAC, aber IP bleibt gleich (ohne NAT).

## Frage
Welche Aussagen zu MAC und IP sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) MAC ist Layer 2 Adresse.
- B) IP ist Layer 3 Adresse.
- C) MAC aendert sich beim Routing nicht.
- D) IP-Routing basiert auf MAC-Adressen.
- E) Switching basiert oft auf MAC-Tabellen.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: MAC L2, IP L3, Switching nutzt MAC Tabellen. IP-Routing basiert auf IP, nicht MAC. Beim Routing wird das L2 Header (MAC) pro Hop neu gesetzt.
