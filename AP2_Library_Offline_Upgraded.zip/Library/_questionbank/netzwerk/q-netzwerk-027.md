---
title: 'Question net-027: Split Tunneling'
tags:
- questionbank
- netzwerk
- split-tunneling
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Split/Full verwechseln.

## Mini-Beispiel
Firmennetz ueber VPN, Internet direkt lokal.

## Frage
Welche Aussagen zu Split Tunneling sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Nur bestimmter Traffic geht durch den VPN-Tunnel.
- B) Kann Bandbreite sparen.
- C) Kann Sicherheitsrisiken erhoehen (je nach Policy).
- D) Bedeutet immer Full Tunnel.
- E) Hat nichts mit Routing zu tun.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: nur bestimmter Traffic; kann Bandbreite sparen; kann Risiko erhoehen; hat mit Routing/Policies zu tun. Full Tunnel ist Gegenteil.
