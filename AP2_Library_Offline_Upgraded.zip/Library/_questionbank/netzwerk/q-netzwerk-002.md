---
title: 'Question net-002: Trunk Port'
tags:
- questionbank
- netzwerk
- trunk-port
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Trunk mit 'untagged' verwechseln.

## Mini-Beispiel
AP zum Switch: Trunk erlaubt VLAN20 (VoIP) und VLAN30 (Guest).

## Frage
Welche Aussagen zu Trunk-Ports sind typisch richtig (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Ein Trunk kann mehrere VLANs transportieren.
- B) Auf einem Trunk werden VLANs oft per Tagging unterschieden.
- C) Ein Trunk ist immer untagged.
- D) Allowed VLANs begrenzen, welche VLANs ueber den Trunk gehen.
- E) Ein Trunk ist ein DHCP-Server.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig sind: Trunk traegt mehrere VLANs; Tagging unterscheidet VLANs; Allowed VLANs koennen eingeschraenkt werden. Trunk ist kein DHCP-Server.
