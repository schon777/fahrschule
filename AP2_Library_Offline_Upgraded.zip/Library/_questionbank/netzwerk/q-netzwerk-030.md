---
title: 'Question net-030: Port vs Service'
tags:
- questionbank
- netzwerk
- port-vs-service
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Portnummern als Sicherheitsgarantie ansehen.

## Mini-Beispiel
HTTPS typischerweise 443/TCP.

## Frage
Welche Aussagen zu Ports/Services sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Ports identifizieren Dienste auf einem Host (mit TCP/UDP).
- B) Port 80 ist oft HTTP.
- C) Ein Port ist immer verschluesselt.
- D) Der gleiche Port kann fuer TCP und UDP existieren.
- E) Ports ersetzen DNS.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Ports fuer Dienste; 80 oft HTTP; TCP und UDP getrennt; nicht immer verschluesselt; Ports ersetzen DNS nicht.
