---
title: 'Question net-024: DHCP Relay'
tags:
- questionbank
- netzwerk
- dhcp-relay
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Relay vergessen bei Segmentierung.

## Mini-Beispiel
DHCP Server in Server-VLAN, Clients in Office-VLAN -> Relay am L3-Switch.

## Frage
Welche Aussagen zu DHCP Relay (ip helper) sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Hilft DHCP ueber Subnetze/VLANs hinweg.
- B) Forwardet DHCP-Broadcasts als Unicast zum Server.
- C) Ist noetig, wenn DHCP-Server im gleichen VLAN ist.
- D) Wird oft am L3-Gateway konfiguriert.
- E) Ersetzt DNS.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: ueber VLANs hinweg; Broadcast->Unicast; oft am Gateway. Nicht noetig wenn Server im gleichen VLAN. Kein DNS.
