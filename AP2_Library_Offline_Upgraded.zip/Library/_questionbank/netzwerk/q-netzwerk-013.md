---
title: 'Question net-013: IPv4 Private Netze'
tags:
- questionbank
- netzwerk
- ipv4-private-netze
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- CGNAT Bereich mit RFC1918 verwechseln.

## Mini-Beispiel
LAN mit 192.168.10.0/24.

## Frage
Welche IPv4-Bereiche sind typische Private-Adressbereiche (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) 10.0.0.0/8
- B) 172.16.0.0/12
- C) 192.168.0.0/16
- D) 100.64.0.0/10
- E) 1.1.1.0/24

## Loesung (Klartext, nicht markieren in Optionen)
Typisch private RFC1918: 10/8, 172.16/12, 192.168/16. 100.64/10 ist Carrier-Grade NAT Bereich, nicht klassisch 'privat' fuer LAN. 1.1.1.0/24 ist oeffentlich.
