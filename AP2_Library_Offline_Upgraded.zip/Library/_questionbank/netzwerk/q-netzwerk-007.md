---
title: 'Question net-007: LACP'
tags:
- questionbank
- netzwerk
- lacp
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- LACP wird als 'Routing' missverstanden.

## Mini-Beispiel
2x1G Links als Port-Channel zwischen Switch und Server.

## Frage
Welche Aussagen zu LACP sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Buendelt mehrere physische Links logisch.
- B) Erhoeht Ausfallsicherheit (bei Link-Ausfall).
- C) Ersetzt Routing.
- D) Benutzt typischerweise identische Speed/Duplex Links.
- E) Erzwingt, dass Traffic immer ueber beide Leitungen gleich verteilt wird.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Buendeln von Links; kann Redundanz bringen; typischerweise gleiche Link-Eigenschaften. Routing ersetzt es nicht. Verteilung kann hash-basiert sein, nicht zwingend immer 50/50 pro Flow.
