---
title: 'Question net-011: WLAN SSID'
tags:
- questionbank
- netzwerk
- wlan-ssid
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- SSID mit IP-Konzept verwechseln.

## Mini-Beispiel
SSID 'Guest' mapped to VLAN30.

## Frage
Welche Aussagen zu SSID und WLAN sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) SSID ist der Netzwerkname.
- B) SSID bestimmt direkt die IP-Adresse.
- C) Mehrere SSIDs koennen auf einem AP existieren.
- D) SSID kann unterschiedlichen VLANs zugeordnet werden.
- E) SSID ist ein Kabeltyp.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: SSID = Name; mehrere SSIDs; Zuordnung zu VLANs ist moeglich. SSID bestimmt nicht direkt IP und ist kein Kabeltyp.
