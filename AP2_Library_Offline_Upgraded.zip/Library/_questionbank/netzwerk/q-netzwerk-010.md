---
title: 'Question net-010: VPN Tunnel'
tags:
- questionbank
- netzwerk
- vpn-tunnel
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Nur Tunnelstatus betrachten.

## Mini-Beispiel
VPN up, Ping Remote GW fail -> route/policy check.

## Frage
Tunnel steht, aber Zugriff geht nicht: Was sind typische Ursachen (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Routing fehlt auf einer Seite.
- B) Firewall/ACL blockt.
- C) Subnetze ueberschneiden sich.
- D) DNS im Tunnel nicht korrekt (split DNS).
- E) CPU des Clients ist zu schnell.

## Loesung (Klartext, nicht markieren in Optionen)
Typisch: Routing, Firewall, Subnet overlap, DNS. CPU ist irrelevant.
