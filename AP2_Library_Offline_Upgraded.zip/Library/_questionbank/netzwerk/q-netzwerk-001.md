---
title: 'Question net-001: VLAN vs Subnet'
tags:
- questionbank
- netzwerk
- vlan-vs-subnet
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- VLAN und Subnet werden gleichgesetzt.

## Mini-Beispiel
Beispiel: VLAN10 192.168.10.0/24 und VLAN20 192.168.20.0/24. Kommunikation nur ueber Router/L3-Switch.

## Frage
Welche Aussagen treffen zu (Mehrfachangabe) in Bezug auf VLAN und Subnet?

## Optionen (neutral, Mehrfachangabe)
- A) Ein VLAN segmentiert auf Layer 2.
- B) Ein Subnet definiert einen Layer-3-Adressbereich.
- C) VLAN und Subnet sind immer identisch.
- D) Inter-VLAN-Kommunikation braucht Routing (L3).
- E) Ein VLAN ersetzt DNS.

## Loesung (Klartext, nicht markieren in Optionen)
Korrekt sind u.a.: VLAN segmentiert Layer 2; Subnet ist Layer 3; fuer Kommunikation zwischen VLANs ist Routing/L3 erforderlich. VLAN=Subnet ist nicht zwingend. DNS ist unabhaengig.
