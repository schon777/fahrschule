---
title: 'Question net-009: QoS/DSCP'
tags:
- questionbank
- netzwerk
- qos-dscp
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- QoS mit mehr Bandbreite verwechseln.

## Mini-Beispiel
Wenn Link ausgelastet: Voice bevorzugen.

## Frage
Welche Aussagen zu QoS/DSCP sind richtig (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) QoS priorisiert Traffic.
- B) DSCP ist eine Markierung im IP-Header.
- C) QoS ist nur fuer WLAN relevant.
- D) VoIP profitiert oft von Priorisierung.
- E) DSCP ersetzt Bandbreite.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: QoS priorisiert; DSCP markiert; VoIP profitiert. Nicht nur WLAN. Keine echte Bandbreite, sondern Prioritaet.
