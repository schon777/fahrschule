---
title: 'Question net-028: Firewall vs ACL'
tags:
- questionbank
- netzwerk
- firewall-vs-acl
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- ACL als stateful annehmen.

## Mini-Beispiel
Inbound block, established allowed.

## Frage
Welche Aussagen sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Eine Firewall kann zustandsbehaftet (stateful) arbeiten.
- B) ACLs sind oft simple Regel-Listen auf Interfaces.
- C) Firewall und ACL sind immer identisch.
- D) Beide koennen Traffic filtern.
- E) Stateful kann Rueckverkehr automatisch erlauben.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Firewall kann stateful; ACLs oft einfache Listen; beide filtern; stateful erlaubt Rueckverkehr. Nicht identisch.
