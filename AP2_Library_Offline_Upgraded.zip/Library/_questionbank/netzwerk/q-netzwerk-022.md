---
title: 'Question net-022: Default Gateway'
tags:
- questionbank
- netzwerk
- default-gateway
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- DNS als Gateway eintragen.

## Mini-Beispiel
PC in 192.168.10.0/24 nutzt 192.168.10.1 als GW.

## Frage
Welche Aussagen zum Default Gateway sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Es ist der Router fuer Ziele ausserhalb des lokalen Subnetzes.
- B) Ohne Gateway funktioniert meist nur lokaler Verkehr.
- C) Gateway ist immer der DNS-Server.
- D) Gateway kann eine IP im eigenen Subnet haben.
- E) Mehrere Gateways sind immer besser.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Router fuer fremde Netze; ohne Gateway nur lokal; Gateway IP im Subnet. Gateway ist nicht gleich DNS. Mehrere Gateways brauchen Routing-Design.
