---
title: 'Question net-006: STP'
tags:
- questionbank
- netzwerk
- stp
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- STP wird vergessen bei redundanten Links.

## Mini-Beispiel
Zwei Switches doppelt verbunden -> STP blockt einen Pfad.

## Frage
Wozu dient STP/RSTP im Switch-Netz (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Verhindert Layer-2 Loops.
- B) Reduziert Broadcast-Storms durch Loop-Vermeidung.
- C) Vergibt IP-Adressen.
- D) Ermittelt einen loopfreien Baum (Topology).
- E) Ersetzt VLANs.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Loop-Vermeidung; damit weniger Broadcast-Storms; berechnet loopfreien Pfad. Kein DHCP und ersetzt VLANs nicht.
