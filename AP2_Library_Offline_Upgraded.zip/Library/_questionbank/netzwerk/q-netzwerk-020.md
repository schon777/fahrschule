---
title: 'Question net-020: Subnetting'
tags:
- questionbank
- netzwerk
- subnetting
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Subnetting ohne Doku.

## Mini-Beispiel
Benutze /24 fuer bis 254 Hosts.

## Frage
Welche Schritte sind bei IPv4 Subnetting typisch sinnvoll (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Anzahl Hosts benoetigt ermitteln.
- B) Passende Prefixlaenge waehlen.
- C) Netzadresse/Broadcast berechnen.
- D) DNS-Server kaufen.
- E) IP-Plan dokumentieren.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Hosts, Prefix, Netz/Broadcast, dokumentieren. DNS kaufen nicht relevant.
