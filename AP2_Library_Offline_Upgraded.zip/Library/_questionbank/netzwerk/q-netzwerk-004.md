---
title: 'Question net-004: DNS Symptom'
tags:
- questionbank
- netzwerk
- dns-symptom
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Ohne IP sofort DNS schuld geben.

## Mini-Beispiel
Ping 8.8.8.8 ok, ping example.com fail -> DNS.

## Frage
Welche Symptome sprechen eher fuer ein DNS-Problem (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Ping auf externe IP funktioniert, aber Name nicht.
- B) Nur bestimmte Namen/Domain gehen nicht.
- C) IP-Adresse wird gar nicht vergeben.
- D) Webseite geht nicht, aber nslookup zeigt richtigen Eintrag.
- E) Namensaufloesung dauert extrem lange.

## Loesung (Klartext, nicht markieren in Optionen)
Typische DNS-Indikatoren: IP geht aber Name nicht; bestimmte Domains; sehr langsame Aufloesung. Keine IP ist eher DHCP/Layer Problem.
