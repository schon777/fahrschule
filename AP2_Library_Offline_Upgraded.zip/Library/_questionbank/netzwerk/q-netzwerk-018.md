---
title: 'Question net-018: RAID vs Backup'
tags:
- questionbank
- netzwerk
- raid-vs-backup
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Nur Backup machen ohne Restore-Test.

## Mini-Beispiel
User loescht Datei -> Restore aus Backup/Snapshot.

## Frage
Welche Aussagen sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) RAID erhoeht Verfuegbarkeit gegen Plattenausfall.
- B) Backup hilft gegen Loeschung/Ransomware.
- C) RAID ersetzt Backup.
- D) Snapshots koennen Teil einer Strategie sein.
- E) Backup braucht Restore-Test.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: RAID Verfuegbarkeit; Backup gegen Loeschung; snapshots; restore testen. RAID ersetzt Backup nicht.
