---
title: 'Question net-014: TCP vs UDP'
tags:
- questionbank
- netzwerk
- tcp-vs-udp
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- TCP als 'schneller' pauschal sehen.

## Mini-Beispiel
VoIP oft UDP, Web oft TCP.

## Frage
Welche Aussagen zu TCP und UDP sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) TCP ist verbindungsorientiert.
- B) UDP ist verbindungslos.
- C) TCP garantiert immer niedrige Latenz.
- D) UDP hat weniger Overhead.
- E) Beide nutzen Ports.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: TCP verbindungsorientiert; UDP verbindungslos; UDP weniger Overhead; beide nutzen Ports. Niedrige Latenz ist nicht garantiert.
