---
title: 'Question net-003: DHCP'
tags:
- questionbank
- netzwerk
- dhcp
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- DHCP mit DNS verwechseln.

## Mini-Beispiel
Client bekommt IP, GW, DNS automatisch und kann danach Namen aufloesen.

## Frage
Welche Komponenten/Infos werden typischerweise durch DHCP bereitgestellt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) IP-Adresse
- B) Subnetzmaske/Prefix
- C) Default Gateway
- D) DNS-Server
- E) MAC-Adresse des Switches

## Loesung (Klartext, nicht markieren in Optionen)
Richtig sind: IP, Maske/Prefix, Gateway, DNS sind typische DHCP-Optionen. MAC des Switches gehoert nicht dazu.
