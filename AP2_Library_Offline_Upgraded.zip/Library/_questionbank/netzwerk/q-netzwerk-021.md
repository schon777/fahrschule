---
title: 'Question net-021: ARP'
tags:
- questionbank
- netzwerk
- arp
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- ARP und DNS verwechseln.

## Mini-Beispiel
Client kennt IP des Gateways -> ARP um MAC zu finden.

## Frage
Welche Aussagen zu ARP sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) ARP ordnet IPv4-Adressen MAC-Adressen zu.
- B) ARP arbeitet im lokalen Netzwerksegment.
- C) ARP ersetzt Routing.
- D) ARP-Anfragen sind typischerweise Broadcasts.
- E) ARP ist nur fuer IPv6.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: ARP mappt IPv4->MAC; lokal; ARP Requests oft Broadcast. Es ersetzt Routing nicht und ist nicht fuer IPv6 (dort NDP).
