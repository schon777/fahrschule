---
title: 'Question net-008: ACL'
tags:
- questionbank
- netzwerk
- acl
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- ACL und VLAN werden vermischt.

## Mini-Beispiel
Gast-VLAN darf nur ins Internet, nicht ins interne Netz (ACL/Firewall).

## Frage
Welche Aussagen zu ACLs sind typisch korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) ACLs koennen Verkehr erlauben oder blockieren.
- B) ACLs sind immer gleichbedeutend mit VLAN.
- C) ACLs werden auf Interfaces/Policies angewendet.
- D) ACLs koennen nach IP/Port/Protokoll filtern.
- E) ACLs ersetzen Backup.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: erlauben/blockieren; werden angewendet; filtern nach Kriterien. Kein VLAN und kein Backup.
