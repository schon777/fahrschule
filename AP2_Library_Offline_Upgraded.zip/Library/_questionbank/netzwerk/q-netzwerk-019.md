---
title: 'Question net-019: Monitoring'
tags:
- questionbank
- netzwerk
- monitoring
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Alert-Fatigue (zu viele Alarme).

## Mini-Beispiel
Ping + SNMP + Syslog fuer Switches.

## Frage
Welche Aussagen zu Monitoring sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Monitoring kann Ausfaelle frueh erkennen.
- B) Logs sind eine Quelle fuer Troubleshooting.
- C) Monitoring ersetzt Dokumentation.
- D) Alerts muessen sinnvoll gefiltert werden.
- E) Ohne Baseline sind Grenzwerte schwer.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: frueh erkennen; logs; alerts filtern; baseline hilft. Monitoring ersetzt Doku nicht.
