---
title: 'Question net-005: NAT'
tags:
- questionbank
- netzwerk
- nat
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- NAT mit Routing gleichsetzen.

## Mini-Beispiel
Mehrere interne Clients teilen eine oeffentliche IP via PAT.

## Frage
Welche Aussagen zu NAT sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) NAT aendert IP-Adressen (z.B. intern->extern).
- B) NAT ersetzt Routing komplett.
- C) NAT wird oft am Internet-Router eingesetzt.
- D) NAT kann Port-Translation verwenden.
- E) NAT ist ein Layer-1 Protokoll.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: NAT aendert Adressen; oft am Edge-Router; kann Port-Translation (PAT) nutzen. NAT ersetzt Routing nicht und ist nicht Layer 1.
