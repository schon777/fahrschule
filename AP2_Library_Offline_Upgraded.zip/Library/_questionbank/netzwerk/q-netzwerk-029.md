---
title: 'Question net-029: VPN Typen'
tags:
- questionbank
- netzwerk
- vpn-typen
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- VPN als Allheilmittel sehen.

## Mini-Beispiel
Site-to-site IPsec zwischen Standorten.

## Frage
Welche Aussagen zu IPsec/WireGuard/SSL-VPN sind allgemein korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) IPsec arbeitet auf Netzwerkebene (L3).
- B) WireGuard ist ein VPN-Protokoll mit Key-basiertem Setup.
- C) SSL-VPNs laufen oft ueber TLS.
- D) Alle VPNs sind automatisch Ende-zu-Ende im Sinne von Application Security.
- E) VPN ersetzt nicht zwingend Zero Trust Policies.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: IPsec L3; WireGuard VPN; SSL-VPN ueber TLS. VPN ist nicht automatisch App-Ende-zu-Ende und ersetzt Policies nicht.
