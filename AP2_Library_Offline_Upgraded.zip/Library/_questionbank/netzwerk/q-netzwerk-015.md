---
title: 'Question net-015: ICMP'
tags:
- questionbank
- netzwerk
- icmp
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- ICMP komplett abschalten ohne Begruendung.

## Mini-Beispiel
Traceroute/Ping fuer Diagnose.

## Frage
Welche Aussagen zu ICMP sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Ping nutzt ICMP Echo.
- B) ICMP kann fuer Fehlermeldungen im IP-Netz genutzt werden.
- C) ICMP ersetzt DNS.
- D) ICMP ist Layer 2.
- E) ICMP wird oft von Firewalls gefiltert.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Ping Echo; Fehlermeldungen; kann gefiltert werden. Es ist kein DNS und nicht Layer 2.
