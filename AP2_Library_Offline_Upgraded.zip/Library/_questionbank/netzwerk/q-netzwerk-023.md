---
title: 'Question net-023: MTU'
tags:
- questionbank
- netzwerk
- mtu
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: netzwerk. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Jumbo nur auf einem Switch aktivieren.

## Mini-Beispiel
iSCSI in einem LAN: Jumbo Frames nur wenn alle Komponenten passen.

## Frage
Welche Aussagen zu MTU sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) MTU ist die maximale Nutzlastgroesse pro Frame/Packet-Segment im Kontext eines Links.
- B) Zu grosse MTU kann Fragmentierung/Probleme verursachen.
- C) MTU betrifft nur WLAN.
- D) Jumbo Frames koennen Performance beeinflussen, aber muessen Ende-zu-Ende passen.
- E) MTU ist ein Passwort.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: MTU Maxgroesse; mismatch kann Probleme; Jumbo Frames muessen passen. Nicht nur WLAN, kein Passwort.
