---
title: 'Question ele-012: Sicherheitsregeln'
tags:
- questionbank
- elektrotechnik
- sicherheitsregeln
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Sicherheitsregeln als optional sehen.

## Mini-Beispiel
Vor Arbeit im Schaltschrank: freischalten, sichern, feststellen.

## Frage
Welche der '5 Sicherheitsregeln' gehoeren dazu (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Freischalten
- B) Gegen Wiedereinschalten sichern
- C) Spannungsfreiheit feststellen
- D) Erden und kurzschliessen (wo gefordert)
- E) Benachbarte, unter Spannung stehende Teile abdecken/abschranken

## Loesung (Klartext, nicht markieren in Optionen)
Die 5 Sicherheitsregeln umfassen u.a. diese Punkte (je nach Umfeld/Spannungsebene).
