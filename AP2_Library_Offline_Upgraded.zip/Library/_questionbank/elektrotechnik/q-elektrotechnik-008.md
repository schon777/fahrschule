---
title: 'Question ele-008: Isolationswiderstand'
tags:
- questionbank
- elektrotechnik
- isolationswiderstand
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Messverfahren verwechseln.

## Mini-Beispiel
Bei empfindlicher Elektronik ggf. nach Vorschrift trennen.

## Frage
Welche Aussagen sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Misst Isolationsqualitaet zwischen Leitern/Erde.
- B) Wird mit einer Pruefspannung gemessen (je nach Norm/Geraet).
- C) Ist identisch mit Schleifenimpedanz.
- D) Hilft bei der Erkennung von Isolationsfehlern.
- E) Kann bei angeschlossenen elektronischen Geraeten Vorsicht erfordern.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Isolationsqualitaet; Pruefspannung; erkennt Fehler; Vorsicht bei Elektronik. Nicht identisch mit Schleifenimpedanz.
