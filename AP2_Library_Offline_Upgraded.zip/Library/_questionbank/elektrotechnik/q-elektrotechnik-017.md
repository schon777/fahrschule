---
title: 'Question ele-017: Ueberlast'
tags:
- questionbank
- elektrotechnik
- ueberlast
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Fehlerstrom vs Ueberlast verwechseln.

## Mini-Beispiel
Mehrfachsteckdose ueberlastet.

## Frage
Welche Aussagen zu Ueberlast sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Ueberlast ist zu hoher Strom ueber laengere Zeit (typisch).
- B) Kann Leitungen erwaermen.
- C) Wird oft durch thermische Ausloeser detektiert.
- D) Ist identisch mit Fehlerstrom.
- E) Kann bei zu vielen Verbrauchern auftreten.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: zu hoher Strom ueber Zeit; Erwrmung; thermische Ausloeser; zu viele Verbraucher. Nicht identisch mit Fehlerstrom.
