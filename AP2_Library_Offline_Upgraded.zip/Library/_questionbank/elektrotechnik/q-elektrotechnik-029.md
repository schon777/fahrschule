---
title: 'Question ele-029: Schutztrennung'
tags:
- questionbank
- elektrotechnik
- schutztrennung
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- SELV und Trennung gleichsetzen.

## Mini-Beispiel
Werkstatt: Trenntrafo fuer Service, je nach Vorgaben.

## Frage
Welche Aussagen zur Schutztrennung sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Schutztrennung nutzt Trenntrafo/galvanische Trennung.
- B) Kann das Risiko von Fehlerstroemen reduzieren (Konzeptabhaengig).
- C) Ersetzt immer jeden PE.
- D) Ist ein Schutzprinzip in bestimmten Situationen.
- E) Ist identisch mit SELV.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: galvanische Trennung; Schutzprinzip; nicht immer PE ersetzen; nicht identisch mit SELV.
