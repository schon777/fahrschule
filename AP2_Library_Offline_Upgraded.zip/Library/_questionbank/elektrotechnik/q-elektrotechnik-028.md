---
title: 'Question ele-028: RCD Test'
tags:
- questionbank
- elektrotechnik
- rcd-test
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Testtaste als einzige Pruefung verwenden.

## Mini-Beispiel
Testtaste druecken -> RCD loest aus.

## Frage
Welche Aussagen zu RCD Tests sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) RCDs haben oft eine Testtaste fuer Funktionspruefung.
- B) Test ersetzt keine normgerechte Messung, kann aber Funktionshinweis geben.
- C) Wenn Testtaste geht, ist alles immer perfekt.
- D) Regelmaessige Pruefung kann gefordert sein.
- E) RCD ist gleich LS.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Testtaste; ersetzt keine vollstaendige Messung; regelmaessige Pruefung moeglich. Nicht identisch mit LS.
