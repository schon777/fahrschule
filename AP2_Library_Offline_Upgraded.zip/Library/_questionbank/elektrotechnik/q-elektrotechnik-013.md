---
title: 'Question ele-013: Schleifenimpedanz'
tags:
- questionbank
- elektrotechnik
- schleifenimpedanz
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Schleife und Isolation verwechseln.

## Mini-Beispiel
Zu lange Leitung -> Impedanz steigt, Abschaltbedingung pruefen.

## Frage
Welche Aussagen zur Schleifenimpedanz sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Sie beeinflusst die Abschaltbedingungen im Fehlerfall.
- B) Sie ist identisch mit Isolationswiderstand.
- C) Sie haengt von Leitungswiderstand/Netzimpedanz ab.
- D) Zu hohe Impedanz kann Abschaltung erschweren.
- E) Sie ist nur fuer IT-Netze relevant.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: beeinflusst Abschaltung; haengt von Impedanzen ab; zu hoch erschwert. Nicht identisch mit Isolation und nicht nur IT.
