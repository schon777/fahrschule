---
title: 'Question ele-030: Drehrichtung Motor'
tags:
- questionbank
- elektrotechnik
- drehrichtung-motor
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Drehrichtung ungeprueft lassen.

## Mini-Beispiel
Nach Anschluss pruefen, ggf. zwei Phasen tauschen.

## Frage
Welche Aussagen sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Drehrichtung bei Drehstrommotoren haengt vom Drehfeld ab.
- B) Tausch zweier Aussenleiter kann Drehrichtung aendern.
- C) Drehrichtung kann fuer Pumpen/Foerderer kritisch sein.
- D) Drehrichtung wird durch DNS bestimmt.
- E) Motor dreht immer richtig herum.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Drehfeld; Leiter tauschen; kritisch. DNS irrelevant, nicht immer richtig.
