---
title: 'Question ele-007: Messen: Durchgang'
tags:
- questionbank
- elektrotechnik
- messen-durchgang
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Durchgang statt Isolation messen.

## Mini-Beispiel
PE Leitung am Geraet pruefen.

## Frage
Welche Aussagen zur Durchgangspruefung sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Prueft ob eine leitende Verbindung besteht.
- B) Ist sinnvoll fuer PE-Kontinuitaet (je nach Vorgabe).
- C) Ersetzt Isolationsmessung.
- D) Kann bei spannungsfreiem Zustand erfolgen.
- E) Ist geeignet um Kurzschluss unter Last zu messen.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: leitende Verbindung; PE Kontinuitaet; spannungsfrei. Ersetzt keine Isolationsmessung und nicht fuer 'unter Last' gedacht.
