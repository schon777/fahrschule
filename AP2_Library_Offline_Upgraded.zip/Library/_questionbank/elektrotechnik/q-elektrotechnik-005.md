---
title: 'Question ele-005: Netzformen'
tags:
- questionbank
- elektrotechnik
- netzformen
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Netzform ignorieren.

## Mini-Beispiel
TT: RCD oft wichtig wegen Schleifenimpedanz.

## Frage
Welche Aussagen zu TN/TT/IT-Netzen sind allgemein korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) TN: Sternpunkt geerdet, Schutzleiter mit System verbunden (je nach Variante).
- B) TT: Verbraucher-Erdung ueber eigenen Erder, getrennt vom Netzbetreiber-PE.
- C) IT: Netz isoliert oder ueber hohe Impedanz geerdet.
- D) TT bedeutet immer kein RCD noetig.
- E) Netzform beeinflusst Schutzmassnahmen.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: TN/TT/IT grobe Einordnung; Schutzmassnahmen haengen davon ab. TT braucht oft RCD, nicht 'kein RCD'.
