---
title: 'Question ele-023: Sicherung'
tags:
- questionbank
- elektrotechnik
- sicherung
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Sicherung hochdrehen statt Ursache suchen.

## Mini-Beispiel
Motor/Trafo mit hohem Einschaltstrom: passende Ausloesecharakteristik begruenden.

## Frage
Welche Aussagen zu Sicherungen/Schutzorganen sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Schutzorgane muessen zur Leitung und Last passen.
- B) Falsche Auslegung kann zu Fehlausloesung oder fehlendem Schutz fuehren.
- C) Groessere Sicherung ist immer besser.
- D) Charakteristik (z.B. B/C) kann Einschaltstrom beruecksichtigen.
- E) Schutzorgane ersetzen korrekte Verdrahtung.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: auslegen; falsche Auslegung problematisch; groesser nicht besser; Charakteristik kann inrush beachten. Sie ersetzen keine korrekte Verdrahtung.
