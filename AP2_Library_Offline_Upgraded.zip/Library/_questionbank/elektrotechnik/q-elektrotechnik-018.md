---
title: 'Question ele-018: SELV/PELV'
tags:
- questionbank
- elektrotechnik
- selv-pelv
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- SELV als Allheilmittel.

## Mini-Beispiel
Steuerkreis 24V SELV.

## Frage
Welche Aussagen zu SELV/PELV sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) SELV ist Schutzkleinspannung mit galvanischer Trennung.
- B) PELV ist aehnlich, aber ein Bezug zu Erde kann vorhanden sein.
- C) SELV bedeutet immer 230V.
- D) SELV/PELV werden fuer sichere Kleinspannungsbereiche genutzt.
- E) SELV ersetzt jede Schutzmassnahme fuer 230V.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: SELV Trennung; PELV Bezug moeglich; genutzt fuer sichere Kleinspannung. Nicht 230V und ersetzt nicht 230V Schutz.
