---
title: 'Question ele-026: Leitungsquerschnitt'
tags:
- questionbank
- elektrotechnik
- leitungsquerschnitt
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Querschnitt nur nach Bauchgefuehl.

## Mini-Beispiel
Lange Leitung -> ggf. groesserer Querschnitt begruenden.

## Frage
Welche Aussagen sind allgemein korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Querschnitt beeinflusst Strombelastbarkeit und Spannungsfall (grob).
- B) Laenge/Verlegeart spielen ebenfalls eine Rolle.
- C) Querschnitt hat keinen Einfluss auf Erwrmung.
- D) Schutzorgan muss zum Querschnitt passen.
- E) Nur die Farbe bestimmt den Querschnitt.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: beeinflusst; Laenge/Verlegeart; Schutzorgan passend. Querschnitt beeinflusst Erwrmung; Farbe bestimmt nicht Querschnitt.
