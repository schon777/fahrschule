---
title: 'Question ele-019: Leiterfarben'
tags:
- questionbank
- elektrotechnik
- leiterfarben
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Farben ohne Kontext raten.

## Mini-Beispiel
Verdrahtung im Schaltschrank: PE gruen-gelb, N blau.

## Frage
Welche Aussagen zu Leiterfarben sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Gruen-gelb ist typischerweise PE.
- B) Blau ist typischerweise N.
- C) Braun/schwarz/grau werden oft als Aussenleiter genutzt.
- D) Farben sind immer weltweit identisch.
- E) Aufgaben-/Normkontext kann relevant sein.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: typische Farben; Kontext kann relevant. Nicht weltweit identisch.
