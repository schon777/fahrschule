---
title: 'Question ele-004: PE/N/L'
tags:
- questionbank
- elektrotechnik
- pe-n-l
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- PE und N vertauschen.

## Mini-Beispiel
Gehause an PE -> Fehlerstrom wird abgeleitet.

## Frage
Welche Aussagen zu Leitern PE, N, L sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) PE ist Schutzleiter.
- B) N ist Neutralleiter.
- C) L ist Aussenleiter/Phase.
- D) PE fuehrt im Normalbetrieb den Arbeitsstrom.
- E) PE darf nicht willkuerlich weggelassen werden.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: PE Schutzleiter, N Neutral, L Aussenleiter. PE fuehrt normal keinen Arbeitsstrom. PE weglassen ist sicherheitskritisch.
