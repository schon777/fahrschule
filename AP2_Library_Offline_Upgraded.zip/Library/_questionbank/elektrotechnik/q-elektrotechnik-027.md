---
title: 'Question ele-027: EMV Schirmanschluss'
tags:
- questionbank
- elektrotechnik
- emv-schirmanschluss
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Schirm nicht anschliessen und trotzdem Wirkung erwarten.

## Mini-Beispiel
Ethernet in Industrie: geschirmt + sauberer Anschluss.

## Frage
Welche Aussagen zum Schirmanschluss sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Ein Schirm wirkt besser, wenn er korrekt angeschlossen ist.
- B) Ein 'fliegender' Schirm ohne Anschluss bringt oft wenig.
- C) Schirmung ersetzt immer Verdrillung.
- D) Potentialausgleich kann bei Schirmung relevant sein.
- E) Schirmung ist nur fuer Audio.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Anschluss wichtig; fliegender Schirm wenig; PA relevant. Schirmung ersetzt Verdrillung nicht und ist nicht nur Audio.
