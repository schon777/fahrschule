---
title: 'Question ele-014: Spannungsfall'
tags:
- questionbank
- elektrotechnik
- spannungsfall
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Spannungsfall ignorieren.

## Mini-Beispiel
Lange Leitung zu Motor -> Funktion pruefen.

## Frage
Welche Aussagen zum Spannungsfall sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Spannungsfall steigt mit Strom und Leitungslnge (grob).
- B) Groesserer Querschnitt reduziert Spannungsfall (grob).
- C) Spannungsfall ist immer 0.
- D) Spannungsfall kann fuer Funktion/Sicherheit relevant sein.
- E) Spannungsfall betrifft nur DC.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: steigt mit I und Laenge; Querschnitt reduziert; relevant; betrifft auch AC. Nicht immer 0.
