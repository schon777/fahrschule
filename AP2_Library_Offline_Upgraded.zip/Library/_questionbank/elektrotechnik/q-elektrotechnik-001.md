---
title: 'Question ele-001: Ohmsches Gesetz'
tags:
- questionbank
- elektrotechnik
- ohmsches-gesetz
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Ohm pauschal fuer alles anwenden.

## Mini-Beispiel
24V, 12 Ohm -> I=2A.

## Frage
Welche Aussagen zu Ohmschem Gesetz sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) U = R * I
- B) I = U / R
- C) R = U / I
- D) U = I / R
- E) Ohmsches Gesetz gilt immer fuer jedes Bauteil bei jeder Frequenz.

## Loesung (Klartext, nicht markieren in Optionen)
Korrekt: U=R*I, I=U/R, R=U/I. U=I/R ist falsch. Gueltigkeit: als Naeherung fuer ohmsche Verbraucher; nicht fuer alle nichtlinearen/AC-Faelle pauschal.
