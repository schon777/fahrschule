---
title: 'Question ele-006: Schutzklasse'
tags:
- questionbank
- elektrotechnik
- schutzklasse
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- SK II mit PE verwechseln.

## Mini-Beispiel
Laptopnetzteil oft SK II, Gert teils SK III/SELV Bereiche.

## Frage
Welche Aussagen zu Schutzklassen sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Schutzklasse I: Schutzleiteranschluss.
- B) Schutzklasse II: doppelte/verstaerkte Isolierung.
- C) Schutzklasse III: Betrieb mit Schutzkleinspannung (SELV).
- D) Schutzklasse II braucht immer PE.
- E) Schutzklasse III bedeutet automatisch 230V.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: I mit PE; II doppelte Isolierung; III Schutzkleinspannung. II braucht keinen PE. III nicht 230V.
