---
title: 'Question ele-021: Erdung vs Potentialausgleich'
tags:
- questionbank
- elektrotechnik
- erdung-vs-potentialausgleich
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Begriffe vermischen.

## Mini-Beispiel
Metallische Teile werden verbunden, um Beruehrungsspannungen zu reduzieren.

## Frage
Welche Aussagen zu Erdung und Potentialausgleich sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Erdung verbindet ein System mit Erde (Potential).
- B) Potentialausgleich verbindet leitfaehige Teile miteinander, um Potentialdifferenzen zu reduzieren.
- C) Potentialausgleich ersetzt jede Erdung immer.
- D) Beide sind fuer Sicherheit/EMV relevant.
- E) Potentialausgleich ist nur Deko.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Erdung zur Erde; Potentialausgleich zwischen Teilen; beide relevant. Potentialausgleich ersetzt nicht alles.
