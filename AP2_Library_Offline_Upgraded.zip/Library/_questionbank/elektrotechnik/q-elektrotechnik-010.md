---
title: 'Question ele-010: Reihenschaltung'
tags:
- questionbank
- elektrotechnik
- reihenschaltung
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Reihe vs parallel verwechseln.

## Mini-Beispiel
2 Widerstaende in Reihe -> Rges = R1+R2.

## Frage
Welche Aussagen zur Reihenschaltung sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Strom ist in allen Bauteilen gleich.
- B) Spannungen teilen sich auf.
- C) Widerstaende addieren sich.
- D) Spannung ist in allen Bauteilen gleich.
- E) Bei Ausfall eines Bauteils ist der Stromkreis unterbrochen.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Strom gleich; Spannungen teilen; R addiert; Ausfall unterbricht. Spannung gleich ist parallel, nicht Reihe.
