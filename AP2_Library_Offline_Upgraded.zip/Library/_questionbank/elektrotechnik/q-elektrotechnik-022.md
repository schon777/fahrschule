---
title: 'Question ele-022: IP Schutzart'
tags:
- questionbank
- elektrotechnik
- ip-schutzart
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- IP mit Ex-Schutz verwechseln.

## Mini-Beispiel
Aussenbereich -> passende IP waehlen und begruenden.

## Frage
Welche Aussagen zur IP-Schutzart sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) IP beschreibt Schutz gegen Fremdkoerper und Wasser.
- B) Die erste Ziffer bezieht sich auf Fremdkoerper/Staub.
- C) Die zweite Ziffer bezieht sich auf Wasser.
- D) IP ist eine Angabe zur Datenrate.
- E) Hoehere IP bedeutet immer 'explosionsgeschuetzt'.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: IP Fremdkoerper/Wasser; 1. Ziffer Fremdkoerper; 2. Ziffer Wasser. Nicht Datenrate und nicht automatisch Ex-Schutz.
