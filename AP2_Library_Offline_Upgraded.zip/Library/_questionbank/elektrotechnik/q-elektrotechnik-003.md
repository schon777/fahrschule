---
title: 'Question ele-003: RCD vs LS'
tags:
- questionbank
- elektrotechnik
- rcd-vs-ls
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- RCD als Kurzschlussschutz ansehen.

## Mini-Beispiel
Steckdosenkreis: LS + RCD.

## Frage
Welche Aussagen zu RCD (FI) und LS sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) RCD schuetzt gegen Fehlerstroeme (Personenschutz).
- B) LS schuetzt gegen Ueberstrom/Kurzschluss.
- C) RCD ersetzt LS immer.
- D) Beide koennen in Installationen kombiniert werden.
- E) LS misst Differenzstrom zwischen L und N.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: RCD Fehlerstrom; LS Ueberstrom; Kombination ueblich. RCD ersetzt LS nicht, LS misst keinen Differenzstrom.
