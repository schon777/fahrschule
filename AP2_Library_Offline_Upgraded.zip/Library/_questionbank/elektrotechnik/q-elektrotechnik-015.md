---
title: 'Question ele-015: Drehstrom'
tags:
- questionbank
- elektrotechnik
- drehstrom
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- 400V pauschal annehmen.

## Mini-Beispiel
Motor laeuft falsch herum -> Drehrichtung tauschen.

## Frage
Welche Aussagen zu Drehstrom sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Es gibt drei Aussenleiter (L1, L2, L3).
- B) N kann vorhanden sein (je nach System/Last).
- C) Drehstrom bedeutet immer 400V an jeder Steckdose.
- D) Drehfeldrichtung kann bei Motoren relevant sein.
- E) Stern/Dreieck sind Schaltungsarten fuer Lasten.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: drei Aussenleiter; N kann; Drehrichtung relevant; Stern/Dreieck. Nicht jede Steckdose 400V.
