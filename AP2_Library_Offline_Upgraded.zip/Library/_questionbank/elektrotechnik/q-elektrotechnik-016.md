---
title: 'Question ele-016: Kurzschluss'
tags:
- questionbank
- elektrotechnik
- kurzschluss
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Kurzschluss als harmlos abtun.

## Mini-Beispiel
Werkzeug brueckt Kontakte -> Schutz loest aus.

## Frage
Welche Aussagen zu Kurzschluss sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Kurzschluss verursacht sehr hohen Strom (je nach Impedanz).
- B) LS/Schutzorgane sollen abschalten.
- C) Kurzschluss ist das gleiche wie Ueberlast.
- D) Kurzschluss kann zu Lichtbogen/Brand fuehren.
- E) Kurzschluss ist ungefaehrlich wenn Spannung klein ist.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: hoher Strom; Schutz schaltet; Brandgefahr. Kurzschluss != Ueberlast. Auch klein kann gefaehrlich sein je nach Situation.
