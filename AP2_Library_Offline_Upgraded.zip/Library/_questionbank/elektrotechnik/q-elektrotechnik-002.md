---
title: 'Question ele-002: Leistung'
tags:
- questionbank
- elektrotechnik
- leistung
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Watt und Wh verwechseln.

## Mini-Beispiel
100W ueber 2h -> Energie 200Wh.

## Frage
Welche Aussagen zu elektrischer Leistung sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) P = U * I (DC)
- B) P kann auch als I^2 * R berechnet werden (ohmsch).
- C) P ist immer gleich Energie.
- D) Energie ist Leistung mal Zeit.
- E) Leistung wird in Watt angegeben.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: P=U*I (DC); P=I^2*R fuer ohmsch; Energie = P * t; Watt ist Einheit. Leistung ist nicht gleich Energie.
