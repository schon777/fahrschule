---
title: 'Question ele-025: Beruehrungsspannung'
tags:
- questionbank
- elektrotechnik
- beruehrungsspannung
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Spannung und Strom verwechseln.

## Mini-Beispiel
Fehler im Geraet -> Gehaeuse unter Spannung, Schutz schaltet ab.

## Frage
Welche Aussagen sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Beruehrungsspannung ist eine Spannung, die bei Beruehrung an Teilen anliegen kann.
- B) Schutzmassnahmen zielen darauf ab, gefaehrliche Beruehrungsspannung zu vermeiden/reduzieren.
- C) Beruehrungsspannung ist nur in der Theorie.
- D) PE/RCD/PA koennen helfen Risiken zu reduzieren.
- E) Beruehrungsspannung ist gleich Strom.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Definition; Schutzmassnahmen; PE/RCD/PA helfen. Nicht nur Theorie, nicht gleich Strom.
