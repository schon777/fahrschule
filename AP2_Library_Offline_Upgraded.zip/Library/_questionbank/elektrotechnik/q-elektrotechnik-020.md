---
title: 'Question ele-020: Schutz durch Abschaltung'
tags:
- questionbank
- elektrotechnik
- schutz-durch-abschaltung
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Messwerte nicht verbinden.

## Mini-Beispiel
Im TN-Netz: LS/RCD loesen bei Fehler aus.

## Frage
Welche Aussagen sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Schnelle Abschaltung im Fehlerfall ist ein Schutzprinzip.
- B) RCD kann Abschaltung bei Fehlerstrom bewirken.
- C) Isolationswiderstand misst Abschaltzeit.
- D) Schleifenimpedanz beeinflusst Fehlerstrom und damit Ausloesung.
- E) Schutz durch Abschaltung ist nur bei DC moeglich.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Abschaltung; RCD; Schleifenimpedanz beeinflusst. Isolation misst nicht Abschaltzeit; nicht nur DC.
