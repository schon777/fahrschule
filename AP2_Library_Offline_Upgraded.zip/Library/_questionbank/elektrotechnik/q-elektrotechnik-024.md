---
title: 'Question ele-024: Multimeter'
tags:
- questionbank
- elektrotechnik
- multimeter
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Strom parallel messen -> Kurzschlussrisiko.

## Mini-Beispiel
Strom messen: Messgeraet in Reihe einschleifen.

## Frage
Welche Aussagen zum Multimeter-Einsatz sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Messbereich/Funktion vor Messung pruefen.
- B) Richtige Buchsen (COM, V, A) nutzen.
- C) Strommessung erfolgt parallel zur Last.
- D) Spannungsmessung erfolgt parallel.
- E) Falsche Einstellung kann Geraet/Sicherung beschaedigen.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Bereich/Funktion; Buchsen; Spannung parallel; Strom nicht parallel (typisch in Reihe). Fehler kann Schaden verursachen.
