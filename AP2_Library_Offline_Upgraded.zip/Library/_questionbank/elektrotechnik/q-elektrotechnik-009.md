---
title: 'Question ele-009: EMV'
tags:
- questionbank
- elektrotechnik
- emv
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: elektrotechnik. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Schirmung ohne Anschluss bringt alles.

## Mini-Beispiel
Motorumrichter stoert Ethernet -> geschirmtes Kabel + korrekter Anschluss.

## Frage
Welche Aussagen zu EMV sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Schirmung kann Stoereinfluesse reduzieren.
- B) Verdrillung reduziert Stoerungen in Paaren.
- C) EMV ist nur fuer Hochspannung relevant.
- D) Saubere Erdung/Schirmanschluss ist wichtig.
- E) EMV hat keinen Einfluss auf Datenkommunikation.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Schirmung, Verdrillung, Erdung/Schirmanschluss. EMV betrifft auch Datenkommunikation.
