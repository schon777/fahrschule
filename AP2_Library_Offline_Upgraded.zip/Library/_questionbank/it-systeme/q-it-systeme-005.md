---
title: 'Question it--005: RAID Levels'
tags:
- questionbank
- it-systeme
- raid-levels
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- RAID als Backup ansehen.

## Mini-Beispiel
Server: RAID1 fuer OS, separate Backupstrategie.

## Frage
Welche Aussagen sind allgemein korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) RAID 1 spiegelt Daten.
- B) RAID 0 bietet keine Redundanz.
- C) RAID ersetzt Backup.
- D) RAID kann Verfuegbarkeit verbessern.
- E) RAID 5/6 nutzen Paritaet (konzeptuell).

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: RAID1 Spiegel, RAID0 keine Redundanz, RAID verbessert Verfuegbarkeit, RAID5/6 Paritaet. RAID ersetzt kein Backup.
