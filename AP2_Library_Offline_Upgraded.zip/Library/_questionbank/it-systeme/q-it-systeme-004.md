---
title: 'Question it--004: 3-2-1'
tags:
- questionbank
- it-systeme
- 3-2-1
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- RAID mit Backup verwechseln.

## Mini-Beispiel
NAS + Band/USB + Cloud/Offsite.

## Frage
Welche Aussagen zur 3-2-1 Backup Regel sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) 3 Kopien
- B) 2 verschiedene Medien/Typen
- C) 1 Offsite
- D) 1 Kopie muss im gleichen Rack sein
- E) 3-2-1 ist eine Strategie, kein Produkt

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: 3/2/1 und Strategie. Nicht 'gleiches Rack'.
