---
title: 'Question it--019: Hardening'
tags:
- questionbank
- it-systeme
- hardening
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Hardening als Ersatz fuer Updates.

## Mini-Beispiel
Server nur mit noetigen Ports offen.

## Frage
Welche Aussagen zu System-Hardening sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Unnoetige Dienste deaktivieren.
- B) Default Passwoerter aendern.
- C) Prinzip der minimalen Rechte anwenden.
- D) Hardening macht Updates unnoetig.
- E) Firewall-Regeln restriktiv planen.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Dienste reduzieren; defaults aendern; least privilege; firewall. Updates bleiben noetig.
