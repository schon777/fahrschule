---
title: 'Question it--002: VM vs Container'
tags:
- questionbank
- it-systeme
- vm-vs-container
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Container als Sicherheitsgarantie sehen.

## Mini-Beispiel
Docker Container fuer Dienst, VM fuer isolierte Umgebung.

## Frage
Welche Aussagen zu VMs und Containern sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) VMs virtualisieren Hardware, Container teilen sich den Kernel (typisch).
- B) Container starten oft schneller als VMs.
- C) Container bieten automatisch vollstndige Isolation wie eigene Hardware.
- D) VMs brauchen meist mehr Overhead als Container.
- E) Container ersetzen immer Backup.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Kernel-sharing; schneller; weniger Overhead. Isolation nicht automatisch wie Hardware; Backup bleibt Thema.
