---
title: 'Question it--009: Permissions'
tags:
- questionbank
- it-systeme
- permissions
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Rechte wild pro User vergeben.

## Mini-Beispiel
Mitarbeitergruppe bekommt nur Leserechte auf Share.

## Frage
Welche Aussagen zu Berechtigungen sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Least Privilege ist ein Sicherheitsprinzip.
- B) Berechtigungen sollten Rollen/Groups nutzen.
- C) Admin-Rechte fuer alle sind sicher.
- D) Rechte sollten dokumentiert werden.
- E) Audit/Logging kann wichtig sein.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: least privilege; groups/rollen; dokumentieren; audit. Admin fuer alle ist unsicher.
