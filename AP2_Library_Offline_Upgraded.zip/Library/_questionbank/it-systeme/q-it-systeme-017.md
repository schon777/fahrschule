---
title: 'Question it--017: DHCP Scope'
tags:
- questionbank
- it-systeme
- dhcp-scope
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Scope und VLAN gleichsetzen.

## Mini-Beispiel
Drucker reserviert feste IP per MAC.

## Frage
Welche Aussagen zu DHCP Scopes sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Scope definiert Pool/Optionen fuer ein Subnetz.
- B) Reservierungen koennen fixe IP per MAC liefern.
- C) Wenn Pool leer ist, bekommen Clients keine Lease.
- D) DHCP Scope ist ein VLAN.
- E) Gateway/DNS koennen als Option verteilt werden.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: scope pool/options; reservations; pool leer -> keine lease; Optionen wie GW/DNS. Scope ist nicht VLAN.
