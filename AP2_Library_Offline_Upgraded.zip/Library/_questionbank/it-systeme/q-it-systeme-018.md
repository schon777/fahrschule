---
title: 'Question it--018: Access Control'
tags:
- questionbank
- it-systeme
- access-control
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Rechte ohne Rollen.

## Mini-Beispiel
Helpdesk Rolle: Reset Password, keine Server Adminrechte.

## Frage
Welche Aussagen zu RBAC sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) RBAC = Role Based Access Control.
- B) Rollen vereinfachen Rechteverwaltung.
- C) RBAC bedeutet, jeder ist Admin.
- D) Rollen sollten zu Aufgaben passen.
- E) Audit hilft Missbrauch zu erkennen.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: role-based; vereinfachen; rollen passend; audit. Nicht admin fuer alle.
