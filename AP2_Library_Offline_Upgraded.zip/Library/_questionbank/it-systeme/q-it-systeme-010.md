---
title: 'Question it--010: Patch Management'
tags:
- questionbank
- it-systeme
- patch-management
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Patchen ohne Plan.

## Mini-Beispiel
Server Update im Wartungsfenster, Snapshot vorher.

## Frage
Welche Aussagen sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Updates schliessen Sicherheitsluecken.
- B) Patchen kann Ausfaelle verursachen, daher braucht man Planung/Testing.
- C) Patchen ist nur fuer Clients wichtig.
- D) Wartungsfenster und Rollback-Plan sind sinnvoll.
- E) Ohne Updates ist man immer sicher.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: schliessen Luecken; Planung/Testing; Wartungsfenster/Rollback. Nicht nur Clients und ohne Updates nicht sicher.
