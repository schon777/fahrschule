---
title: "Question it--021: AD / Dom\xE4ne"
tags:
- questionbank
- it-systeme
- ad-dom-ne
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Zeit/NTP ignorieren.

## Mini-Beispiel
User login scheitert wenn Zeit stark abweicht.

## Frage
Welche Aussagen zu Windows Domnen/AD sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) AD nutzt DNS stark.
- B) Group Policies koennen zentrale Einstellungen verteilen.
- C) Domne bedeutet immer Internet.
- D) Domnenkonten koennen zentral verwaltet werden.
- E) Zeit (NTP) kann wichtig sein fuer Auth.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: DNS; GPO; zentral; Zeit wichtig. Domne ist nicht gleich Internet.
