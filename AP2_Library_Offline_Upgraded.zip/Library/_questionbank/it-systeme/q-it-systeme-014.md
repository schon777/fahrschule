---
title: 'Question it--014: Snapshots'
tags:
- questionbank
- it-systeme
- snapshots
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Snapshot als einziges Backup.

## Mini-Beispiel
ZFS Snapshot vor Update.

## Frage
Welche Aussagen zu Snapshots sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Snapshots sind Punkt-in-Zeit Abbilder (konzeptuell).
- B) Sie koennen schnelle Wiederherstellung ermoeglichen.
- C) Snapshots ersetzen Offsite-Backups immer.
- D) Aufbewahrung/Retention muss geplant werden.
- E) Snapshots koennen bei Ransomware helfen, wenn korrekt geschuetzt.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Punkt-in-Zeit; schnelle Restore; retention planen; koennen helfen. Ersetzen Offsite nicht immer.
