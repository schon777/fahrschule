---
title: 'Question it--028: Change Management'
tags:
- questionbank
- it-systeme
- change-management
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Ohne Rollback updaten.

## Mini-Beispiel
Switch-Firmware Update nach Plan.

## Frage
Welche Aussagen zu Change Management sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Aenderungen sollten dokumentiert werden.
- B) Rollback-Plan ist sinnvoll.
- C) Changes sollten immer spontan passieren.
- D) Risikoanalyse/Impact kann wichtig sein.
- E) Maintenance Window kann Ausfall minimieren.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: dokument; rollback; risiko; maintenance. Spontan ist schlecht.
