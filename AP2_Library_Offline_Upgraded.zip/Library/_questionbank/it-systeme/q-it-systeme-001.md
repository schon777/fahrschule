---
title: 'Question it--001: Hypervisor Typen'
tags:
- questionbank
- it-systeme
- hypervisor-typen
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Container und VM vermischen.

## Mini-Beispiel
Beispiel: ESXi (Typ-1), VirtualBox (Typ-2).

## Frage
Welche Aussagen zu Hypervisoren sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Typ-1 Hypervisor laeuft direkt auf Hardware (bare metal).
- B) Typ-2 Hypervisor laeuft auf einem Host-OS.
- C) Typ-1 ist immer langsamer als Typ-2.
- D) Beide koennen virtuelle Maschinen bereitstellen.
- E) Container sind dasselbe wie Hypervisor.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Typ-1 bare metal, Typ-2 auf Host-OS, beide fuer VMs. Typ-1 ist nicht pauschal langsamer. Container sind nicht dasselbe wie Hypervisor.
