---
title: 'Question it--023: Virtual Snapshots'
tags:
- questionbank
- it-systeme
- virtual-snapshots
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Snapshots wie Backup behandeln.

## Mini-Beispiel
Snapshot vor Patch, danach loeschen/commit.

## Frage
Welche Aussagen zu VM-Snapshots sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) VM-Snapshots sind nicht dasselbe wie langfristiges Backup.
- B) Zu viele/lange Snapshots koennen Performance/Storage belasten.
- C) Snapshots koennen vor Updates hilfreich sein.
- D) Snapshots brauchen keinen Speicher.
- E) Snapshots ersetzen Offsite.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: nicht gleich Backup; koennen belasten; hilfreich vor Updates. Brauchen Speicher und ersetzen Offsite nicht.
