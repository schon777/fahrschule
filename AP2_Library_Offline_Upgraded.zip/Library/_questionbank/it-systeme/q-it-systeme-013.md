---
title: 'Question it--013: Filesystem'
tags:
- questionbank
- it-systeme
- filesystem
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- ZFS als Bildformat sehen.

## Mini-Beispiel
Backupdisk als exFAT/FAT/NTFS je nach Bedarf.

## Frage
Welche Aussagen zu Dateisystemen sind allgemein korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) NTFS ist typisch fuer Windows.
- B) ext4 ist typisch fuer Linux.
- C) FAT32 hat Beschraenkungen (z.B. Dateigroesse).
- D) ZFS ist ein Grafikformat.
- E) Dateisystemwahl kann Features wie Snapshots beeinflussen.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: NTFS Windows; ext4 Linux; FAT32 Limits; Dateisystemwahl beeinflusst Features. ZFS ist kein Grafikformat.
