---
title: 'Question it--029: Incident Response'
tags:
- questionbank
- it-systeme
- incident-response
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Nur technisch fixen, nichts lernen.

## Mini-Beispiel
Ransomware: isolate, assess, restore, improve.

## Frage
Welche Aussagen sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Incident Response umfasst Erkennen, Eindmmen, Beheben, Lernen.
- B) Kommunikation/Verantwortlichkeiten sind Teil davon.
- C) IR ist nur ein Tool.
- D) Logs/Forensik koennen helfen.
- E) Nachbereitung (Lessons Learned) ist sinnvoll.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Prozess; Kommunikation; Logs; Lessons Learned. Nicht nur Tool.
