---
title: 'Question it--020: TLS'
tags:
- questionbank
- it-systeme
- tls
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- TLS als Segmentierung betrachten.

## Mini-Beispiel
Web-Admin via HTTPS mit gueltigem Zertifikat.

## Frage
Welche Aussagen zu TLS sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) TLS kann Transport verschluesseln (z.B. HTTPS).
- B) Zertifikate dienen zur Identitaetspruefung.
- C) TLS ist ein Dateisystem.
- D) Ohne korrekte Zertifikate drohen MITM-Risiken.
- E) TLS ersetzt Netzwerksegmentierung.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: TLS verschluesselt; Zertifikate; Risiko bei falschen Zertifikaten. Kein Dateisystem und ersetzt Segmentierung nicht.
