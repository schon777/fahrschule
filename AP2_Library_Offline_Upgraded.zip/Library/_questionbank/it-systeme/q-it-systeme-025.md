---
title: 'Question it--025: Cloud vs On-Prem'
tags:
- questionbank
- it-systeme
- cloud-vs-on-prem
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Kosten pauschal annehmen.

## Mini-Beispiel
Kritische Daten on-prem, Mail in Cloud (Begruendung).

## Frage
Welche Aussagen sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Cloud kann Skalierung vereinfachen, bringt aber Abhaengigkeiten.
- B) On-Prem gibt mehr Kontrolle, aber mehr Betriebslast.
- C) Cloud ist immer billiger.
- D) Datenschutz/Compliance kann Entscheidung beeinflussen.
- E) Hybrid ist moeglich.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: tradeoffs; compliance; hybrid. Cloud nicht immer billiger.
