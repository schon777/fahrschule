---
title: 'Question it--024: Restore Plan'
tags:
- questionbank
- it-systeme
- restore-plan
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- DR Plan nur technisch schreiben.

## Mini-Beispiel
Ransomware: immutable backups nutzen, Restore testen.

## Frage
Welche Aussagen zu Restore/DR Plan sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) RTO/RPO definieren Ziele fuer Wiederherstellung.
- B) Restore-Prozesse sollten dokumentiert und getestet werden.
- C) Backup ohne Restore-Test ist ausreichend.
- D) Offsite/Immutable kann gegen Ransomware helfen.
- E) DR Plan sollte Rollen/Kommunikation enthalten.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: RTO/RPO; dokument/test; offsite/immutable hilft; Rollen/Kommunikation. Ohne Test nicht ausreichend.
