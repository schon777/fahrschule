---
title: 'Question it--030: Immutable Backup'
tags:
- questionbank
- it-systeme
- immutable-backup
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Immutable als Allheilmittel sehen.

## Mini-Beispiel
Backupziel mit Object Lock/Immutable Policies, Restore testen.

## Frage
Welche Aussagen zu immutable/Write-Once Backups sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Immutable Backups sollen nach dem Schreiben nicht leicht veraenderbar sein.
- B) Sie koennen gegen Ransomware helfen.
- C) Immutable bedeutet, dass Restore unnoetig ist.
- D) Retention/Policies bestimmen die Dauer der Unveraenderbarkeit.
- E) Immutable ersetzt Netzwerksegmentierung komplett.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: unveraenderbar nach Schreiben; hilft gegen Ransomware; retention bestimmt Dauer. Restore bleibt wichtig. Ersetzt Segmentierung nicht.
