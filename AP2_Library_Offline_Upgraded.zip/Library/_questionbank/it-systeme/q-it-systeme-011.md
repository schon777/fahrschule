---
title: 'Question it--011: Logging'
tags:
- questionbank
- it-systeme
- logging
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Logs sammeln aber nie auswerten.

## Mini-Beispiel
Syslog/SIEM sammelt Events von Servern und Switches.

## Frage
Welche Aussagen zu Logs sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Logs helfen bei Troubleshooting und Security.
- B) Zentralisiertes Logging kann Vorteile bringen.
- C) Logs ersetzen Backups.
- D) Zeitstempel/Zeitsynchronisation ist wichtig.
- E) Zu viele Logs ohne Filter erzeugen Rauschen.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: troubleshooting/security; zentral; Zeit; Filter. Logs ersetzen kein Backup.
