---
title: 'Question it--022: Redundanz'
tags:
- questionbank
- it-systeme
- redundanz
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Redundanz ohne Test.

## Mini-Beispiel
Zwei Netzteile, zwei Uplinks, aber nur ein Switch -> SPoF bleibt.

## Frage
Welche Aussagen zu Redundanz sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Redundanz erhoeht Verfuegbarkeit.
- B) Redundanz ersetzt Backups.
- C) Redundanz kann Kosten/Komplexitaet erhoehen.
- D) Failover muss getestet werden.
- E) Single Point of Failure identifizieren ist sinnvoll.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: Verfuegbarkeit; Kosten/Komplex; testen; SPoF identifizieren. Ersetzt Backup nicht.
