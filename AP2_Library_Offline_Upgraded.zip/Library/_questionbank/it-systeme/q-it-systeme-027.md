---
title: 'Question it--027: Service Account'
tags:
- questionbank
- it-systeme
- service-account
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Service Accounts fuer alles nutzen.

## Mini-Beispiel
Backup-Job nutzt eigenen Account mit Schreibrechten aufs Ziel.

## Frage
Welche Aussagen zu Service Accounts sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Sollten minimale Rechte haben.
- B) Passwoerter/Keys sollten sicher verwaltet werden.
- C) Service Accounts sollten fuer menschliches Login genutzt werden.
- D) Rotation kann sinnvoll sein.
- E) Audit/Monitoring ist wichtig.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: least privilege; secure storage; rotation; audit. Nicht fuer menschliches Login.
