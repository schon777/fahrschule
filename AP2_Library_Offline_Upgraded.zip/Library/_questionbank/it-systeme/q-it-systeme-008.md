---
title: 'Question it--008: iSCSI'
tags:
- questionbank
- it-systeme
- iscsi
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- iSCSI als File-Share behandeln.

## Mini-Beispiel
VM-Host bindet iSCSI LUN als Disk ein.

## Frage
Welche Aussagen zu iSCSI sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) iSCSI transportiert SCSI-Befehle ueber IP-Netze.
- B) iSCSI ist Blockspeicher.
- C) iSCSI ist gleich SMB.
- D) iSCSI kann eigene VLANs/Netze fuer Performance/Sicherheit nutzen.
- E) MTU/Jumbo Frames koennen relevant sein, muessen aber Ende-zu-Ende passen.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: SCSI ueber IP; Block; getrennte Netze; MTU kann relevant. iSCSI != SMB.
