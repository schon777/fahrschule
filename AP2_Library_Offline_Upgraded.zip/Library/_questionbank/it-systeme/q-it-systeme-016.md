---
title: 'Question it--016: DNS im Netzwerk'
tags:
- questionbank
- it-systeme
- dns-im-netzwerk
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- DNS als unwichtig abtun.

## Mini-Beispiel
Zwei DNS Server im DHCP verteilen.

## Frage
Welche Aussagen zu DNS-Server Betrieb sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) DNS braucht stabile IP/Erreichbarkeit.
- B) Split DNS kann fuer VPN/Intern genutzt werden.
- C) DNS ist egal fuer AD/Windows Domnen.
- D) Redundanz (zweiter DNS) ist oft sinnvoll.
- E) DNS-Fehler kann viele Dienste lahmlegen.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: stabile IP; split DNS; Redundanz; DNS kritisch. AD ist sehr DNS-abhaengig.
