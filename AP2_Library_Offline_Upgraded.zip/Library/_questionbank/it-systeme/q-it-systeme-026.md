---
title: 'Question it--026: Version Control'
tags:
- questionbank
- it-systeme
- version-control
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Git als Backup missverstehen.

## Mini-Beispiel
Konfig-Dateien versionieren.

## Frage
Welche Aussagen zu Versionsverwaltung (z.B. Git) sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Hilft bei Nachvollziehbarkeit von Aenderungen.
- B) Unterstuetzt Zusammenarbeit.
- C) Ersetzt Backups komplett.
- D) Branches koennen parallele Entwicklung erlauben.
- E) Commit Messages sollten sinnvoll sein.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: nachvollziehbar; collaboration; branches; commit messages. Ersetzt Backups nicht.
