---
title: 'Question it--012: Monitoring'
tags:
- questionbank
- it-systeme
- monitoring
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Alles monitoren ohne Prioritaet.

## Mini-Beispiel
CPU/RAM/Disk + Service Checks.

## Frage
Welche Aussagen zu Monitoring sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) Monitoring erkennt Performance- und Ausfallprobleme frueh.
- B) Alerts sollten Schwellenwerte/Baselines nutzen.
- C) Monitoring ersetzt Dokumentation.
- D) Health Checks und Metriken sind hilfreich.
- E) Ohne Alert-Routing bleibt es wirkungslos.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: frueh erkennen; Schwellen/Baselines; Metriken; alert routing. Monitoring ersetzt Doku nicht.
