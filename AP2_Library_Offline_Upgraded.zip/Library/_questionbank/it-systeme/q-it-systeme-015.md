---
title: 'Question it--015: Virtual Switch'
tags:
- questionbank
- it-systeme
- virtual-switch
priority: P2
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: questionbank
topic_area: it-systeme
---
## Kontext & Grundlagen (Voraussetzungen)
Thema: it-systeme. Mehrfachangabe: Mehrere Antworten koennen korrekt sein.

## Pruefungsnahe Anwendung
Beantworte die Frage kurz und begruende in 1-2 Saetzen, wenn es in AP2 verlangt wird.

## Typische Fehler & Stolperfallen
- Uplinks/Tags vergessen.

## Mini-Beispiel
VM in VLAN10 ueber Portgroup.

## Frage
Welche Aussagen zu virtuellen Switches (vSwitch) sind korrekt (Mehrfachangabe)?

## Optionen (neutral, Mehrfachangabe)
- A) vSwitch verbindet VMs virtuell (L2 Konzept).
- B) Portgroups/VLANs koennen genutzt werden.
- C) vSwitch ersetzt physische Switches immer.
- D) Uplinks verbinden vSwitch mit physischem Netzwerk.
- E) Fehlkonfiguration kann Isolation brechen.

## Loesung (Klartext, nicht markieren in Optionen)
Richtig: verbindet VMs; VLANs; uplinks; Fehlconfig. Ersetzt nicht immer physisch.
