---
title: Template Entscheidungsbegruendung
tags:
- template
- begruendung
- entscheidung
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: template
topic_area: pruefung
---
## Kontext & Grundlagen (Voraussetzungen)
In AP2 gibt es Punkte fuer Begruendung (Kosten, Sicherheit, Verfuegbarkeit, Wartbarkeit, Skalierung).

## Pruefungsnahe Anwendung
Nutze 4-6 kurze Bulletpoints und beziehe dich auf Anforderungen der Aufgabe.

## Typische Fehler & Stolperfallen
- Nur "weil besser" statt nachvollziehbarer Kriterien.
- Keine Alternative erwaehnt.

## Mini-Beispiel
"NAS statt SAN": Budget + Einfachheit + ausreichend Performance + Wartbarkeit.

## Template
- Entscheidung:
- Anforderungen aus Aufgabe:
- Alternative(n):
- Kriterien:
  * Kosten:
  * Sicherheit:
  * Verfuegbarkeit:
  * Wartbarkeit:
  * Skalierung:
- Fazit:
