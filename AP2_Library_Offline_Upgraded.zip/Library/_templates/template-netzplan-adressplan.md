---
title: Template Netzplan/Adressplan
tags:
- template
- netzplan
- adressplan
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: template
topic_area: pruefung
---
## Kontext & Grundlagen (Voraussetzungen)
Netzplan/Adressplan sind typische Doku-Bestandteile in AP2.

## Pruefungsnahe Anwendung
Zeige Segmentierung, IP-Bereiche, Gateways, Dienste. Halte es einfach und lesbar.

## Typische Fehler & Stolperfallen
- VLAN-IDs fehlen oder IP-Subnetze passen nicht zu Segmenten.
- Kein Gateway/DNS angegeben.

## Mini-Beispiel
VLAN10 Office: 192.168.10.0/24, GW .1, DHCP Bereich .50-.200, DNS: 192.168.10.2

## Template
- Standort/Teilnetz:
- VLAN-ID + Name:
- Subnetz (CIDR):
- Gateway:
- DHCP (ja/nein, Bereich):
- DNS:
- Besondere Regeln (ACL/QoS):
- Notizen:
