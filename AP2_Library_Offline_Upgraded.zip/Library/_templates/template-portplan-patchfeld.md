---
title: Template Portplan/Patchfeld
tags:
- template
- portplan
- patchfeld
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: template
topic_area: pruefung
---
## Kontext & Grundlagen (Voraussetzungen)
Portplan/Patchfeldplan fuer strukturierte Verkabelung.

## Pruefungsnahe Anwendung
In AP2: eindeutige Zuordnung von Dose <-> Patchfeld <-> Switchport <-> VLAN.

## Typische Fehler & Stolperfallen
- Portnummern werden nicht konsistent dokumentiert.
- VLAN/PoE Bedarf fehlt.

## Mini-Beispiel
Dose A1 -> Patchfeld 01 -> Switch Gi1/0/1 -> VLAN 10 -> PoE: nein

## Template
- Dose/Ort:
- Patchfeld-Port:
- Switch/Port:
- VLAN:
- PoE (ja/nein):
- Geraet (z.B. PC, Telefon, AP):
- Notizen:
