---
title: Template Fehleranalyse
tags:
- template
- stoerung
- doku
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: template
topic_area: pruefung
---
## Kontext & Grundlagen (Voraussetzungen)
Nutze dieses Template fuer Stoerungsanalyse in AP2 (systematisch, nachvollziehbar, messbar).

## Pruefungsnahe Anwendung
Fuelle die Felder kurz und sachlich aus. Zeige: Symptom -> Hypothese -> Test -> Ergebnis -> Massnahme.

## Typische Fehler & Stolperfallen
- Sofort Loesung raten ohne Messung.
- Keine klare Abgrenzung (Layer/Komponente) -> Zeitverlust.

## Mini-Beispiel
Symptom: "Kein Internet" -> Test: IP, Gateway, DNS -> Ergebnis dokumentieren.

## Template
- Problem/Symptom:
- Umfeld (Ort, Zeitpunkt, betroffene Systeme):
- Erwartetes Verhalten:
- Ist-Zustand:
- Erste Eingrenzung (Layer: L1/L2/L3/Dienst):
- Hypothesen (Liste):
- Tests/Messungen (Was? Wie? Erwartung? Ergebnis?):
- Ursache:
- Massnahme/Fix:
- Verifikation (Nachtest):
- Praevention (wie vermeiden):
