---
title: USV (Unterbrechungsfreie Stromversorgung) - Zweck, Typen, Auswahl
tags:
- elektrotechnik
- energieversorgung
- usv
- stromversorgung
- it-infrastruktur
priority: P2
exam_relevance: mittel
sources:
- internal:Elektrotechnik/Allgemeines/USV_Praesentation_AT_PL_Komprimiert.pptx
- internal:IT/Ernstmeier/Datenschutz und Datensicherheit USV/USV.pptx
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
USVs tauchen in ITSE-Kontexten haeufig auf (Serverraum, Netzwerkschraenke, Verfuegbarkeit). Voraussetzungen:
- [[leistung-energie-drehstrom-cosphi|Leistungsberechnung]] (VA/W, cosphi)
- Grundidee Batterie/Energiespeicher (siehe [[batterie|Batterie]])
- Verfuegbarkeit (siehe [[cia-triad-datenschutz-datensicherheit|CIA/Verfuegbarkeit]])

## Definition und Zweck
Eine **USV** ueberbrueckt Stromausfaelle und stabilisiert die Versorgung, damit IT-Systeme kontrolliert weiterlaufen oder sauber herunterfahren koennen. Ziele:
- **Verfuegbarkeit** erhoehen
- **Datenverlust** vermeiden
- Schutz vor Spannungseinbruechen/Spikes (je nach Typ)

## Typen (Grundidee)
- **Offline/Standby**: schaltet bei Ausfall um (kurze Umschaltzeit).
- **Line-Interactive**: Spannungsregelung + Batterieunterstuetzung.
- **Online/Doppelwandler**: dauerhaft ueber Umrichter, beste Qualitaet, teurer.

In Pruefungen reicht meist die Unterscheidung nach Umschaltzeit" und Versorgungsqualitaet".

## Auswahl in Aufgaben (pruefungsnah)
- Leistungsbedarf (W/VA) und Reserve
- gewuenschte Ueberbrueckungszeit (Minuten)
- Anzahl Ausgaenge/Lastverteilung
- Wartung: Batterietausch, Test, Alarmierung

## Typische Fehler & Stolperfallen
- VA und W gleichsetzen (bei cosphi relevant).
- Keine Reserve einplanen.
- Batteriekapazitaet/Alterung ignorieren.

## Checkliste (Kurz)
- Last in W/VA ermitteln.
- Typ passend zum Bedarf.
- Ueberbrueckungszeit definieren.
- Wartung/Monitoring beruecksichtigen.

## Siehe auch
- [[leistung-energie-drehstrom-cosphi|Leistung & cosphi]]
- [[batterie|Batterie]]
- [[cia-triad-datenschutz-datensicherheit|Verfuegbarkeit]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
