---
title: Leitungsdimensionierung - Querschnitt, Verlegeart, Spannungsfall (AP2-Schema)
tags:
- elektrotechnik
- energieversorgung
- querschnitt
- spannungsfall
- verlegeart
- dimensionierung
- ap2
priority: P1+P2
exam_relevance: hoch
sources:
- internal:KI Ergebnisse/AP2_2026_ITSE_Elektrotechnik_Lernskript (1).docx
- internal:KI Ergebnisse/AP2_2026_ITSE_ET_Themencheckliste.md
- internal:Elektrotechnik/Allgemeines/Praesentationsthemen.txt
- internal:Altklausur-Muster (aus Lernskript)
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Das ist einer der klassischen AP2-Kerne: Aus Leistung/Netzform den Strom berechnen und daraus **Absicherung**, **Leitungstyp** und **Querschnitt** ableiten - plus **Spannungsfall**. Voraussetzungen:
- [[leistung-energie-drehstrom-cosphi|Leistungsberechnung 1~/3~]]
- Grundidee LS/Sicherung (In) und Strombelastbarkeit (Iz)
- Tabellenarbeit (Belegsatz): Verlegearten, belastete Adern, Korrekturfaktoren

## Standard-Loesungsschema (pruefungsnah)
1) **Netzart klaeren**: 1~ 230 V oder 3~ 400 V  
2) **Betriebsstrom Ib berechnen** (mit cosphi, falls gegeben)  
3) **Schutzeinrichtung waehlen**: In >= Ib  
4) **Leitung waehlen**: Iz >= In (unter Beruecksichtigung von Verlegeart, belasteten Adern, Haeufung, Temperatur)  
5) **Spannungsfall pruefen**: DeltaU in V und in % angeben  
6) **Dokumentation**: Leitungstyp (z.B. NYM-J/NYY-J), Querschnitt, Laenge, Absicherung, Verlegeart

## Spannungsfall (Grundidee)
Der Spannungsfall ist die Spannungsdifferenz zwischen Einspeisung und Last. In Aufgaben wird oft ein maximaler Prozentwert erwartet (z.B. nicht mehr als ... %" - abhaengig vom Kontext in der Aufgabe).
Typischer Ablauf:
- Tabellen-/Formelwert je Leiterquerschnitt und Laenge nutzen
- DeltaU berechnen und als % von U angeben

## Pruefungsnahe Anwendung: Typische Entscheidungen (Beispiele)
- **Leitungstyp**: NYM-J im Gebaeude, NYY-J im Erdreich, H07RN-F fuer flexible/robuste Anwendung (wenn Aufgabe das nahelegt).
- **Aderbelegung**: L1/L2/L3, N, PE; bei Drehstrom oft 5-adrig.
- **Verlegeart**: beeinflusst Iz stark -> in Pruefungen immer aus Aufgabe/Belegsatz ableiten.

## Typische Fehler & Stolperfallen
- Korrekturfaktoren ignorieren (Haeufung/Temperatur).
- Falsche Anzahl belasteter Adern gewaehlt.
- Spannungsfall nicht als Prozent angegeben.
- In/Iz/Ib durcheinander.

## Checkliste (Kurz)
- Netzart? Spannung korrekt?
- Ib sauber gerechnet?
- In gewaehlt und begruendet?
- Iz mit Verlegeart/Korrektur?
- Spannungsfall ok?

## Siehe auch
- [[ls-leitungsschutzschalter|LS]]
- [[pruefung-nach-vde-0100-600|VDE-Pruefung]]
- [[installationszonen|Installationszonen]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
