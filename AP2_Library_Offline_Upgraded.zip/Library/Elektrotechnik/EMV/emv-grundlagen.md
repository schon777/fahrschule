---
title: EMV - elektromagnetische Vertraeglichkeit (Grundidee, typische Massnahmen)
tags:
- elektrotechnik
- emv
- grundlagen
- abschirmung
- filter
priority: P2
exam_relevance: niedrig
sources:
- internal:Elektrotechnik/Allgemeines/Praesentationsthemen.txt
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
EMV kann in AP2 als Randthema vorkommen (z.B. Serverraum, Leitungsfuehrung, Filter). Meist reicht ein solides Grundverstaendnis:
- Stoerungen entstehen durch schnelle Strom-/Spannungsaenderungen
- Leitungen wirken wie Antennen (Einstrahlung/Abstrahlung)

## Definition und Zweck
**EMV** bedeutet: Geraete sollen so konstruiert/aufgebaut sein, dass sie
1) andere Geraete nicht unzulaessig stoeren (Emission) und
2) selbst ausreichend stoerfest sind (Immunitaet).

## Typische Stoerquellen (Beispiele)
- Schaltnetzteile, Umrichter, Motoren
- lange Leitungen, unsaubere Erdung/PA
- fehlende Schirmung bei Datenleitungen

## Typische Massnahmen (pruefungsnah)
- **Schirmung** (z.B. geschirmte Leitungen, korrekt aufgelegt)
- **Filter** (z.B. Kondensatoren/Spulen in Netzfiltern)
- **Potentialausgleich** / Erdung (saubere Bezugsebene)
- **Trennung** von Leistungs- und Datenleitungen, richtige Verlegewege
- **Twisted Pair** / korrekte Patchkabel im Netzwerk

## Typische Fehler & Stolperfallen
- Schirm nur irgendwie" anschliessen: Schirm wirkt nur korrekt bei richtiger Auflegung/PA-Konzept.
- Leistungs- und Datenkabel parallel auf langer Strecke fuehren.

## Siehe auch
- [[erdung-potentialausgleich|Erdung/PA]]
- [[kondensator|Kondensator]]
- [[spule|Spule]]
- [[strukturierte-verkabelung|Strukturierte Verkabelung]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
