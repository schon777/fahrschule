---
title: Leitungsschutzschalter (LS) - Aufgabe, Kennlinien B/C/D, Auswahl
tags:
- elektrotechnik
- schutztechnik
- ls
- sicherung
- kurzschluss
- ueberlast
priority: P1+P2
exam_relevance: hoch
sources:
- internal:KI Ergebnisse/AP2_2026_ITSE_ET_Themencheckliste.md
- internal:KI Ergebnisse/AP2_2026_ITSE_Elektrotechnik_Lernskript (1).docx
- internal:Elektrotechnik/Allgemeines/Leitungsschutzschalter_Praesentation_Enrico_Tolga.pptx
- internal:Unterricht
- internal:Altklausur-Muster (aus Lernskript)
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
In AP2 wird haeufig erwartet, dass du Schutzorgane richtig zuordnest und begruendest: Warum LS B16?" oder Was schuetzt der LS, was nicht?". Voraussetzungen:
- Strombelastbarkeit von Leitungen (Iz)
- Ueberlast vs. Kurzschluss
- Grundidee Selektivitaet (wer loest zuerst aus?)

## Definition und Zweck
Der **Leitungsschutzschalter (LS)** schuetzt **Leitungen** vor:
- **Ueberlast** (zu hoher Strom ueber laengere Zeit)
- **Kurzschluss** (sehr hoher Strom, schnelle Abschaltung)

Wichtig: Ein LS ist **kein** Personenschutz (dafuer i.d.R. RCD als Zusatzschutz).

## Kennlinien (B/C/D - Grundidee)
Die Kennlinie beschreibt das Ausloeseverhalten im Kurzschlussbereich (magnetisch):
- **B**: loest bei relativ kleineren Kurzschlussstroemen aus (typisch Haushalt/Steckdosen, wenig Einschaltstrom).
- **C**: toleriert hoehere Einschaltstroeme (z.B. Motoren, Netzteile, IT-Lasten mit Inrush).
- **D**: fuer sehr hohe Einschaltstroeme (Spezialfaelle).

In Pruefungen reicht meist die **Grundidee + typische Anwendung**, nicht die exakten Faktorwerte.

## Auswahl in Aufgaben (typisches Schema)
1) Betriebsstrom **Ib** berechnen (siehe [[leistung-energie-drehstrom-cosphi|Leistungsberechnung]])  
2) LS-Nennstrom **In** so waehlen, dass In >= Ib  
3) Leitung so waehlen, dass **Iz >= In** (Tabelle/Verlegeart)  
4) Abschaltbedingungen/Schleifenimpedanz (je nach Aufgabe) beachten

## Typische Fehler & Stolperfallen
- LS schuetzt **nicht** vor Fehlerstroemen gegen Erde (dafuer RCD).
- In und Iz verwechseln (Iz ist Leitung, In ist Schutzorgan).
- Kennlinie ohne Begruendung waehlen (C ist immer besser") - falsch.

## Checkliste (Kurz)
- Welche Last? (Einschaltstrom?)
- Ib berechnet?
- Iz aus Tabelle korrekt?
- RCD zusaetzlich noetig?

## Siehe auch
- [[rcd-fi-fehlerstromschutz|RCD/FI]]
- [[leitungsdimensionierung-querschnitt-spannungsfall|Leitungsdimensionierung]]
- [[selektivitaet-sls|Selektivitaet & SLS]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
