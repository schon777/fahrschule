---
title: Schmelzsicherungen (DIAZED/NEOZED) - Aufgabe, Einsatz, Vor- und Nachteile
tags:
- elektrotechnik
- schutztechnik
- sicherung
- schmelzsicherung
- neozed
- diazed
priority: P2
exam_relevance: mittel
sources:
- internal:Elektrotechnik/Allgemeines/Notizen Schmelzsicherungen.docx
- internal:Elektrotechnik/Allgemeines/Praesentationsthemen.txt
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Schmelzsicherungen sind in Verteilern/Altanlagen verbreitet und werden in Pruefungsaufgaben gern mit LS/RCD verglichen. Voraussetzungen:
- Ueberlast vs. Kurzschluss
- Warum Selektivitaet wichtig ist (siehe [[selektivitaet-sls|Selektivitaet]])

## Definition und Zweck
Eine **Schmelzsicherung** schuetzt Leitungen/Anlagenteile, indem ein Sicherungselement (Schmelzleiter) bei Ueberstrom schmilzt und den Stromkreis trennt.

Typische Systeme:
- **DIAZED (D)**: klassische Schraubsicherung (groesser).
- **NEOZED (D0)**: kompakter, moderner.

## Pruefungsnahe Anwendung: Wo wird sie eingesetzt?
- Vorsicherung in Verteilungen
- Selektive Schutzkonzepte
- Schutz von Teilstromkreisen oder Geraeten (je nach Aufgabe)

## Vor- und Nachteile (pruefungsnah)
Vorteile:
- hohe Abschaltleistung, robust
- gute Selektivitaetseigenschaften in vielen Kombinationen

Nachteile:
- nach Ausloesung **muss** Einsatz getauscht werden
- Gefahr falscher Einsaetze ohne Passschraube (je nach System)
- Diagnose weniger komfortabel als beim LS (kein Hebel")

## Typische Fehler & Stolperfallen
- Sicherung schuetzt Menschen" -> nein, sie schuetzt primaer Leitungen/Anlage.
- Nennstrom und Charakteristik nicht begruenden.
- Austausch ohne Ursachenanalyse (Kurzschluss/Ueberlast muss geklaert werden).

## Checkliste (Kurz)
- Welche Aufgabe: Vorsicherung, Endstromkreis, Geraeteschutz?
- Selektivitaet gegenueber nachgeschaltetem Schutz?
- Richtiger Nennstrom?

## Siehe auch
- [[ls-leitungsschutzschalter|LS]]
- [[selektivitaet-sls|Selektivitaet & SLS]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
