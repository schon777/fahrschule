---
title: Selektivitaet und selektiver Leitungsschutzschalter (SLS) - Prinzip
tags:
- elektrotechnik
- schutztechnik
- selektivitaet
- sls
- verteilung
priority: P1+P2
exam_relevance: mittel
sources:
- internal:KI Ergebnisse/AP2_2026_ITSE_Elektrotechnik_Lernskript (1).docx
- internal:KI Ergebnisse/AP2_2026_ITSE_ET_Themencheckliste.md
- internal:Alte AP2 Pruefungen/2021_22_Winter_IT-System-Elektroniker (KI-Hilfe).docx
- internal:Altklausur-Muster (aus Lernskript)
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
In vielen AP2-Aufgaben wird erwartet, dass du Schutzorgane im Verteilerschrank fachgerecht benennst (z.B. SLS, Hauptschalter, Zaehler) und das Zusammenspiel verstehst. Selektivitaet ist ausserdem wichtig, wenn mehrere Schutzorgane in Reihe sind.

## Definition: Selektivitaet
**Selektivitaet** bedeutet: Bei einem Fehler soll **nur** das Schutzorgan ausloesen, das dem Fehler **am naechsten** liegt - damit der restliche Anlagenteil weiterlaeuft.

Beispielidee:
- Kurzschluss an einem Endstromkreis -> der zugehoerige LS/Sicherung soll ausloesen, nicht die Vorsicherung des ganzen Bereichs.

## SLS (selektiver Leitungsschutzschalter) - Grundidee
Ein **SLS** sitzt typischerweise im Zaehler-/Hausanschlussbereich als Hauptschutzorgan fuer nachgelagerte Bereiche. Er ist so ausgelegt, dass er in Selektivitaetskonzepten mit nachgeschalteten Sicherungen/LS zusammenarbeitet (je nach Aufgabe/Belegsatz).

## Pruefungsnahe Anwendung: Pruefungsrelevante Punkte
- Benennen Sie die Betriebsmittel" (SLS, Hauptschalter, Zaehler, FI/RCD, LS, Ueberspannungsschutz - je nach Bild).
- Begruendung: Warum loest welches Schutzorgan aus?"

## Typische Fehler & Stolperfallen
- Selektivitaet mit Empfindlichkeit" verwechseln (es geht um abgestimmtes Ausloeseverhalten).
- SLS mit Hauptschalter verwechseln (Hauptschalter trennt manuell; SLS ist Schutzorgan).
- Keine Systematik: In Pruefungen hilft die Reihenfolge vom Hausanschluss zum Endstromkreis.

## Checkliste (Kurz)
- Schutzorgane in Reihe identifizieren.
- Ziel: moeglichst kleiner betroffener Bereich.
- Aufgabenhinweise/Belegsatz nutzen.

## Siehe auch
- [[ls-leitungsschutzschalter|LS]]
- [[schmelzsicherungen-neozed-diazed|Schmelzsicherungen]]
- [[komponenten-im-verteilerschrank-benennen|Aufgabentyp: Betriebsmittel benennen]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
