---
title: RCD/FI - Funktionsweise, IDeltan, Typen und Pruefung
tags:
- elektrotechnik
- schutztechnik
- rcd
- fi
- fehlerstrom
- personenschutz
priority: P1+P2
exam_relevance: hoch
sources:
- internal:KI Ergebnisse/AP2_2026_ITSE_ET_Themencheckliste.md
- internal:KI Ergebnisse/AP2_2026_ITSE_Elektrotechnik_Lernskript (1).docx
- internal:Elektrotechnik/Allgemeines/RCD.pdf
- internal:Unterricht
- internal:Altklausur-Muster (aus Lernskript)
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
RCD/FI wird in AP2 sehr oft geprueft: Netzform (TT/TN), Zusatzschutz, Messungen (Ausloesezeit, Ausloesestrom). Voraussetzungen:
- Unterschied Betriebsstrom vs. Fehlerstrom
- PE/N/PEN-Grundlagen (siehe [[netzformen-tn-tt-it|Netzformen]])

## Funktionsprinzip (kurz, pruefungstauglich)
Ein **RCD** misst die Summe der Stroeme in den aktiven Leitern (z.B. L und N).  
- Im Normalfall gilt: **Hin- und Rueckstrom sind gleich** -> Summe = 0.  
- Fliesst ein Teilstrom ueber Erde/PE (z.B. durch Fehler oder Beruehrung), entsteht eine **Differenz** IDelta.  
Ueberschreitet IDelta den Nennfehlerstrom **IDeltan**, schaltet der RCD ab.

## Wichtige Kenngroessen
- **IDeltan**: z.B. **30 mA** (Zusatzschutz/Personenschutz), **300 mA** (Brandschutz in bestimmten Konzepten).
- **Ausloesezeit**: abhaengig vom Typ/Pruefwert (in Aufgaben meist aus Protokoll/Tabelle).
- **Typen (Grundidee)**:
  - Typ **A**: Wechselfehlerstroeme + pulsierende Gleichfehlerstroeme (Standard).
  - Typ **B**: auch glatte Gleichfehlerstroeme (z.B. Frequenzumrichter/EV/USV-Kontexte; nur wenn Aufgabe darauf hindeutet).

## Pruefungsnahe Anwendung: Pruefung/Fehlersuche
- RCD-Testtaste (funktional, aber kein Messersatz)
- Messung mit Pruefgeraet (Ausloesestrom/zeit)
- In TT-Systemen ist RCD haeufig zentrale Schutzmassnahme, weil die Fehlerschleife ueber Erde unguenstiger sein kann.

## Typische Fehler & Stolperfallen
- RCD ersetzt nicht den Basisschutz (Abdeckungen/Isolierung).
- N und PE hinter dem RCD falsch gefuehrt/verbunden -> Fehlfunktionen.
- RCD-Typ ohne Kontext raten": AP2 fragt oft nur Grundprinzip und IDeltan.

## Checkliste (Kurz)
- Wo sitzt der RCD im Stromkreis?
- Welcher IDeltan ist gefordert?
- Netzform beachten (TT vs. TN).
- N/PE sauber getrennt?

## Siehe auch
- [[schutz-gegen-elektrischen-schlag|Schutz gegen elektrischen Schlag]]
- [[pruefung-nach-vde-0100-600|VDE 0100-600 Pruefung]]
- [[netzformen-tn-tt-it|Netzformen]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
