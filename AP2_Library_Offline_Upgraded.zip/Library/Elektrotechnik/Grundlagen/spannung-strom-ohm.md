---
title: Spannung, Strom, Widerstand und Ohmsches Gesetz
tags:
- elektrotechnik
- grundlagen
- ohm
- spannung
- strom
- widerstand
- formeln
priority: P1+P2
exam_relevance: hoch
sources:
- internal:KI Ergebnisse/AP2_2026_ITSE_Elektrotechnik_Lernskript (1).docx
- internal:Elektrotechnik/Grundlagen ET (Wiederholung)/Grundlagen Spannung und Strom.docx
- internal:KI Ergebnisse/AP2_2026_ITSE_ET_Themencheckliste.md
- internal:Unterricht
- internal:Altklausur-Muster (aus Lernskript)
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
In AP2-Aufgaben ist oft klar", was **U**, **I** und **R** bedeuten - z.B. beim Dimensionieren einer Zuleitung, beim Abschaetzen von Verlustleistung oder beim Pruefen von Messwerten im Schaltschrank. Voraussetzung sind:
- elektrische Groessen und Einheiten (Volt, Ampere, Ohm)
- einfacher Stromkreis (Quelle -> Leitung -> Last)
- Zusammenhang zwischen Spannung, Strom und Widerstand
- Umgang mit Formeln (Umstellen, Einheiten pruefen)

Wenn du bei Einheiten unsicher bist: Notiere immer zuerst die Einheit und pruefe am Ende, ob das Ergebnis plausibel ist (z.B. 0,2 A vs. 200 A).

## Definition und Zweck
- **Spannung (U)** ist eine Potentialdifferenz - sie treibt" Ladungen an.
- **Strom (I)** ist der Fluss elektrischer Ladung pro Zeit.
- **Widerstand (R)** beschreibt, wie stark ein Bauteil/Leiter den Stromfluss hemmt.
Diese Groessen sind die Basis fuer fast alle Rechenaufgaben in Elektrotechnik (DC und als Bestandteil von AC).

## Ohmsches Gesetz (DC / Naeherung)
**U = R * I**  
Daraus:
- **I = U / R**
- **R = U / I**

Typischer AP2-Einsatz: Wie gross ist der Strom bei 230 V an einer Last?" oder Welche Sicherung/LS-Kennlinie passt zu einem Strom?".

## Mini-Beispiel
Gegeben: U = 24 V, R = 12 Ohm  
I = U/R = 24/12 = 2 A  
Leistung (Ueberblick): P = U*I = 48 W (siehe [[leistung-energie-drehstrom-cosphi|Leistung & Energie]])

## Typische Fehler & Stolperfallen
- **Einheiten vergessen** (kOhm vs. Ohm; mA vs. A).
- **Umstellen falsch** (z.B. R = I/U statt U/I).
- **Verwechseln von Nennspannung** (230 V) und tatsaechlichem Messwert (kann abweichen).
- **Ohmsches Gesetz blind anwenden** bei nicht-ohmschen Bauteilen (z.B. Diode). In der Pruefung wird meist klar gesagt, ob linear/ohmsch angenommen werden darf.

## Checkliste (Kurz)
- Einheiten ueberall mitschreiben.
- Vor dem Rechnen: Welche Groesse gesucht?"
- Formel waehlen, umstellen, einsetzen, plausibilisieren.

## Siehe auch
- [[leistung-energie-drehstrom-cosphi|Leistung & Energie]]
- [[wechselspannung-grundlagen|Wechselspannung-Grundlagen]]
- [[messgeraete-spannungspruefer-multimeter|Messgeraete]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)
