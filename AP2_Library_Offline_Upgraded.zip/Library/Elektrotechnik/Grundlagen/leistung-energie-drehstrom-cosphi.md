---
title: Leistung, Energie, Drehstrom, cos(phi) und P-Q-S
tags:
- elektrotechnik
- grundlagen
- leistung
- energie
- drehstrom
- cosphi
- formeln
priority: P1+P2
exam_relevance: hoch
sources:
- internal:KI Ergebnisse/AP2_2026_ITSE_Elektrotechnik_Lernskript (1).docx
- internal:KI Ergebnisse/AP2_2026_ITSE_ET_Themencheckliste.md
- internal:Elektrotechnik/Grundlagen Wechselspannung/Kenngroessen der Wechselspannungstechnik.pdf
- internal:Altklausur-Muster (aus Lernskript)
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
In AP2 tauchen Rechenaufgaben fast immer in einem Kontext auf: **Dimensionierung** (Strom, Absicherung, Querschnitt, Spannungsfall) oder **Plausibilitaetschecks** (Passt der Strom zum Geraet?). Voraussetzungen:
- [[spannung-strom-ohm|U, I, R und Einheiten]]
- Unterschied 1~ (230 V) vs. 3~ (400 V)
- Grundidee Leistungsfaktor **cos(phi)** bei Wechselstrom (Blindanteil)

## Definition und Zweck
- **Wirkleistung P (W)**: nutzbare" Leistung, die in Waerme/Arbeit umgesetzt wird.
- **Blindleistung Q (var)**: pendelt zwischen Quelle und Last (z.B. Spule/Kondensator), verrichtet keine nutzbare" Arbeit.
- **Scheinleistung S (VA)**: geometrische Summe aus P und Q.
Beziehung: **S2 = P2 + Q2** und **cos(phi) = P/S**.

## Formeln (AP2-relevant)
**Gleichstrom / ohmsche Last:**  
P = U * I

**Wechselstrom 1~:**  
P = U * I * cos(phi)

**Drehstrom 3~ (symmetrisch):**  
P = sqrt3 * U\_LL * I * cos(phi)  
(U\_LL = Leiterspannung, typ. 400 V)

Umgestellt nach Strom:
I = P / (sqrt3 * U\_LL * cos(phi))

## Mini-Beispiel (typisch wie in Altklausuren)
Gegeben: P = 22 kW, U\_LL = 400 V, cos(phi)=0,95  
I ~ 22000 / (1,732*400*0,95) ~ 33,4 A  
Danach: passende Schutzeinrichtung waehlen und Querschnitt bestimmen (siehe [[leitungsdimensionierung-querschnitt-spannungsfall|Leitungsdimensionierung]]).

## Pruefungsnahe Anwendung: Wo kommt das vor?
- Motoren, USV/Netzteile, groessere Verbraucher im Rack/Serverraum.
- Bewertung von Angaben auf Typenschildern (kW, A, cosphi).

## Typische Fehler & Stolperfallen
- 400 V vs. 230 V vertauschen (3~ vs. 1~).
- cos(phi) vergessen -> Strom zu klein gerechnet.
- kW/W falsch (22 kW = 22000 W).
- P, Q, S verwechselt (P ist nicht VA).

## Checkliste (Kurz)
- Netzart klaeren: 1~ oder 3~.
- Spannung richtig waehlen (230/400).
- cos(phi) beachten.
- Ergebnis plausibilisieren (Groessenordnung).

## Siehe auch
- [[leitungsdimensionierung-querschnitt-spannungsfall|Leitungsdimensionierung]]
- [[wechselspannung-grundlagen|Wechselspannung-Grundlagen]]
- [[usv-grundlagen|USV-Grundlagen]]
