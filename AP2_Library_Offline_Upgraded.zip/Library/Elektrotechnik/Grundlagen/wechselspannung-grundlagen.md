---
title: Wechselspannung und Wechselstrom-Grundlagen
tags:
- elektrotechnik
- grundlagen
- wechselspannung
- wechselstrom
- effektivwert
- frequenz
- impedanz
priority: P2
exam_relevance: mittel
sources:
- internal:Elektrotechnik/Grundlagen Wechselspannung/Grundlagen Wechselspannung.txt
- internal:Elektrotechnik/Grundlagen Wechselspannung/Grundlagen Wechselspannung.pdf
- internal:Elektrotechnik/Grundlagen Wechselspannung/IB_Wechselstrom_v3.pdf
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Wechselspannung (AC) ist in der Gebaeudetechnik und in vielen Pruefungsaufgaben Standard" (230/400 V). Haeufig wird vorausgesetzt:
- Unterschied DC vs. AC
- Sinusfoermiger Verlauf und **Effektivwert**
- Grundidee von Frequenz (50 Hz) und Periodendauer
- Warum Spule/Kondensator im AC anders reagieren als im DC

## Definition und Zweck
**Wechselspannung** aendert periodisch ihren Wert und ihr Vorzeichen. In Europa sind es typischerweise **50 Hz**. Vorteile: effiziente Uebertragung, Transformierbarkeit (Trafo), Drehstromsysteme.

## Wichtige Kenngroessen
- **Amplitude (U)**: Spitzenwert.
- **Effektivwert (Ueff)**: Gleichwertige DC-Spannung bezueglich Waermeleistung.  
  Fuer Sinus: **Ueff = U / sqrt2**.
- **Frequenz (f)** und **Periodendauer (T)**: T = 1/f.
- **Phasenlage**: relevant bei P-Q-S und Drehstrom.

## Wechselstromwiderstaende (Grundidee)
Im AC gilt nicht nur R:
- **Induktiver Blindwiderstand (Spule):** X\_L = 2pi f L
- **Kapazitiver Blindwiderstand (Kondensator):** X\_C = 1 / (2pi f C)
Das erklaert, warum z.B. Netzteile Kondensatoren/Spulen zur Glaettung/Filterung nutzen.

## Pruefungsnahe Anwendung: Pruefungsrelevante Anwendung
- Bewertung von cos(phi) und Leistungsfaktor (siehe [[leistung-energie-drehstrom-cosphi|P/Q/S & cosphi]])
- Auswahl von Schutzorganen, Dimensionierung, Spannungsfall (siehe [[leitungsdimensionierung-querschnitt-spannungsfall|Leitungen]])

## Typische Fehler & Stolperfallen
- Effektivwert vs. Spitzenwert verwechseln (230 V ist Ueff).
- Formeln ohne Einheiten nutzen.
- Blindwiderstaende ignorieren, obwohl Aufgabe explizit Spule/Kondensator nennt.

## Checkliste (Kurz)
- 230/400 V sind Effektivwerte.
- Bei AC-Lasten immer fragen: Ist cos(phi) gegeben?"
- Bei Spule/Kondensator: f beachten.

## Siehe auch
- [[leistung-energie-drehstrom-cosphi|Leistung & cos(phi)]]
- [[spule|Spule]]
- [[kondensator|Kondensator]]
- [[transformator|Transformator]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
