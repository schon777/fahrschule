---
title: Erdung und Potentialausgleich - Zweck, Aufbau, typische Fehler
tags:
- elektrotechnik
- grundlagen
- erdung
- potentialausgleich
- pe
- schutz
- pruefung
priority: P1+P2
exam_relevance: hoch
sources:
- internal:KI Ergebnisse/AP2_2026_ITSE_ET_Themencheckliste.md
- internal:KI Ergebnisse/AP2_2026_ITSE_Elektrotechnik_Lernskript (1).docx
- internal:Themen die ich nicht vergessen moechte.docx
- internal:Unterricht
- internal:Altklausur-Muster (aus Lernskript)
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Erdung und Potentialausgleich werden in Pruefungen oft als selbstverstaendlich" behandelt - z.B. im Serverraum (Rack, Patchpanel, Kabeltrassen) oder in Netzform-Aufgaben. Voraussetzungen:
- Unterschied Erde" (Bezugspotential) vs. PE" (Schutzleiter)
- Warum Beruehrungsspannungen gefaehrlich sind (siehe [[schutz-gegen-elektrischen-schlag|Schutz gegen elektrischen Schlag]])

## Definition und Zweck
- **Erdung**: leitfaehige Verbindung zu einem Erdungssystem (Erder), um ein definiertes Bezugspotential und Fehlerstromwege zu schaffen.
- **Potentialausgleich (PA)**: leitfaehiges Verbinden von gleichzeitig beruehrbaren Teilen, damit zwischen ihnen moeglichst **keine** gefaehrliche Spannung auftritt.

Merksatz: *Erdung schafft Bezug zur Erde - Potentialausgleich bringt alles auf (nahezu) gleiches Potential.*

## Pruefungsnahe Anwendung in IT-Umgebungen (Serverraum/Rack)
Typisch sind:
- PA-Schiene / Haupterdungsschiene im Gebaeude
- Verbindung von Rack/Kabeltrasse/Metallgehaeusen zum PA
- Schutzleiterfuehrung zu Steckdosenleisten/USV

## Typische Fehler & Stolperfallen
- **Hoher Uebergangswiderstand** (lose Klemme, Korrosion) -> Messwerte unplausibel, RCD/Schutzorgan reagiert ggf. anders.
- **PEN-Unterbrechung** (im TN-C/TN-C-S) -> gefaehrliche Gehaeusespannungen moeglich.
- Erdung vergessen" bei metallischen Konstruktionen -> gefaehrliche Potentialdifferenzen.

## Typische Fehler & Stolperfallen
- PE und PA gleichsetzen: PA kann auch Teile verbinden, die nicht direkt PE sind (z.B. Wasserrohre, Kabeltrassen - abhaengig von Aufgabe).
- N ist doch auch geerdet" -> N ist Betriebsleiter; in TN-Systemen am Sternpunkt geerdet, aber im Betrieb stromfuehrend.

## Checkliste (Kurz)
- Gibt es eine definierte Erdungsanlage/HES?
- Sind alle beruehrbaren Metallteile eingebunden?
- Sind N/PE/PEN korrekt gefuehrt?

## Siehe auch
- [[netzformen-tn-tt-it|Netzformen]]
- [[fuenf-sicherheitsregeln|5 Sicherheitsregeln]]
- [[pruefung-nach-vde-0100-600|VDE-Pruefung]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
