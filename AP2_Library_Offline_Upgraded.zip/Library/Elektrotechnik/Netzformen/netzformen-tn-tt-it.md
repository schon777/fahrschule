---
title: Netzformen TN/TT/IT - N, PE, PEN und typische Messwerte
tags:
- elektrotechnik
- netzformen
- tn
- tt
- it
- erdung
- pen
- pruefung
priority: P1+P2
exam_relevance: hoch
sources:
- internal:KI Ergebnisse/AP2_2026_ITSE_ET_Themencheckliste.md
- internal:KI Ergebnisse/AP2_2026_ITSE_Elektrotechnik_Lernskript (1).docx
- internal:Elektrotechnik/Netzformen/Netzformen.txt
- internal:Unterricht
- internal:Altklausur-Muster (aus Lernskript)
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
In AP2-Aufgaben kommt die Netzform haeufig indirekt vor: Messwerte (L-L, L-N, N-PE), Auswahl von Schutzmassnahmen (RCD, Abschaltbedingungen) oder Aufbau im Schaltschrank. Vorausgesetzt wird:
- Rollen von **N** (Neutralleiter) und **PE** (Schutzleiter)
- Unterschied zwischen Schutzleiter und Betriebsleiter
- Grundidee Erdung und Potentialausgleich

## Kurzdefinitionen
- **TN-System**: Sternpunkt des Versorgers ist geerdet, Koerper der Anlage sind ueber PE/PEN damit verbunden.
  - **TN-S**: N und PE getrennt gefuehrt.
  - **TN-C**: kombinierter Leiter **PEN** (N+PE gemeinsam) - nur in Teilen des Netzes zulaessig.
  - **TN-C-S**: erst PEN, spaeter Trennung in N und PE (z.B. Hausanschluss).
- **TT-System**: Sternpunkt geerdet, Koerper der Anlage haben **eigene** Erdungsanlage. Fehlerstromweg ueber Erde -> oft hoehere Impedanz -> RCD wichtig.
- **IT-System**: Versorgung gegen Erde isoliert oder ueber hohe Impedanz; bei erstem Fehler oft keine sofortige Abschaltung, Ueberwachung relevant.

## Typische Messwerte (AP2-Plausibilitaetschecks)
Im TN-S (typisch):
- **L-L ~ 400 V**
- **L-N ~ 230 V**
- **N-PE ~ ~0 V** (idealerweise sehr klein)
Wenn N-PE deutlich hoeher ist: Hinweis auf Fehler/Belastung/Uebergangswiderstand.

## Pruefungsnahe Anwendung: Warum ist das pruefungsrelevant?
- Auswahl von Schutzorganen (RCD ja/nein, IDeltan)
- Interpretieren von Messprotokollen (VDE-Pruefung)
- Fehlersuche (PEN-Unterbrechung, Erdungsprobleme)

## Typische Fehler & Stolperfallen
- PEN mit PE verwechseln: PEN fuehrt Betriebsstrom und ist deshalb kritisch bei Unterbrechung.
- TT wie TN behandeln (Abschaltbedingungen unterscheiden sich praktisch).
- IT-System mit einfacher" Erdung gleichsetzen - Konzept ist anders.

## Checkliste (Kurz)
- Sind N und PE getrennt oder kombiniert?
- Wo ist der Sternpunkt geerdet?
- Wie laeuft der Fehlerstrom zurueck?
- Welche Schutzmassnahme ist naheliegend (LS vs. RCD)?

## Siehe auch
- [[erdung-potentialausgleich|Erdung & Potentialausgleich]]
- [[rcd-fi-fehlerstromschutz|RCD/FI]]
- [[pruefung-nach-vde-0100-600|Pruefung nach VDE 0100-600]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
