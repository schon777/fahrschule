---
title: Die 5 Sicherheitsregeln (DIN VDE) - sicher arbeiten
tags:
- elektrotechnik
- sicherheit
- vde
- pruefung
- arbeitsablauf
priority: P1+P2
exam_relevance: hoch
sources:
- internal:Elektrotechnik/Die 5 Sicherheitsregeln und physologische Wirkung des elektr.
  Stromes/Sicherheit Elektrotechnik - Zusammenfassung.docx
- internal:KI Ergebnisse/AP2_2026_ITSE_Elektrotechnik_Lernskript (1).docx
- internal:Elektrotechnik/Die 5 Sicherheitsregeln und physologische Wirkung des elektr.
  Stromes/5 Sicherheitsregeln.txt
- internal:Unterricht
- internal:Altklausur-Muster (aus Lernskript)
- internal:Web
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
In AP2 wird oft geprueft, ob du **sicheres Arbeiten** korrekt beschreiben kannst - entweder direkt (Nennen Sie die 5 Sicherheitsregeln...") oder indirekt (Messung/Pruefung, Fehleranalyse). Voraussetzungen:
- Grundidee von Spannung/Strom (Gefahr)
- Was bedeutet allpolig trennen"?
- Wer darf was? (Elektrofachkraft, EuP, Laie - je nach Aufgabenstellung)

## Die 5 Sicherheitsregeln (Reihenfolge!)
1) **Freischalten** - Anlage allpolig vom Netz trennen (z.B. Hauptschalter/LS/Sicherung).  
2) **Gegen Wiedereinschalten sichern** - Sperre, Schloss, Schild, Abdeckung; bei zugaenglichen Anlagen nicht nur Zettel".  
3) **Spannungsfreiheit feststellen** - mit geeignetem Messgeraet (typisch: zweipoliger Spannungspruefer), alle aktiven Leiter pruefen.  
4) **Erden und kurzschliessen** - vor allem bei Mittel-/Hochspannung, in Niederspannung abhaengig von Situation; Prinzip kennen.  
5) **Benachbarte, unter Spannung stehende Teile abdecken oder abschranken** - damit keine unbeabsichtigte Beruehrung moeglich ist.

## Pruefungsnahe Anwendung: So formulierst du es pruefungssicher
- **Kurz + begruendet**: nicht nur aufzaehlen, sondern 1 Satz warum".
- Wenn Messaufgaben vorkommen: Regel 3 immer aktiv erwaehnen (Spannungsfreiheit).

## Typische Pruefungsfallen & Fehler
- Reihenfolge vertauschen (z.B. erst messen, dann sichern).
- Einpoliger Phasenpruefer" als Nachweis der Spannungsfreiheit -> gilt i.d.R. als **nicht zulaessig**.
- Schild reicht immer": In Bereichen mit Laienzugang wird i.d.R. eine **physische Sicherung** erwartet.

## Mini-Checkliste (Kurz)
- Allpolig trennen?
- Physisch gesichert?
- Richtiges Messgeraet?
- Umgebung abgesichert?

## Siehe auch
- [[messgeraete-spannungspruefer-multimeter|Messgeraete & Spannungspruefer]]
- [[schutz-gegen-elektrischen-schlag|Schutz gegen elektrischen Schlag]]
- [[pruefung-nach-vde-0100-600|Pruefung nach VDE 0100-600]]


## Typische Fehler & Stolperfallen
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
