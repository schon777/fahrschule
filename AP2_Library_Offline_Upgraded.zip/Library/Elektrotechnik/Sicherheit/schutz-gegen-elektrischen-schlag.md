---
title: Schutz gegen elektrischen Schlag - Schutzmassnahmen und Grundbegriffe
tags:
- elektrotechnik
- sicherheit
- schutzmassnahmen
- erdung
- rcd
- schutzklasse
- ip
priority: P1+P2
exam_relevance: hoch
sources:
- internal:Elektrotechnik/Die 5 Sicherheitsregeln und physologische Wirkung des elektr.
  Stromes/Schutz gegen elektrischen Schlag.txt
- internal:KI Ergebnisse/AP2_2026_ITSE_Elektrotechnik_Lernskript (1).docx
- internal:KI Ergebnisse/AP2_2026_ITSE_ET_Themencheckliste.md
- internal:Elektrotechnik/Die 5 Sicherheitsregeln und physologische Wirkung des elektr.
  Stromes/Sicherheit Elektrotechnik - Zusammenfassung.docx
- internal:Unterricht
- internal:Altklausur-Muster (aus Lernskript)
- internal:Web
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Aufgaben rund um Schutz gegen elektrischen Schlag" tauchen in AP2 sehr haeufig auf (Netzformen, RCD, Schutzklasse, Messungen). Vorausgesetzt wird:
- Unterschied **Koerperstrom** / Beruehrungsspannung
- Begriffe: PE, N, PEN, Erdung, Potentialausgleich
- Grundidee, warum Abschaltbedingungen wichtig sind

## Definition und Zweck
Schutz gegen elektrischen Schlag bedeutet: **gefaehrliche Beruehrungsspannungen vermeiden** oder so schnell abschalten, dass keine gefaehrliche Einwirkdauer entsteht. Man unterscheidet u.a.:
- **Basisschutz** (Schutz gegen direktes Beruehren)
- **Fehlerschutz** (Schutz bei indirektem Beruehren, wenn ein Fehler auftritt)
- **Zusatzschutz** (z.B. RCD <= 30 mA in bestimmten Bereichen)

## Wichtige Schutzmassnahmen (AP2-typisch)
- **Schutzleiter (PE) + automatische Abschaltung**: Fehlerstrom fliesst ueber PE, Schutzorgan schaltet ab (LS/Sicherung, ggf. RCD).
- **RCD/FI**: erkennt Differenzstrom (IDelta) zwischen Hin- und Rueckleiter und schaltet ab (siehe [[rcd-fi-fehlerstromschutz|RCD/FI]]).
- **Schutztrennung** (Trenntrafo) / **Schutzkleinspannung** (SELV/PELV) - je nach Kontext.
- **Isolierung / Abdeckungen / Gehaeuse** (Basisschutz).

## Schutzklassen & Schutzarten (Kurzueberblick)
- **Schutzklasse I**: Schutzleiter vorhanden (Metallgehaeuse mit PE).
- **Schutzklasse II**: doppelte/verstaerkte Isolierung, kein PE noetig.
- **Schutzklasse III**: Schutzkleinspannung.
- **IP-Schutzart**: Schutz gegen Eindringen (Staub/Wasser). In Pruefungen reicht meist Grundidee + Beispiel.

## Typische Fehler & Stolperfallen
- PE und N verwechseln (PE fuehrt im Normalbetrieb keinen Betriebsstrom).
- TT/TN falsch begruenden: In TT ist RCD oft entscheidender", weil Schleifenimpedanz ueber Erde hoeher sein kann.
- RCD als Allheilmittel" sehen: Er ersetzt nicht den Basisschutz.

## Checkliste (Kurz)
- Welche Netzform? ([[netzformen-tn-tt-it|TN/TT/IT]])
- Gibt es PE/PEN korrekt?
- Welche Abschaltbedingung wird erwartet?
- RCD-Typ/ IDeltan passend?

## Siehe auch
- [[netzformen-tn-tt-it|Netzformen]]
- [[rcd-fi-fehlerstromschutz|RCD/FI]]
- [[ls-leitungsschutzschalter|Leitungsschutzschalter]]
- [[erdung-potentialausgleich|Erdung & Potentialausgleich]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
