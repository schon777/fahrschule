---
title: Pruefung nach DIN VDE 0100-600 - Ablauf, Messungen, Dokumentation
tags:
- elektrotechnik
- messen
- pruefen
- vde0100-600
- messprotokoll
- ap2
priority: P1+P2
exam_relevance: hoch
sources:
- internal:KI Ergebnisse/AP2_2026_ITSE_Elektrotechnik_Lernskript (1).docx
- internal:Elektrotechnik/Allgemeines/Praesentationsthemen.txt
- internal:Elektrotechnik/Allgemeines/Formel SE.pdf
- internal:Unterricht
- internal:Altklausur-Muster (aus Lernskript)
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Pruefen/Messen nach VDE" ist ein typischer Aufgabenteil: Messprotokoll interpretieren, fehlende Werte ergaenzen oder den Ablauf beschreiben. Voraussetzungen:
- [[fuenf-sicherheitsregeln|5 Sicherheitsregeln]]
- Grundbegriffe PE, Isolationswiderstand, RCD
- Geeignete Messgeraete (siehe [[messgeraete-spannungspruefer-multimeter|Messgeraete]])

## Ziel der Pruefung
Nach Errichtung oder Aenderung einer Anlage wird geprueft, ob:
- die Anlage **sicher** ist,
- Schutzmassnahmen wirken,
- keine unzulaessigen Fehler vorliegen,
- Dokumentation plausibel und vollstaendig ist.

## Typischer Pruefablauf (Merkschema)
1) **Sichtpruefung**
   - Leitungsfuehrung, Beschriftung, Schutzleiter, Klemmen, IP-Schutz, Beschaedigungen
2) **Erprobung/Funktionspruefung**
   - Schalter, RCD-Testtaste, Funktionen (je nach Aufgabe)
3) **Messungen**
   - **Durchgaengigkeit PE** (niederohmig)
   - **Isolationswiderstand** (zwischen Leitern/PE - abhaengig vom Pruefkonzept)
   - **Schleifenimpedanz / Kurzschlussstrom** (je nach Netzform)
   - **RCD-Pruefung** (Ausloesestrom/Ausloesezeit)
   - ggf. **Polpruefung** / Drehrichtung (bei Drehstrom)

## Dokumentation (Pruefprotokoll)
In Pruefungen zaehlt:
- Werte + Einheit
- bestanden/nicht bestanden" logisch begruendet
- Hinweise auf moegliche Fehler, wenn Werte unplausibel sind (z.B. hoher PE-Widerstand -> schlechter Kontakt)

## Typische Fehler & Stolperfallen
- Reihenfolge ohne Sicherheitsbezug nennen (Regeln vergessen).
- Messgeraet unpassend (z.B. Phasenpruefer).
- Messwert ohne Einheit.
- Grenzwerte raten": besser auf Aufgabe/Belegsatz verweisen.

## Checkliste (Kurz)
- Sichtpruefung erwaehnt?
- Messungen: PE, Isolation, RCD (mindestens diese 3).
- Protokoll: Einheit + Plausibilitaet.

## Siehe auch
- [[messgeraete-spannungspruefer-multimeter|Messgeraete]]
- [[rcd-fi-fehlerstromschutz|RCD/FI]]
- [[aufgabentyp-messprotokoll-vde0100-600|Aufgabentyp: Messprotokoll]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
