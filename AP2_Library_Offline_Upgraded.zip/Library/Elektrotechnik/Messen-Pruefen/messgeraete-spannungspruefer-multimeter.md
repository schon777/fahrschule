---
title: 'Messgeraete: zweipoliger Spannungspruefer, Multimeter, Stromzange - richtig
  einsetzen'
tags:
- elektrotechnik
- messen
- messgeraete
- spannungspruefer
- multimeter
- stromzange
- sicherheit
priority: P1+P2
exam_relevance: hoch
sources:
- internal:Elektrotechnik/Die 5 Sicherheitsregeln und physologische Wirkung des elektr.
  Stromes/Sicherheit Elektrotechnik - Zusammenfassung.docx
- internal:KI Ergebnisse/AP2_2026_ITSE_Elektrotechnik_Lernskript (1).docx
- internal:Unterricht
- internal:Altklausur-Muster (aus Lernskript)
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
In AP2 kann schon ein kleiner Satz entscheidend sein: Spannungsfreiheit mit geeignetem Messgeraet feststellen". Du musst wissen, **welches** Messgeraet wofuer zulaessig ist und welche Fehler haeufig passieren.

## Zweipoliger Spannungspruefer (Standard fuer Spannungsfreiheit)
- Wird fuer Regel 3 der Sicherheitsregeln erwartet.
- Prueft zuverlaessig zwischen zwei Punkten (z.B. L-N, L-PE, N-PE).
- Viele Geraete haben Selbsttest/Funktionspruefung - in Pruefungen kurz erwaehnen.

**Typische Messfolge** (pruefungsnah):
1) Geraet testen (Funktionspruefung)
2) Messung allpolig durchfuehren
3) Geraet danach erneut testen (um Geraetefehler auszuschliessen)

## Multimeter (flexibel, aber vorsichtig einsetzen)
- Fuer Spannung/Strom/Widerstand - je nach Messart muss der Messbereich und die Buchse korrekt gewaehlt werden.
- In sicherheitskritischen Aussagen (Spannungsfreiheit) wird in der Ausbildung oft der zweipolige Pruefer bevorzugt.

Pruefungsfalle: Falsche Buchse (A statt V) oder falscher Messbereich -> Sicherung im Multimeter fliegt oder Messwert ist falsch.

## Stromzange (Kontaktloser Strommesser)
- Misst Strom ueber Magnetfeld - ideal, wenn Leitung nicht getrennt werden soll.
- Wichtig: nur **eine** Ader durch die Zange fuehren (sonst heben sich Felder auf -> 0 A).

## Typische Fehler & Stolperfallen
- Einpoliger Phasenpruefer" als Spannungsfreiheit-Nachweis.
- Messbereich/Buchse falsch.
- Stromzange um beide Leiter (L und N) gelegt -> 0 A.

## Checkliste (Kurz)
- Fuer Spannungsfreiheit: zweipolig + Funktionspruefung.
- Multimeter: Buchse + Bereich pruefen.
- Stromzange: nur eine Ader.

## Siehe auch
- [[fuenf-sicherheitsregeln|5 Sicherheitsregeln]]
- [[pruefung-nach-vde-0100-600|VDE 0100-600 Pruefung]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
