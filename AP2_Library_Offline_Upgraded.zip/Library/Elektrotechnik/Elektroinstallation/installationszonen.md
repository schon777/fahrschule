---
title: Installationszonen (Wand) - wo Leitungen verlegt werden duerfen (Grundidee)
tags:
- elektrotechnik
- elektroinstallation
- installationszonen
- verlegung
- praxis
priority: P2
exam_relevance: mittel
sources:
- internal:Elektrotechnik/Elektro-Installationsschaltungen/Installationszone.txt
- internal:Unterricht
- internal:Web
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Installationszonen kommen in AP2 z.B. bei Serverraum-/Elektroinstallationsaufgaben vor: Wo duerfen Leitungen in der Wand laufen?" Voraussetzungen:
- Grundidee Unterputz/aufputz
- Sicherheits- und Wartungsaspekt: Leitungen sollen erwartbar verlaufen

## Definition und Zweck
**Installationszonen** sind festgelegte Bereiche in Waenden/Decken, in denen Leitungen typischerweise gefuehrt werden, damit sie spaeter nicht zufaellig angebohrt oder beschaedigt werden. Ziel ist: **vorhersehbare Leitungsfuehrung**.

## Pruefungsnahe Anwendung: Typische Zonenkonzepte (ohne Normzahlen auswendig)
In Pruefungen reicht meist:
- Horizontal/vertikal zu Schaltern/Steckdosen
- In definierten Hoehenbereichen (Zonen") und rechtwinklig
- Keine diagonalen" Leitungswege

Wenn die Aufgabe konkrete Masse vorgibt, nutze diese; sonst beschreibe die Regel: *gerade, rechtwinklig, in Zonen*.

## Typische Fehler & Stolperfallen
- Diagonal verlegen (sieht kuerzer aus") -> unzulaessig/gefaehrlich.
- Leitungen quer durch freie Wandflaechen ohne Bezug zu Installationspunkten.

## Checkliste (Kurz)
- Leitungen rechtwinklig fuehren.
- Horizontale/vertikale Zonen nutzen.
- Von Steckdose/Schalter senkrecht/waagerecht weg.

## Siehe auch
- [[leitungsdimensionierung-querschnitt-spannungsfall|Leitungsdimensionierung]]
- [[schaltzeichen-und-stromlaufplaene|Schaltzeichen & Plaene]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
