---
title: Schaltzeichen und Stromlaufplaene lesen - Basics fuer AP2
tags:
- elektrotechnik
- elektroinstallation
- schaltzeichen
- stromlaufplan
- planlesen
- ap2
priority: P1+P2
exam_relevance: mittel
sources:
- internal:Elektrotechnik/Elektro-Installationsschaltungen/Liste der Schaltzeichen.txt
- internal:Elektrotechnik/Elektro-Installationsschaltungen/Schaltzeichen V2.pdf
- internal:Elektrotechnik/Elektro-Installationsschaltungen/VP Installationsschaltungen.pdf
- internal:Unterricht
- internal:Web
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Planlesen ist ein typischer Pruefungsteil: Verdrahtung nachvollziehen, Leiter (L/N/PE) zuordnen, Betriebsmittel erkennen. Voraussetzungen:
- Leiterfarben/Bezeichnungen (L1-L3, N, PE, PEN)
- Grundsymbole (Schalter, Sicherung, RCD, Lampe, Steckdose)

## Definition und Zweck
Ein **Stromlaufplan** stellt elektrische Verbindungen so dar, dass Funktion und Verdrahtung erkennbar sind. Schaltzeichen standardisieren dabei die Darstellung.

## Prueferprobte Vorgehensweise (Plan lesen)
1) Energiequelle/Netzpunkt finden (Einspeisung, Hauptschalter, Sicherung)
2) Schutzorgane identifizieren (LS, RCD, Sicherung)
3) Leiter konsequent verfolgen (L -> Schutzorgane -> Last -> zurueck)
4) PE separat betrachten (Schutzleiterfuehrung)
5) Bei Drehstrom: L1/L2/L3, N, PE sauber trennen

## Haeufige Schaltzeichen, die AP2 gern nutzt (Beispiele)
- LS / Sicherung
- RCD/FI
- Schalter/Relais/Schuetz (je nach ITSE-Aufgabe)
- Steckdose, Leuchte, Klemme
- Schutzleiter-/Potentialausgleichsymbol

## Typische Fehler & Stolperfallen
- N und PE verwechseln (PE fuehrt im Normalbetrieb keinen Strom).
- Leiter springen" im Plan ueber Klemmen/Nummern - dann unbedingt Klemmenbezeichnung folgen.
- Schuetz/Relais nicht erkennen -> Funktion falsch.

## Checkliste (Kurz)
- Einspeisung -> Schutzorgane -> Last.
- Leiterbezeichnungen notieren.
- PE separat pruefen.

## Siehe auch
- [[netzformen-tn-tt-it|Netzformen]]
- [[ls-leitungsschutzschalter|LS]]
- [[rcd-fi-fehlerstromschutz|RCD/FI]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
