---
title: Diode - Einbahnstrasse fuer Strom (Grundprinzip, LED, Schutzdiode)
tags:
- elektrotechnik
- bauteile
- diode
- gleichrichtung
- schutz
priority: P2+P3
exam_relevance: niedrig
sources:
- internal:Ordnerstruktur fuer PI/Elektrotechnik/Bauteile/diode.txt
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Dioden tauchen in Pruefungen eher als Grundlage" auf (Gleichrichtung, Netzteile, Schutzbeschaltungen). Voraussetzungen:
- [[spannung-strom-ohm|U/I/R]] (aber: Diode ist nicht-ohmsch)

## Definition und Zweck
Eine **Diode** laesst Strom im Idealfall nur in **eine Richtung** fliessen:
- **Vorwaertsrichtung**: leitet ab einer Schwellspannung
- **Sperrrichtung**: sperrt (bis zur Durchbruchspannung)

## Pruefungsnahe Anwendung-Anwendungen
- **Gleichrichter** in Netzteilen (AC -> DC) (siehe [[gleichrichter|Gleichrichter]])
- **Freilaufdiode** bei Relais/Spulen (Schutz vor Induktionsspannung) (siehe [[spule|Spule]])
- **LED** als Leuchtdiode (mit Vorwiderstand)

## Typische Fehler & Stolperfallen
- Diode wie einen Widerstand behandeln (Ohmsches Gesetz direkt anwenden).
- LED ohne Strombegrenzung.

## Siehe auch
- [[gleichrichter|Gleichrichter]]
- [[widerstand|Widerstand]]
- [[spule|Spule]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
