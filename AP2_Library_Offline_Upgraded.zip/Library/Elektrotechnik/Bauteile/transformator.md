---
title: Transformator - Spannung anpassen, Trennung, Grundprinzip
tags:
- elektrotechnik
- bauteile
- transformator
- trafo
- wechselspannung
- schutztrennung
priority: P1+P2+P3
exam_relevance: mittel
sources:
- internal:Ordnerstruktur fuer PI/Elektrotechnik/Bauteile/transformator.txt
- internal:KI Ergebnisse/AP2_2026_ITSE_Elektrotechnik_Lernskript (1).docx
- internal:Unterricht
- internal:Altklausur-implizit
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Trafos sind Basiswissen, weil sie erklaeren, warum AC verteilt wird und wie Schutztrennung funktioniert. Voraussetzungen:
- [[wechselspannung-grundlagen|Wechselspannung]] (Trafo braucht wechselndes Magnetfeld)

## Definition und Zweck
Ein **Transformator (Trafo)** uebertraegt elektrische Energie ueber ein Magnetfeld zwischen Primaer- und Sekundaerwicklung. Ziele:
- Spannung hoch/runter transformieren
- galvanische Trennung (z.B. Schutztrennung)

## Grundprinzip (sehr kurz)
- Wechselstrom in Primaerwicklung -> wechselndes Magnetfeld im Kern
- Induktion erzeugt Spannung in Sekundaerwicklung
- Uebersetzungsverhaeltnis: U2/U1 ~ N2/N1 (N = Windungszahl)

## Pruefungsnahe Anwendung
- Netzteile (230 V AC -> niedrigere AC -> Gleichrichter/Regler)
- Trenntrafo als Schutzmassnahme (abhaengig vom Kontext)

## Typische Fehler & Stolperfallen
- Trafo mit Gleichspannung betreiben (im Ideal nicht sinnvoll).
- Galvanische Trennung mit PE" verwechseln: Trennung heisst nicht automatisch geerdet.

## Siehe auch
- [[gleichrichter|Gleichrichter]]
- [[schutz-gegen-elektrischen-schlag|Schutzmassnahmen]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
