---
title: Widerstand - Aufgabe, Bauformen, Kennzeichnung (Kurzueberblick)
tags:
- elektrotechnik
- bauteile
- widerstand
- ohm
- grundlagen
priority: P2+P3
exam_relevance: niedrig
sources:
- internal:Ordnerstruktur fuer PI/Elektrotechnik/Bauteile/widerstand.txt
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Widerstaende sind Grundlagenwissen und tauchen in Pruefungen meist indirekt auf (Ohmsches Gesetz, Spannungsteiler, Innenwiderstaende). Voraussetzungen:
- [[spannung-strom-ohm|Ohmsches Gesetz]]

## Definition und Zweck
Ein **Widerstand** begrenzt Strom oder teilt Spannung auf. In der Praxis:
- Pull-Up/Pull-Down in Elektronik
- Strombegrenzung (z.B. LEDs)
- Mess- und Anpassschaltungen

## Kenngroessen
- **R in Ohm** (Ohm)
- **Toleranz** (z.B. 1 %, 5 %)
- **Belastbarkeit** (Watt)
- **Temperaturkoeffizient** (optional)

## Mini-Beispiel (LED-Strombegrenzung)
Versorgung 12 V, LED-Flussspannung 2 V, Zielstrom 20 mA  
R ~ (12-2)/0,02 = 500 Ohm  
Belastbarkeit: P = I2*R ~ 0,2 W -> 0,25 W oder groesser waehlen.

## Typische Fehler & Stolperfallen
- mA/A vertauschen.
- Leistung im Widerstand unterschaetzen.

## Siehe auch
- [[spannung-strom-ohm|U/I/R]]
- [[diode|Diode/LED]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)
