---
title: Spule/Induktivitaet - Magnetfeld, Induktionsspannung, Anwendungen
tags:
- elektrotechnik
- bauteile
- spule
- induktivitaet
- magnetfeld
- schutz
priority: P2+P3
exam_relevance: niedrig
sources:
- internal:Ordnerstruktur fuer PI/Elektrotechnik/Bauteile/spule.txt
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Spulen sind in Relais/Schuetzen, Netzteilen und Filtern relevant. In AP2 oft als Voraussetzung (z.B. Freilaufdiode). Voraussetzungen:
- [[wechselspannung-grundlagen|AC-Grundlagen]] (XL haengt von f ab)

## Definition und Zweck
Eine **Spule** speichert Energie im Magnetfeld. Sie wehrt" sich gegen schnelle Stromaenderungen:
- Beim Einschalten steigt der Strom verzoegert
- Beim Abschalten kann eine hohe **Induktionsspannung** entstehen

## Pruefungsnahe Anwendung
- Relais-/Schuetzspule -> Induktionsspannung beim Abschalten -> Schutz mit Freilaufdiode.
- Drosseln in Netzteilen/EMV-Filtern.

## Typische Fehler & Stolperfallen
- Induktionsspannung beim Abschalten vergessen.
- Freilaufdiode falsch gepolt.

## Siehe auch
- [[diode|Diode]]
- [[emv-grundlagen|EMV]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
