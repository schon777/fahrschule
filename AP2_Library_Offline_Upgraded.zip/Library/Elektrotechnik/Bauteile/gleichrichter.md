---
title: Gleichrichter - AC zu DC (Brueckengleichrichter, Glaettung)
tags:
- elektrotechnik
- bauteile
- gleichrichter
- netzteil
- gleichspannung
priority: P2+P3
exam_relevance: niedrig
sources:
- internal:Ordnerstruktur fuer PI/Elektrotechnik/Bauteile/gleichrichter.txt
- internal:Elektrotechnik/Grundlagen ET (Wiederholung)/Netzteile.pdf
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Gleichrichter sind in Netzteilen zentral. In AP2 meist indirekt (Netzteil-Auswahl, DC-Versorgung von Geraeten). Voraussetzungen:
- [[wechselspannung-grundlagen|Wechselspannung]]
- [[diode|Diode-Grundprinzip]]

## Definition und Zweck
Ein **Gleichrichter** wandelt Wechselspannung in (pulsierende) Gleichspannung um. Haeufig:
- **Brueckengleichrichter** (4 Dioden)

## Glaettung (Kurz)
Nach dem Gleichrichter wird oft ein **Kondensator** eingesetzt, um die Spannung zu glaetten (Spannungswelligkeit reduzieren).  
Siehe [[kondensator|Kondensator]].

## Pruefungsnahe Anwendung
- Netzteile, Ladegeraete, DC-Versorgung in IT-Komponenten
- Pruefen: Warum kommt nach dem Trafo ein Gleichrichter?"

## Typische Fehler & Stolperfallen
- Glaettung mit stabiler" DC verwechseln (Regelung kommt meist zusaetzlich).
- Dioden-Spannungsabfall ignorieren (in Elektronikaufgaben).

## Siehe auch
- [[diode|Diode]]
- [[kondensator|Kondensator]]
- [[transformator|Transformator]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
