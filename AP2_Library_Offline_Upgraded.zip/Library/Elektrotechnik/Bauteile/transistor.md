---
title: Transistor - Schalten/Verstaerken (Kurzueberblick fuer ITSE)
tags:
- elektrotechnik
- bauteile
- transistor
- schalten
- elektronik
priority: P2+P3
exam_relevance: niedrig
sources:
- internal:Ordnerstruktur fuer PI/Elektrotechnik/Bauteile/transistor.txt
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Transistoren sind eher Elektronik-Grundlagen. In AP2 ITSE selten tief, aber als Voraussetzung nuetzlich (z.B. Schalten von Relais, Sensorik). Voraussetzungen:
- Strom/Spannung-Grundlagen

## Definition und Zweck
Ein **Transistor** ist ein Halbleiterbauteil zum **Schalten** oder **Verstaerken**. Typisch:
- BJT (Basis steuert Kollektor-Emitter-Strom)
- MOSFET (Gate steuert Drain-Source-Strom)

## Pruefungsnahe Anwendung
- Schalten von Lasten mit kleinem Steuersignal (z.B. Mikrocontroller -> Relais)
- Leistungsschalter in Netzteilen/USV (Leistungselektronik)

## Typische Fehler & Stolperfallen
- BJT/MOSFET durcheinander
- Schutzbeschaltung (Freilaufdiode bei Relais) vergessen

## Siehe auch
- [[spule|Spule]]
- [[diode|Diode]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
