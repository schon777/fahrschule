---
title: Batterie - Grundlagen, Kenngroessen und Einsatz in IT/ET
tags:
- elektrotechnik
- bauteile
- batterie
- energie
- usv
- grundlagen
priority: P1+P2+P3
exam_relevance: mittel
sources:
- internal:Ordnerstruktur fuer PI/Elektrotechnik/Bauteile/Batterie.txt
- internal:IT/Ernstmeier/Datenschutz und Datensicherheit USV/USV.pptx
- internal:YouTube-Themen
- internal:Unterricht
- internal:Altklausur-implizit
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Batterien werden in Pruefungen oft nicht direkt abgefragt, sind aber als **Voraussetzung** wichtig (USV, Notstrom, Messgeraete, Akkupacks). Vorausgesetzt werden:
- Unterschied Spannung vs. Energie (siehe [[leistung-energie-drehstrom-cosphi|Leistung & Energie]])
- DC-Grundlagen (siehe [[spannung-strom-ohm|U/I/R]])

## Definition und Zweck
Eine **Batterie** (bzw. Akku) ist ein elektrochemischer Energiespeicher, der elektrische Energie als **Gleichspannung** bereitstellt. In IT-Umgebungen ist sie zentral fuer:
- USV-Ueberbrueckung
- Router/Switch-Backup (teilweise)
- mobile Messgeraete/Tools

## Wichtige Kenngroessen
- **Nennspannung (V)**: z.B. 12 V, 24 V.
- **Kapazitaet (Ah)**: Ladungsmenge (vereinfacht).
- **Energie (Wh)**: naeherungsweise Wh ~ V * Ah (bei konstanter Spannung).
- **Innenwiderstand**: beeinflusst Spannungseinbruch bei hoher Last.
- **C-Rate**: Verhaeltnis Entladestrom zu Kapazitaet (bei Akkus relevant).

## Mini-Beispiel
Akku: 12 V, 7 Ah  
Energie ~ 12 * 7 = 84 Wh  
Wenn eine Last 42 W zieht, ergibt das idealisiert ~2 h (real weniger wegen Verlusten/Alterung).

## Typische Fehler & Stolperfallen
- Ah mit Wh verwechseln.
- Spannung bleibt nicht konstant; unter Last sinkt sie.
- Alterung/Temperatur ignorieren (Kapazitaet sinkt).

## Checkliste (Kurz)
- W/VA und gewuenschte Laufzeit -> Wh abschaetzen.
- Reserve einplanen.
- Wartung/Batterietausch beruecksichtigen (USV).

## Siehe auch
- [[usv-grundlagen|USV]]
- [[leistung-energie-drehstrom-cosphi|Leistung & Energie]]
- [[spannung-strom-ohm|U/I/R]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)
