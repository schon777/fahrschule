---
title: Kondensator - Speichern, Glaetten, Filtern (Grundidee)
tags:
- elektrotechnik
- bauteile
- kondensator
- kapazitaet
- filter
priority: P2+P3
exam_relevance: niedrig
sources:
- internal:Ordnerstruktur fuer PI/Elektrotechnik/Bauteile/kondensator.txt
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Kondensatoren sind Grundlagenwissen und tauchen oft als implizites" Konzept auf (Netzteile, EMV-Filter, Glaettung). Voraussetzungen:
- [[wechselspannung-grundlagen|AC-Grundlagen]] (Xc haengt von f ab)

## Definition und Zweck
Ein **Kondensator** speichert elektrische Energie im elektrischen Feld und wirkt in Schaltungen z.B. als:
- Glaettung (nach Gleichrichter)
- Filter (AC-Anteile blockieren/zulassen je nach Aufbau)
- Entkopplung/Stuetzung bei Lastwechseln

## Wichtige Kenngroessen
- **Kapazitaet C** in Farad (uF, nF)
- **Spannungsfestigkeit**
- **ESR** (Verluste, wichtig bei Leistungselektronik)

## Pruefungsnahe Anwendung
- DC-Glaettung: Kondensator laedt bei Spannungsspitzen und liefert bei Einbruechen kurz Energie.
- In AC: Blindwiderstand Xc = 1/(2pi f C).

## Typische Fehler & Stolperfallen
- Polaritaet bei Elektrolytkondensatoren ignorieren.
- Spannungsspitzen unterschaetzen (Spannungsfestigkeit).

## Siehe auch
- [[gleichrichter|Gleichrichter]]
- [[emv-grundlagen|EMV]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
