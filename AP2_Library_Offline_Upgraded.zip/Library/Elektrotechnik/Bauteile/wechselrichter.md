---
title: Wechselrichter - DC zu AC (Grundidee, Einsatz in USV/Photovoltaik)
tags:
- elektrotechnik
- bauteile
- wechselrichter
- usv
- dcdc
- acdc
priority: P2+P3
exam_relevance: niedrig
sources:
- internal:Ordnerstruktur fuer PI/Elektrotechnik/Bauteile/wechselrichter.txt
- internal:Elektrotechnik/Allgemeines/USV_Praesentation_AT_PL_Komprimiert.pptx
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: elektrotechnik
---
## Kontext & Grundlagen (Voraussetzungen)
Wechselrichter erklaeren, wie aus Batterien/USV wieder AC wird. Voraussetzungen:
- DC/AC-Unterschied
- [[leistung-energie-drehstrom-cosphi|Leistungsbegriffe]] (W/VA, Wirkungsgrad)

## Definition und Zweck
Ein **Wechselrichter** wandelt Gleichspannung (DC) in Wechselspannung (AC) um. Er ist zentral in:
- USV (Batterie/DC -> AC fuer Verbraucher)
- Photovoltaik (DC der Module -> AC fuers Netz)

## Pruefungsnahe Anwendung (pruefungsnah)
- In USV-Systemen bestimmt der Wechselrichter mit, wie sauber" die Ausgangsspannung ist (Online-USV vs. Offline).
- Bei Lasten mit hohem Anlaufstrom ist die Dimensionierung wichtig.

## Typische Fehler & Stolperfallen
- W/VA ignorieren (Leistungsfaktor).
- Wirkungsgrad/Verluste ignorieren.

## Siehe auch
- [[usv-grundlagen|USV]]
- [[batterie|Batterie]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
