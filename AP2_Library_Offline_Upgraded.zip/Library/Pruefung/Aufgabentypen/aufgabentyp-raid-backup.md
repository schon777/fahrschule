---
title: 'Aufgabentyp: RAID vs. Backup sauber abgrenzen und begruenden'
tags:
- pruefung
- it-systeme
- raid
- backup
- begruendung
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Datenschutz und Datensicherheit RAID/RAID.pdf
- internal:IT/Ernstmeier/Datenschutz und Datensicherheit Backupverfahren/Begriffe.txt
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: pruefung
---
## Kontext & Grundlagen (Voraussetzungen)
Pruefungen fragen gern: Welche Massnahme erhoeht Verfuegbarkeit/Datensicherheit?" oder Warum reicht RAID nicht als Backup?". Voraussetzungen:
- [[cia-triad-datenschutz-datensicherheit|CIA-Triade]]
- [[raid-grundlagen|RAID]]
- [[backupverfahren-3-2-1-generationenprinzip|Backup]]

## Standardantwort-Logik (pruefungsnah)
- **RAID**: schuetzt vor *Ausfall einer Platte* (je nach Level) -> erhoeht Verfuegbarkeit.
- **Backup**: schuetzt vor *Datenverlust* durch Loeschen, Malware, Korruption, Feuer/Diebstahl -> ermoeglicht Wiederherstellung.

## Typische Pruefungsbegruendungen
- Ransomware: RAID hilft nicht (verschluesselte Daten sind ueberall gleich).
- User loescht Datei: RAID spiegelt Loeschung.
- Brand/Diebstahl: RAID im selben Geraet betroffen.

## Checkliste (Kurz)
- Welches Risiko wird beschrieben?
- Welche Massnahme adressiert genau dieses Risiko?
- Restore/Recovery erwaehnen (RPO/RTO) wenn gefragt.

## Siehe auch
- [[raid-grundlagen|RAID]]
- [[backupverfahren-3-2-1-generationenprinzip|Backup]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Typische Fehler & Stolperfallen
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
