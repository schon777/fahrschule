---
title: 'Aufgabentyp: Subnetting & IP-Plan in der Pruefung'
tags:
- pruefung
- netzwerk
- subnetting
- ip-plan
- ap2
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Subnetting/subnetting.pdf
- internal:Unterricht
- internal:Altklausur-implizit
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: pruefung
---
## Kontext & Grundlagen (Voraussetzungen)
Subnetting-Aufgaben verbinden Planung und Fehlersuche. Voraussetzungen:
- [[subnetting-ipv4|Subnetting-Grundlage]]
- Routing/Gateway-Logik

## Typische Varianten
- Erstellen Sie einen IP-Plan fuer x Abteilungen/VLANs."
- Welches Netz/BC/Hostbereich hat ...?"
- Warum kann Host A Host B nicht erreichen?" (Maske/Gateway falsch)

## Prueferprobte Vorgehensweise
1) Anforderungen sammeln: Anzahl Hosts pro Segment, Reserven, ggf. Standortkopplung.
2) Netze dimensionieren: passende Prefixe waehlen (groesstes Netz zuerst).
3) Plan dokumentieren: Netzadresse, Gateway, DHCP-Range, statische Bereiche.
4) Plausibilitaetscheck: Ueberschneidungen? genug Hosts? Gateway im Netz?

## Haeufige Stolperstellen
- keine Reserve fuer Wachstum
- DHCP-Range kollidiert mit statischen IPs
- gleiche Netze an mehreren Standorten (VPN-Routing kollidiert)

## Siehe auch
- [[subnetting-ipv4|Subnetting]]
- [[routing-grundlagen|Routing]]
- [[vlan-grundlagen-trunk-tagging|VLAN]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Typische Fehler & Stolperfallen
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
