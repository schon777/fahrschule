---
title: 'Aufgabentyp: Messprotokoll (VDE 0100-600) ausfuellen und bewerten'
tags:
- pruefung
- elektrotechnik
- messprotokoll
- vde0100-600
- ap2
priority: P1+P2
exam_relevance: hoch
sources:
- internal:KI Ergebnisse/AP2_2026_ITSE_Elektrotechnik_Lernskript (1).docx
- internal:Unterricht
- internal:Altklausur-implizit
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: pruefung
---
## Kontext & Grundlagen (Voraussetzungen)
AP2-Aufgaben zeigen oft ein (teilweise leeres) Messprotokoll oder Messwerte, die du interpretieren sollst. Voraussetzungen:
- [[pruefung-nach-vde-0100-600|VDE 0100-600 Ablauf]]
- [[messgeraete-spannungspruefer-multimeter|Messgeraete]]
- Verstaendnis von RCD/PE/Isolation (siehe [[rcd-fi-fehlerstromschutz|RCD]] und [[erdung-potentialausgleich|Erdung]])

## Typische Teilaufgaben
- fehlende Messwerte ergaenzen (Einheit nicht vergessen)
- bestanden/nicht bestanden" markieren und begruenden
- Fehlerquelle nennen, wenn Werte unplausibel sind
- richtigen Pruefablauf kurz beschreiben

## Vorgehensschema (pruefungsnah)
1) **Netzform und Schutzmassnahme** klaeren (TN/TT/IT).
2) **Welche Messung gehoert zu welchem Ziel?**
   - PE-Durchgaengigkeit -> Schutzleiter vorhanden und niederohmig
   - Isolation -> keine unzulaessigen Ableitpfade
   - Schleifenimpedanz/Kurzschlussstrom -> Abschaltbedingungen
   - RCD-Ausloesezeit/-strom -> Zusatzschutz wirkt
3) **Plausibilitaet pruefen**: Passt der Wert zum Kontext?"
4) **Begruendung schreiben**: 1-2 Saetze reichen, aber fachlich sauber.

## Typische Fehler & Stolperfallen
- Werte ohne Einheit.
- RCD-Pruefung vergessen", obwohl RCD verbaut ist.
- Sichtpruefung" nicht erwaehnen (wenn nach Ablauf gefragt).

## Siehe auch
- [[pruefung-nach-vde-0100-600|VDE 0100-600]]
- [[fuenf-sicherheitsregeln|5 Sicherheitsregeln]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
