---
title: 'Aufgabentyp: VoIP-Probleme analysieren (QoS, VLAN, Ports)'
tags:
- pruefung
- netzwerk
- voip
- qos
- vlan
- ports
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/VoIP/Leitfragen.txt
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: pruefung
---
## Kontext & Grundlagen (Voraussetzungen)
VoIP-Aufgaben fragen oft Warum ist die Sprachqualitaet schlecht?" oder Welche Anforderungen hat VoIP?". Voraussetzungen:
- [[voip-grundlagen-sip-rtp-qos|VoIP-Grundlagen]]
- [[vlan-grundlagen-trunk-tagging|VLAN]]
- [[firewall-dmz-nat|Firewall/Ports]]

## Typische Ursachenketten (pruefungsnah)
- Kein DHCP/DNS -> Telefon registriert sich nicht.
- VLAN falsch -> Telefon im falschen Netz.
- QoS fehlt -> Jitter/Latenz unter Last.
- Firewall blockt SIP/RTP -> Signalisierung/Audio fehlt.

## Vorgehensschema
1) Registriert sich das Telefon? (SIP)  
2) Kommt Audio in beide Richtungen? (RTP, NAT/Ports)  
3) Netzwerkqualitaet: Latenz/Jitter/Paketverlust (QoS, Bandbreite)  
4) Verkabelung/PoE: Stromversorgung stabil? (siehe [[poe-standards-8023af-at-bt|PoE]])

## Typische Fehler & Stolperfallen
- SIP ok, aber RTP blockiert -> Es klingelt, aber man hoert nichts".
- QoS wird nur im LAN gedacht, nicht im WAN/Standort-VPN.

## Siehe auch
- [[voip-grundlagen-sip-rtp-qos|VoIP]]
- [[poe-standards-8023af-at-bt|PoE]]
- [[vpn-grundlagen-ipsec-ssl|VPN]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
