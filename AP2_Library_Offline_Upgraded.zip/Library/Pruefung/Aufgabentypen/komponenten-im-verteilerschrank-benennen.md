---
title: 'Aufgabentyp: Betriebsmittel im Verteilerschrank benennen'
tags:
- pruefung
- elektrotechnik
- verteilerschrank
- betriebsmittel
- ap2
priority: P1+P2
exam_relevance: hoch
sources:
- internal:Alte AP2 Pruefungen/2021_22_Winter_IT-System-Elektroniker.pdf
- internal:Alte AP2 Pruefungen/2021_22_Winter_IT-System-Elektroniker Lsg.pdf
- internal:Altklausur-Referenz (Dateinamen)
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: pruefung
---
## Kontext & Grundlagen (Voraussetzungen)
Dieser Aufgabentyp kommt regelmaessig vor: Foto/Skizze eines Verteilerschranks, dazu Benennen Sie die Betriebsmittel fachgerecht". Voraussetzungen:
- Grundaufbau vom Hausanschluss Richtung Endstromkreis
- typische Geraetebilder/Symbole
- Begriffe wie Zaehler, Hauptschalter, SLS, RCD, LS, Patchpanel (im IT-Rack)

## Vorgehensschema (pruefungsnah)
1) **Von der Einspeisung aus denken**: Wo kommt die Energie rein?  
2) **Leistungsweg verfolgen**: Hausanschluss -> Zaehler -> Hauptschalter/SLS -> Verteilung -> Schutzorgane -> Abgaenge  
3) **Geraete an Merkmalen erkennen**:
   - Zaehler: Anzeige/Plombierung, Zaehlwerk
   - Hauptschalter: grosser Schaltergriff/Lasttrennschalter
   - SLS: spezielles Schutzorgan nahe Zaehlerfeld
   - RCD: Testtaste T", IDeltan-Aufdruck (z.B. 30 mA)
   - LS: viele kleine Automaten, Kennlinie/Nennstrom (B16/C16)
   - Ueberspannungsschutz: oft modular, nahe Einspeisung (wenn vorhanden)
   - Steckdosen/Service-Steckdosen: Schuko/CEE im Schaltschrank (je nach Bild)

## Typische IT im Schaltschrank"-Komponenten (wenn Aufgabe es mischt)
- Patchpanel, Switch, Router (eher im Netzwerkschrank als im Zaehlerfeld)

## Typische Fehler & Stolperfallen
- Hauptschalter vs. SLS verwechseln.
- RCD mit LS verwechseln (RCD hat Testtaste und IDeltan).
- Zu ungenau benennen (Sicherung") statt Leitungsschutzschalter B16".

## Mini-Checkliste (Kurz)
- Begriffe aus Aufgabe exakt uebernehmen.
- Fachbezeichnung + Funktion in einem Halbsatz (wenn gefragt).

## Siehe auch
- [[ls-leitungsschutzschalter|LS]]
- [[rcd-fi-fehlerstromschutz|RCD/FI]]
- [[selektivitaet-sls|Selektivitaet & SLS]]
- [[strukturierte-verkabelung|Patchpanel & Verkabelung]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
