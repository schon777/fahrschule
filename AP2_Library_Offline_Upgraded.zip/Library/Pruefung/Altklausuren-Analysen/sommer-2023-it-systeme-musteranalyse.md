---
title: 'Musteranalyse Sommer 2023: IT-Systeme (ITSE)'
tags:
- pruefung
- altklausur
- analyse
- itse
- it-systeme
priority: P1+P2
exam_relevance: hoch
sources:
- internal:Alte AP2 Pruefungen/Sommer 2023 - ITSE (AO2023)_AP Sommer 2023 IT-Systeme.pdf
- internal:Alte AP2 Pruefungen/Sommer 2023 - ITSE (AO2023)_AP Sommer 2023 IT-Systeme
  Belegsatz.pdf
- internal:Alte AP2 Pruefungen/Sommer 2023 - ITSE (AO2023)_AP Sommer 2023 IT-Systeme
  Loesung.pdf
- internal:Alte AP2 Pruefungen/Sommer 2023 - ITSE (AO2023)_AP Sommer 2023 IT-Systeme
  Loesung Belegsatz.pdf
- internal:Altklausur-Dateien
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: pruefung
---
## Kontext & Grundlagen (Voraussetzungen)
Diese Datei ist **keine** Abschrift der Klausur, sondern eine pruefungsorientierte Analyse: Welche Themen tauchen in diesem Bereich typischerweise auf, und welche Skills solltest du dafuer trainieren.

## Typische Aufgabentypen in IT-Systeme
- Rechnen (z.B. Strom/Leistung/Spannungsfall) - falls IT-Systeme elektrotechnisch ist
- Betriebsmittel erkennen und begruenden (Schutzorgane, Schaltungen)
- Mess-/Pruefablauf beschreiben und Protokoll bewerten
- Begriffe kurz erklaeren (Norm-/Sicherheitslogik)

## Lernfokus (was du sitzen haben" solltest)
### Kernwissen
- [[spannung-strom-ohm|U/I/R & Ohm]]
- [[leistung-energie-drehstrom-cosphi|Leistung & Drehstrom]]
- [[leitungsdimensionierung-querschnitt-spannungsfall|Leitungsdimensionierung]]
- [[fuenf-sicherheitsregeln|5 Sicherheitsregeln]]
- [[rcd-fi-fehlerstromschutz|RCD/FI]]
- [[ls-leitungsschutzschalter|LS]]
- [[netzformen-tn-tt-it|Netzformen]]

### Training (Aufgabentypen)
- [[komponenten-im-verteilerschrank-benennen|Betriebsmittel benennen]]
- [[aufgabentyp-messprotokoll-vde0100-600|Messprotokoll]]
- [[leitungsdimensionierung-querschnitt-spannungsfall|Dimensionierung Schrittfolge]]

## Typische Fehler & Stolperfallen
- Einheiten fehlen oder kW/W vertauscht
- cos(phi) vergessen (bei AC/Drehstrom)
- In/Iz/Ib durcheinander
- Schutzmassnahmen unvollstaendig begruendet (RCD vs. LS)

## Selbsttest (ohne Loesungen markieren)
- Erklaere die 5 Sicherheitsregeln in richtiger Reihenfolge.
- Rechne einen Drehstromstrom aus P, U, cos(phi) und leite eine Absicherung ab.
- Interpretiere eine unplausible N-PE Messung: moegliche Ursachen?

## Siehe auch
- [[pruefung-nach-vde-0100-600|VDE 0100-600]]
- [[erdung-potentialausgleich|Erdung/PA]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
