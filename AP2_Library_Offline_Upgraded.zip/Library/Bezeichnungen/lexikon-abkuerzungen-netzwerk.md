---
title: Lexikon Abkuerzungen Netzwerk
tags:
- bezeichnungen
- netzwerk
- abkuerzungen
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: lexikon
topic_area: bezeichnungen
---
## Kontext & Grundlagen (Voraussetzungen)
In Netzwerkaufgaben werden viele Abkuerzungen genutzt. Dieses Blatt ist eine schnelle Entschluesselung + Kontext.

## Pruefungsnahe Anwendung
Bei jeder Abkuerzung:
- Layer/Schicht zuordnen (L2/L3/L4/Anwendung)
- Zweck notieren (Segmentierung, Sicherheit, Verfuegbarkeit)
- typischen Einsatz im AP2-Szenario nennen

## Typische Fehler & Stolperfallen
- NAT, Firewall, Routing werden vermischt.
- VLAN und Subnet werden gleichgesetzt.

## Mini-Beispiel
"STP Problem" -> Symptom: Loop/Broadcast-Storm, Massnahme: STP/RSTP korrekt, Loop vermeiden.

## Abkuerzungen (Kurz)
- VLAN: Virtuelles LAN (Layer-2 Segmentierung).
- Trunk: Port, der mehrere VLANs transportiert (Tagged Frames).
- STP/RSTP: Spanning Tree (Loop-Vermeidung im Switch-Netz).
- LACP: Link Aggregation Control Protocol (Bndelung).
- DHCP: Zuweisung von IP-Konfig (IP, GW, DNS).
- DNS: Namensaufloesung.
- NAT: Network Address Translation.
- ACL: Access Control List (Regeln/Filter).
- QoS/DSCP: Priorisierung/Markierung von Traffic.
- VPN: Virtuelles privates Netz (z.B. IPsec, WireGuard).
