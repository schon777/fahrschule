---
title: Lexikon Bezeichnungen (Master)
tags:
- bezeichnungen
- lexikon
- ap2
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: lexikon
topic_area: bezeichnungen
---
## Kontext & Grundlagen (Voraussetzungen)
In AP2-Aufgaben kommen oft "random" Bezeichnungen/Abkuerzungen vor. Dieses Lexikon hilft, Begriffe schnell zu dekodieren.

## Pruefungsnahe Anwendung
Wenn in der Aufgabe eine Bezeichnung auftaucht:
1) Begriff im Lexikon suchen
2) Bedeutung + Kontext notieren
3) Verwechslungsgefahr pruefen
4) Dann erst planen/rechnen/dokumentieren

## Typische Fehler & Stolperfallen
- Bezeichnung wird nur "ungefaehr" geraten und daraus falsche Entscheidungen abgeleitet.
- Schirmung/Category/OM-OS werden vermischt.

## Mini-Beispiel
"U/UTP" -> ungeschirmt, nur Adernpaare verdrillt. Konsequenz: EMV-Umgebung beachten.

## Kapitel
- [[lexikon-kabel-installationsleitungen|Installationsleitungen (NYM, NYY, ...)]]
- [[lexikon-kabel-harmonisiert-flexible-leitungen|Harmonisiert/Flexible Leitungen (H05..., H07...)]]
- [[lexikon-netzwerk-verkabelung|Netzwerk-Verkabelung (Cat, Schirmung, Stecker)]]
- [[lexikon-lwl|LWL (OM/OS, Stecker, Begriffe)]]
- [[lexikon-abkuerzungen-netzwerk|Netzwerk-Abkuerzungen (VLAN, STP, ...)]]
