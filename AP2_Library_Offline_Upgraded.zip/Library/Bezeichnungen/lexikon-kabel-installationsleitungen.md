---
title: 'Lexikon Kabel: Installationsleitungen'
tags:
- bezeichnungen
- kabel
- installation
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: lexikon
topic_area: bezeichnungen
---
## Kontext & Grundlagen (Voraussetzungen)
Installationsleitungen werden in der Gebaeudeinstallation genutzt (feste Verlegung). In Aufgaben tauchen Bezeichnungen wie NYM-J oder NYY-J auf.

## Pruefungsnahe Anwendung
Merke: Die Bezeichnung ist ein Hinweis auf Einsatz (innen/ausserhalb), Aufbau (Adern, Mantel) und ob ein Schutzleiter vorhanden ist.

## Typische Fehler & Stolperfallen
- "-J" und "-O" werden verwechselt (Schutzleiter vorhanden vs nicht vorhanden).
- NYM (innen/Installation) wird pauschal fuer alle Umgebungen angenommen (z.B. Erdreich) -> Kontext pruefen.

## Mini-Beispiel
Aufgabe: "Zuleitung in Gebaeude (Unterputz)". -> NYM-J ist eine typische Installationsleitung (Kontext checken).

## Begriffe
- NYM-J: Installationsleitung (PVC), mit gruen-gelbem Schutzleiter ("J").
- NYM-O: wie NYM, aber ohne Schutzleiter ("O").
- NYY-J: Mantelleitung (PVC) fuer robustere Umgebungen; Einsatzkontext pruefen.
- Adernfarben (typisch): braun/schwarz/grau (Aussenleiter), blau (N), gruen-gelb (PE). (Hinweis: immer Aufgabe/Normkontext pruefen.)
