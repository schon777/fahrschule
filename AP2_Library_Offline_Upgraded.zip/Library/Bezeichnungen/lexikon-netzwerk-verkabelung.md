---
title: 'Lexikon Netzwerk: Verkabelung/Schirmung'
tags:
- bezeichnungen
- netzwerk
- verkabelung
- schirmung
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: lexikon
topic_area: bezeichnungen
---
## Kontext & Grundlagen (Voraussetzungen)
In Netzwerkaufgaben tauchen Bezeichnungen zu Kabelkategorien, Schirmung und Steckern auf. Das entscheidet EMV-Verhalten, Reichweite und Eignung.

## Pruefungsnahe Anwendung
- Kategorie (Cat) / Klasse: hilft bei der Einordnung der Leistungsfaehigkeit.
- Schirmung: beschreibt EMV-Schutz (gesamt/paare).
- Stecker/Anschluss: z.B. 8P8C ("RJ45" umgangssprachlich).

## Typische Fehler & Stolperfallen
- "RJ45" wird als exakte Steckernorm verwendet (oft umgangssprachlich fuer 8P8C).
- Schirmungscodes werden falsch gelesen (F/UTP vs S/FTP).

## Mini-Beispiel
In einer EMV-stoerreichen Umgebung (Motoren/Umrichter) ist eine geschirmte Variante plausibel zu begruenden.

## Kabelkategorien (grob)
- Cat5e / Cat6 / Cat6A: haeufig in Gebaeude-LAN.
- Cat7/7A: oft mit geschirmtem Aufbau, je nach Installationspraxis.

## Schirmungsbezeichnungen (ISO/IEC-Logik)
Format: Gesamtschirm / Paarschirm
- U/UTP: ungeschirmt / ungeschirmte Paare
- F/UTP: Folienschirm gesamt / Paare ungeschirmt
- S/FTP: Geflechtschirm gesamt / Paare foliengeschirmt
- F/FTP: Folienschirm gesamt / Paare foliengeschirmt

## Stecker
- 8P8C: typische Steckverbindung fuer Ethernet-Kupfer (umgangssprachlich "RJ45").
- Keystone/LSA: typische Anschlusstechnik in Dosen/Patchfeldern.
