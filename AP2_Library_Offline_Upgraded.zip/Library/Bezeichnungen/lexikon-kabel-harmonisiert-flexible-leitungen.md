---
title: 'Lexikon Kabel: Harmonisiert/Flexible Leitungen'
tags:
- bezeichnungen
- kabel
- harmonisiert
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: lexikon
topic_area: bezeichnungen
---
## Kontext & Grundlagen (Voraussetzungen)
Flexible Leitungen und harmonisierte Leitungen tauchen in AP2 oft bei Anschlussleitungen, Maschinen, Verlaengerungen, bewegten Teilen auf.

## Pruefungsnahe Anwendung
Die Kennzeichnung Hxx... gibt Hinweise auf Standardisierung, Spannungsbereich (Ziffern) und Material (V=PVC, R=Gummi, N=Neopren o.a.). In der Pruefung reicht meist die grobe Einordnung + geeigneter Einsatz.

## Typische Fehler & Stolperfallen
- H05 und H07 werden als "egal" betrachtet, obwohl die Kennzahl den Spannungs-/Einsatzbereich beschreibt.
- Verwechslungsgefahr: Leitungstyp vs Querschnitt/Belastbarkeit (das sind zwei getrennte Themen).

## Mini-Beispiel
"H07RN-F" -> robuste Gummileitung, flexibel, oft fuer Baustelle/Outdoor-Kontext. (Einsatz immer begruenden.)

## Beispiele (Kurzdekodierung)
- H05VV-F: harmonisiert, PVC/PVC, flexibel (typisch: Geraete-/Verlaengerungsleitung innen).
- H07RN-F: harmonisiert, Gummi-Aderisolierung + robuster Mantel, flexibel (typisch: rauere Umgebung).
