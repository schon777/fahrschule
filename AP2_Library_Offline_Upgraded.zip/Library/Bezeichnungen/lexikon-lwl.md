---
title: Lexikon LWL
tags:
- bezeichnungen
- lwl
- fiber
priority: P2
exam_relevance: mittel
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: lexikon
topic_area: bezeichnungen
---
## Kontext & Grundlagen (Voraussetzungen)
LWL (Glasfaser) kommt in AP2 bei Backbone, langen Strecken, EMV-kritischen Bereichen oder hohen Bandbreiten.

## Pruefungsnahe Anwendung
Merke grob:
- OM = Multimode (kurzere Strecken, haeufig im Gebaeude/Backbone)
- OS = Singlemode (laengere Strecken)
Steckertypen (LC/SC) sind haeufige Begriffe.

## Typische Fehler & Stolperfallen
- OM und OS werden vertauscht.
- Steckerform wird mit Fasertyp gleichgesetzt (das sind getrennte Dinge).

## Mini-Beispiel
Wenn lange Strecke zwischen Gebaeuden: Singlemode (OS) ist haeufig plausibel.

## Begriffe
- OM1/OM2/OM3/OM4/OM5: Multimode-Klassen (Details streckenabhaengig).
- OS1/OS2: Singlemode-Klassen (Details streckenabhaengig).
- LC: kleiner Steckertyp (haeufig in Patchpanels/SFP).
- SC: groesserer Steckertyp (ebenfalls haeufig).
