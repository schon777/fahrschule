---
title: Cloud-Services - IaaS/PaaS/SaaS, Vor- und Nachteile
tags:
- it-systeme
- cloud
- iaas
- paas
- saas
- ap2
priority: P2+P3
exam_relevance: mittel
sources:
- internal:IT/Ernstmeier/Cloud Service/Inhalte.txt
- internal:IT/Ernstmeier/Cloud Service/CloudServices.pptx
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: itsysteme
---
## Kontext & Grundlagen (Voraussetzungen)
Cloud wird in AP2 oft als Verstaendnisfrage gestellt oder in Projektszenarien (Betrieb, Datenschutz, Kosten). Voraussetzungen:
- Grundidee Dienstmodell vs. Eigenbetrieb
- Sicherheits- und Verfuegbarkeitsaspekte (siehe [[cia-triad-datenschutz-datensicherheit|CIA-Triade]])

## Service-Modelle
- **IaaS (Infrastructure as a Service)**: virtuelle Infrastruktur (VMs, Storage, Netz).
- **PaaS (Platform as a Service)**: Laufzeit/Plattform (z.B. App-Hosting), weniger Admin-Aufwand.
- **SaaS (Software as a Service)**: fertige Anwendung (z.B. Mail, Office).

Merksatz: *Je weiter Richtung SaaS, desto weniger musst du selbst betreiben.*

## Vor- und Nachteile (pruefungsnah)
Vorteile:
- Skalierbarkeit, schnelle Bereitstellung
- oft hoehere Verfuegbarkeit durch Provider-Design
- Kostenmodell OPEX statt CAPEX (je nach Darstellung)

Nachteile/Risiken:
- Datenschutz/Compliance
- Abhaengigkeit vom Provider
- Internetanbindung als kritischer Faktor
- Kostenkontrolle (laufende Gebuehren)

## Typische Fehler & Stolperfallen
- Cloud als immer billiger" darstellen (kommt auf Nutzung an).
- Verantwortlichkeiten (Shared Responsibility) ignorieren.

## Siehe auch
- [[backupverfahren-3-2-1-generationenprinzip|Backup]]
- [[vpn-grundlagen-ipsec-ssl|VPN]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
