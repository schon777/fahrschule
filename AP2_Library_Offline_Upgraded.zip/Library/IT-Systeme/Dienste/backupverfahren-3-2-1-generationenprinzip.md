---
title: Backupverfahren - Voll/inkrementell/differentiell, 3-2-1 und Generationenprinzip
tags:
- it-systeme
- backup
- datensicherung
- 3-2-1
- inkrementell
- differentiell
- generationenprinzip
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Datenschutz und Datensicherheit Backupverfahren/Begriffe.txt
- internal:IT/Ernstmeier/Datenschutz und Datensicherheit Backupverfahren/Backup.pdf
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: itsysteme
---
## Kontext & Grundlagen (Voraussetzungen)
Backup ist ein AP2-Dauerbrenner: Verfahren erklaeren, Entscheidung begruenden, Wiederherstellungsstrategie. Voraussetzungen:
- CIA-Triade (siehe [[cia-triad-datenschutz-datensicherheit|Verfuegbarkeit]])
- Grundidee Restore vs. Backup

## Backuparten (pruefungsnah)
- **Vollbackup**: kompletter Datenbestand.
- **Inkrementell**: sichert nur Aenderungen seit dem letzten Backup (egal ob Voll oder inkrementell).
- **Differentiell**: sichert Aenderungen seit dem letzten Vollbackup.

Merksatz: *Inkrementell spart am meisten pro Lauf, Restore braucht aber mehrere Stufen.*

## Generationenprinzip (Grossvater-Vater-Sohn)
- **Sohn**: taegliche Sicherungen (kurzlebig)
- **Vater**: woechentlich
- **Grossvater**: monatlich/jaehrlich
Ziel: Wiederherstellung auch bei spaet entdeckten Fehlern (z.B. schleichende Datenkorruption, Ransomware).

## 3-2-1-Regel
- 3 Kopien der Daten
- 2 unterschiedliche Medien/Technologien
- 1 Kopie extern/offsite (oder logisch getrennt)

## Typische Fehler & Stolperfallen
- Backup = RAID (RAID ist keine Datensicherung).
- Restore-Prozess nicht mitdenken (Zeitfenster, RPO/RTO).
- Offsite/Immutable vergessen (Ransomware-Szenario).

## Siehe auch
- [[raid-grundlagen|RAID]]
- [[cia-triad-datenschutz-datensicherheit|CIA-Triade]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
