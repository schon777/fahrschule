---
title: RAID - Level 0/1/5/6/10, Nutzen und Grenzen
tags:
- it-systeme
- raid
- speicher
- redundanz
- ap2
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Datenschutz und Datensicherheit RAID/RAID.pdf
- internal:IT/Ernstmeier/Wiederholung/Stichpunkte.txt
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: itsysteme
---
## Kontext & Grundlagen (Voraussetzungen)
RAID wird in AP2 oft als Konzept- und Rechenthema genutzt (Kapazitaet, Ausfalltoleranz). Voraussetzungen:
- Unterschied Verfuegbarkeit vs. Backup (siehe [[backupverfahren-3-2-1-generationenprinzip|Backup]])

## Definition und Zweck
**RAID** (Redundant Array of Independent Disks) kombiniert mehrere Laufwerke, um
- **Performance** zu erhoehen und/oder
- **Ausfallsicherheit** zu verbessern.

Wichtig: RAID ersetzt kein Backup.

## RAID-Level (Kurzueberblick)
- **RAID 0 (Striping)**: schnell, keine Redundanz (1 Platte kaputt -> alles weg)
- **RAID 1 (Mirroring)**: Spiegelung, 50% Kapazitaet, 1 Platte darf ausfallen (bei 2 Platten)
- **RAID 5**: Paritaet, 1 Platte darf ausfallen, gute Kapazitaet, Write-Penalty
- **RAID 6**: doppelte Paritaet, 2 Platten duerfen ausfallen
- **RAID 10**: Kombination aus Mirror+Stripe, gute Performance + Redundanz, braucht mind. 4 Platten

## Pruefungslogik: Kapazitaet & Toleranz
In Aufgaben wird oft gefragt:
- Wie viel nutzbare Kapazitaet?"
- Wie viele Platten duerfen ausfallen?"
- Welche Variante ist sinnvoll fuer ...?"

## Typische Fehler & Stolperfallen
- RAID 5 bei sehr grossen Platten ohne Rebuild-Risiko zu erwaehnen (je nach Tiefe).
- RAID als Backup verkaufen.
- Kapazitaetsrechnung falsch (kleinste Platte bestimmt).

## Siehe auch
- [[backupverfahren-3-2-1-generationenprinzip|Backup]]
- [[speichernetzwerktechnik-das-nas-san-iscsi-fc|DAS/NAS/SAN/iSCSI]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
