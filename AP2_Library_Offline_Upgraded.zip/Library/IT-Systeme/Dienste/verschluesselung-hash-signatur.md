---
title: Verschluesselung, Hash und digitale Signatur - symmetrisch/asymmetrisch/hybrid
tags:
- it-systeme
- sicherheit
- verschluesselung
- hash
- signatur
- rsa
- aes
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Verschluesselung/Aspekte.txt
- internal:IT/Ernstmeier/Datenschutz und Datensicherheit/Begriffe.txt
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: itsysteme
---
## Kontext & Grundlagen (Voraussetzungen)
Krypto-Grundlagen tauchen in AP2 haeufig als Begriffs- und Konzeptfragen auf (VPN, TLS, Signaturen, Hashwerte). Voraussetzungen:
- CIA-Triade (siehe [[cia-triad-datenschutz-datensicherheit|Vertraulichkeit/Integritaet]])
- Grundidee Schluessel/Geheimnis

## Symmetrische Verschluesselung
- gleicher Schluessel zum Ver- und Entschluesseln
- schnell, gut fuer grosse Datenmengen
Beispiel: AES (je nach Aufgabenstellung)

## Asymmetrische Verschluesselung
- Schluesselpaar: **public** und **private**
- langsam, gut fuer Schluesselaustausch/Signaturen
Beispiel: RSA (je nach Aufgabenstellung)

## Hybride Verfahren (typisch in der Praxis)
Viele Systeme kombinieren beides:
- asymmetrisch: sicheren Sitzungsschluessel aushandeln
- symmetrisch: Datenstrom verschluesseln

## Hash-Wert
Ein Hash ist ein Fingerabdruck" von Daten:
- gleiche Eingabe -> gleicher Hash
- kleine Aenderung -> grosser Unterschied
Hash dient Integritaetspruefung, nicht Verschluesselung.

## Digitale Signatur (Grundidee)
- Absender signiert Hash mit **privatem** Schluessel
- Empfaenger prueft Signatur mit **oeffentlichem** Schluessel
Ergebnis: Integritaet + Authentizitaet (und oft Nichtabstreitbarkeit)

## Typische Fehler & Stolperfallen
- Hash als Verschluesselung erklaeren (falsch).
- Public/Private Key vertauschen.
- Signatur und Verschluesselung gleichsetzen (Signatur schuetzt Integritaet/Absender, Verschluesselung schuetzt Vertraulichkeit).

## Siehe auch
- [[vpn-grundlagen-ipsec-ssl|VPN]]
- [[firewall-dmz-nat|Firewall]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
