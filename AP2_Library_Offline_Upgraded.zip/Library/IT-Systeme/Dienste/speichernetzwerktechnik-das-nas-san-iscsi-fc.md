---
title: Speichernetzwerktechnik - DAS, NAS, SAN, iSCSI, Fibre Channel
tags:
- it-systeme
- storage
- das
- nas
- san
- iscsi
- fibre-channel
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Speichernetzwerktechnik/Inhalte.txt
- internal:IT/Ernstmeier/Speichernetzwerktechnik/Speichernetzwerktechnik.pdf
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: itsysteme
---
## Kontext & Grundlagen (Voraussetzungen)
Speicheranbindung ist in AP2 haeufiges Konzeptwissen (Serverraum, Backup, Virtualisierung). Voraussetzungen:
- Grundidee Netzwerk vs. lokal
- Unterschied Datei- vs. Blockzugriff (wenn Aufgabe das anspricht)

## DAS (Direct Attached Storage)
- Speicher direkt am Server (SATA/SAS/USB).
- Einfach, geringe Komplexitaet, aber begrenzt skalierbar/teilbar.

## NAS (Network Attached Storage)
- Dateibasierter Zugriff ueber Netzwerk (z.B. SMB/NFS).
- Gut fuer File-Services, zentraler Speicher, einfache Administration.

## SAN (Storage Area Network)
- Blockbasierter Zugriff (LUNs), wirkt fuer Server wie lokale Platte".
- Hohe Performance/Skalierung, mehr Komplexitaet.

## iSCSI und Fibre Channel (Kurz)
- **iSCSI**: SCSI ueber IP/Ethernet (SAN ueber normales Netzwerk, getrenntes VLAN empfohlen).
- **Fibre Channel (FC)**: eigenes Storage-Netz (dedizierte Technik, hohe Performance).

## Pruefungslogik: Auswahl begruenden
- File-Share fuer Nutzer -> NAS
- hochperformanter Storage fuer Cluster/VMs -> SAN (iSCSI/FC)
- einzelner Server mit lokalem Speicher -> DAS

## Typische Fehler & Stolperfallen
- NAS und SAN gleichsetzen.
- iSCSI ohne Netzwerk-Segmentierung/QoS planen.
- Backup mit Storage verwechseln (Storage ist nicht automatisch Backup).

## Siehe auch
- [[raid-grundlagen|RAID]]
- [[backupverfahren-3-2-1-generationenprinzip|Backup]]
- [[virtualisierung-hypervisor-grundlagen|Virtualisierung]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
