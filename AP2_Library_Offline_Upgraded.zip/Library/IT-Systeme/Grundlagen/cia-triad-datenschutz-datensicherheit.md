---
title: Datensicherheit vs. Datenschutz und CIA-Triade (Vertraulichkeit, Integritaet,
  Verfuegbarkeit)
tags:
- it-systeme
- sicherheit
- datenschutz
- datensicherheit
- cia
- integritaet
- verfuegbarkeit
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Datenschutz und Datensicherheit/Begriffe.txt
- internal:IT/Ernstmeier/Datenschutz und Datensicherheit/(P)Integritaet etc.pdf
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: itsysteme
---
## Kontext & Grundlagen (Voraussetzungen)
In AP2 werden Sicherheitsbegriffe haeufig abgefragt, oft als Begruendung: Warum Backup?", Warum Verschluesselung?", Welche Massnahme erhoeht Verfuegbarkeit?". Voraussetzungen:
- Grundidee Risiko/Bedrohung
- Unterschied technische vs. organisatorische Massnahmen

## Datenschutz vs. Datensicherheit (kurz)
- **Datenschutz**: Schutz personenbezogener Daten (rechtlich/organisatorisch, z.B. DSGVO-Kontext).
- **Datensicherheit**: Schutz von Daten allgemein (technisch/organisatorisch) gegen Verlust, Manipulation, unbefugten Zugriff.

## CIA-Triade (Kernbegriffe)
- **Vertraulichkeit (Confidentiality)**: nur Berechtigte duerfen lesen.
- **Integritaet (Integrity)**: Daten duerfen nicht unbemerkt veraendert werden.
- **Verfuegbarkeit (Availability)**: Systeme/Daten sind bei Bedarf verfuegbar.

Typische Zuordnung:
- Verschluesselung -> Vertraulichkeit
- Hash/Signatur -> Integritaet/Authentizitaet
- USV/Backup/Redundanz -> Verfuegbarkeit

## Authentizitaet (Zusatz)
Authentizitaet bedeutet: Ist der Absender/Urheber echt?" - oft ueber Zertifikate/Signaturen.

## Typische Fehler & Stolperfallen
- Datenschutz und Datensicherheit gleichsetzen.
- Backup = Integritaet" (Backup dient primaer der Wiederherstellung/Verfuegbarkeit; Integritaet ist eher Hash/Signatur/Checks).

## Siehe auch
- [[backupverfahren-3-2-1-generationenprinzip|Backup]]
- [[raid-grundlagen|RAID]]
- [[verschluesselung-hash-signatur|Verschluesselung/Hash/Signatur]]
- [[usv-grundlagen|USV]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
