---
title: Virtualisierung & Hypervisor - Typ 1/Typ 2, Nutzen, typische Risiken
tags:
- it-systeme
- virtualisierung
- hypervisor
- server
- ap2
priority: P2+P3
exam_relevance: mittel
sources:
- internal:IT/Ernstmeier/Wiederholung/Stichpunkte.txt
- internal:Unterricht
- internal:Eigenes Lernziel
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: itsysteme
---
## Kontext & Grundlagen (Voraussetzungen)
Virtualisierung kann in AP2 als Infrastrukturentscheidung vorkommen (Serverraum, Storage, Backup, Verfuegbarkeit). Voraussetzungen:
- Grundidee Betriebssystem vs. Hardware
- Storage/Netzwerk-Grundlagen (siehe [[speichernetzwerktechnik-das-nas-san-iscsi-fc|Storage]] und [[osi-tcpip-ethernet|Netzwerk]])

## Definition und Zweck
Virtualisierung trennt Workloads (VMs/Container) von physischer Hardware. Vorteile:
- bessere Hardwareauslastung
- schnelle Bereitstellung/Skalierung
- Snapshot/Backup-Konzepte (je nach System)
- Isolation zwischen Systemen

## Hypervisor-Typen (Grundidee)
- **Typ 1 (Bare Metal)**: laeuft direkt auf Hardware (Server-Umfeld).
- **Typ 2 (Hosted)**: laeuft auf einem Host-OS (Desktop/Test).

## Typische Fehler & Stolperfallen
- Snapshot als Backup verkaufen (Snapshot ist oft nur kurzfristig).
- Single Point of Failure ignorieren (ein Host faellt aus -> viele VMs betroffen) -> HA/Cluster noetig.

## Siehe auch
- [[backupverfahren-3-2-1-generationenprinzip|Backup]]
- [[raid-grundlagen|RAID]]
- [[speichernetzwerktechnik-das-nas-san-iscsi-fc|Storage]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
