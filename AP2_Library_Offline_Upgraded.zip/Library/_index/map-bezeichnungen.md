---
title: Map Bezeichnungen
tags:
- bezeichnungen
- map
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: map
topic_area: bezeichnungen
---
## Kontext & Grundlagen (Voraussetzungen)
Diese Map ist ein Einstiegspunkt. Sie verlinkt auf zentrale Notizen und hilft beim schnellen Auffinden von Themen.

## Pruefungsnahe Anwendung
Wenn du eine Aufgabe bekommst, starte hier, gehe zu passenden Unterthemen und nutze Methoden/Templates fuer die Antwortstruktur.

## Typische Fehler & Stolperfallen
- In der Aufgabe zu frueh rechnen/konfigurieren, bevor Begriffe und Ziel klar sind.
- Dokumentation vergessen (Netzplan, Portplan, Messprotokoll).

## Mini-Beispiel
Aufgabe: "Plane VLANs fuer Abteilungen". -> Start: [[vlan-grundlagen|VLAN Grundlagen]] und danach [[checkliste-vlan-plan|Checkliste VLAN-Plan]].

## Links
- Elektrotechnik: siehe Ordner /Elektrotechnik/
- Netzwerk: siehe Ordner /Netzwerk/
- IT-Systeme: siehe Ordner /IT-Systeme/
- Bezeichnungen: siehe [[lexikon-bezeichnungen|Lexikon Bezeichnungen]]
- Templates: siehe /_templates/
- Questionbank: siehe /_questionbank/
