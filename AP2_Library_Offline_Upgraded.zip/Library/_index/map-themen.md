---
title: 'Map: Themenuebersicht (Library)'
tags: []
priority: P2
exam_relevance: mittel
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: map
topic_area: pruefung
---
# Map: Themenuebersicht (Library)

Diese Datei ist dein Einstiegspunkt. Alle Links sind im Format [[dateiname|Anzeigename]].

## Elektrotechnik

### Bauteile

- [[batterie|Batterie - Grundlagen, Kenngroessen und Einsatz in IT/ET]] (Grundlagen; Exam: mittel)
- [[diode|Diode - Einbahnstrasse fuer Strom (Grundprinzip, LED, Schutzdiode)]] (Grundlagen; Exam: niedrig)
- [[gleichrichter|Gleichrichter - AC zu DC (Brueckengleichrichter, Glaettung)]] (Grundlagen; Exam: niedrig)
- [[kondensator|Kondensator - Speichern, Glaetten, Filtern (Grundidee)]] (Grundlagen; Exam: niedrig)
- [[spule|Spule/Induktivitaet - Magnetfeld, Induktionsspannung, Anwendungen]] (Grundlagen; Exam: niedrig)
- [[transformator|Transformator - Spannung anpassen, Trennung, Grundprinzip]] (Grundlagen; Exam: mittel)
- [[transistor|Transistor - Schalten/Verstaerken (Kurzueberblick fuer ITSE)]] (Grundlagen; Exam: niedrig)
- [[wechselrichter|Wechselrichter - DC zu AC (Grundidee, Einsatz in USV/Photovoltaik)]] (Grundlagen; Exam: niedrig)
- [[widerstand|Widerstand - Aufgabe, Bauformen, Kennzeichnung (Kurzueberblick)]] (Grundlagen; Exam: niedrig)

### EMV

- [[emv-grundlagen|EMV - elektromagnetische Vertraeglichkeit (Grundidee, typische Massnahmen)]] (Grundlagen; Exam: niedrig)

### Elektroinstallation

- [[installationszonen|Installationszonen (Wand) - wo Leitungen verlegt werden duerfen (Grundidee)]] (Grundlagen; Exam: mittel)
- [[schaltzeichen-und-stromlaufplaene|Schaltzeichen und Stromlaufplaene lesen - Basics fuer AP2]] (AP2; Exam: mittel)

### Energieversorgung

- [[leitungsdimensionierung-querschnitt-spannungsfall|Leitungsdimensionierung - Querschnitt, Verlegeart, Spannungsfall (AP2-Schema)]] (AP2; Exam: hoch)
- [[usv-grundlagen|USV (Unterbrechungsfreie Stromversorgung) - Zweck, Typen, Auswahl]] (AP2; Exam: mittel)

### Grundlagen

- [[erdung-potentialausgleich|Erdung und Potentialausgleich - Zweck, Aufbau, typische Fehler]] (AP2; Exam: hoch)
- [[leistung-energie-drehstrom-cosphi|Leistung, Energie, Drehstrom, cos(phi) und P-Q-S]] (AP2; Exam: hoch)
- [[spannung-strom-ohm|Spannung, Strom, Widerstand und Ohmsches Gesetz]] (Grundlagen; Exam: hoch)
- [[wechselspannung-grundlagen|Wechselspannung und Wechselstrom-Grundlagen]] (Grundlagen; Exam: mittel)

### Messen-Pruefen

- [[messgeraete-spannungspruefer-multimeter|Messgeraete: zweipoliger Spannungspruefer, Multimeter, Stromzange - richtig einsetzen]] (AP2; Exam: hoch)
- [[pruefung-nach-vde-0100-600|Pruefung nach DIN VDE 0100-600 - Ablauf, Messungen, Dokumentation]] (AP2; Exam: hoch)

### Netzformen

- [[netzformen-tn-tt-it|Netzformen TN/TT/IT - N, PE, PEN und typische Messwerte]] (AP2; Exam: hoch)

### Schutztechnik

- [[ls-leitungsschutzschalter|Leitungsschutzschalter (LS) - Aufgabe, Kennlinien B/C/D, Auswahl]] (AP2; Exam: hoch)
- [[rcd-fi-fehlerstromschutz|RCD/FI - Funktionsweise, IDeltan, Typen und Pruefung]] (AP2; Exam: hoch)
- [[schmelzsicherungen-neozed-diazed|Schmelzsicherungen (DIAZED/NEOZED) - Aufgabe, Einsatz, Vor- und Nachteile]] (AP2; Exam: mittel)
- [[selektivitaet-sls|Selektivitaet und selektiver Leitungsschutzschalter (SLS) - Prinzip]] (AP2; Exam: mittel)

### Sicherheit

- [[fuenf-sicherheitsregeln|Die 5 Sicherheitsregeln (DIN VDE) - sicher arbeiten]] (AP2; Exam: hoch)
- [[schutz-gegen-elektrischen-schlag|Schutz gegen elektrischen Schlag - Schutzmassnahmen und Grundbegriffe]] (AP2; Exam: hoch)

## Netzwerk

### Dienste

- [[dhcp-dns|DHCP und DNS - Basics, typische Fehlersuche]] (AP2; Exam: hoch)

### Grundlagen

- [[ip-adressierung-v4-v6|IP-Adressierung - IPv4 vs. IPv6 (Grundlagen, typische Aufgaben)]] (Grundlagen; Exam: hoch)
- [[osi-tcpip-ethernet|Netzwerk-Grundlagen: OSI/TCP-IP, Ethernet, Frames, MAC und ARP]] (Grundlagen; Exam: hoch)
- [[strukturierte-verkabelung|Strukturierte Verkabelung - Patchpanel, Dosen, Kategorien, Pruefungslogik]] (AP2; Exam: hoch)
- [[subnetting-ipv4|Subnetting IPv4 - schnell und pruefungsfest]] (AP2; Exam: hoch)

### PoE

- [[poe-standards-8023af-at-bt|PoE - IEEE 802.3af/at/bt, Leistungsklassen, typische Planung]] (AP2; Exam: mittel)

### Routing

- [[routing-grundlagen|Routing - Default Gateway, Routing-Tabelle, NAT (Ueberblick)]] (AP2; Exam: hoch)

### Sicherheit

- [[firewall-dmz-nat|Firewall-Techniken, DMZ und NAT - pruefungsnaher Ueberblick]] (AP2; Exam: hoch)

### Switching

- [[switching-mac-table|Switching - MAC-Adress-Tabelle, Broadcast, STP (Grundidee)]] (AP2; Exam: hoch)

### VLAN

- [[vlan-grundlagen-trunk-tagging|VLAN - Access/Trunk, Tagging (802.1Q), typische Fehler]] (AP2; Exam: hoch)

### VPN

- [[vpn-grundlagen-ipsec-ssl|VPN - Site-to-Site vs. Remote, IPsec vs. SSL (Grundidee)]] (AP2; Exam: hoch)

### VoIP

- [[voip-grundlagen-sip-rtp-qos|VoIP - SIP, RTP, Codecs, QoS, Latenz/Jitter (AP2)]] (AP2; Exam: hoch)

### WLAN

- [[wlan-80211-sicherheit|WLAN - 802.11 Grundlagen, Sicherheit (WPA2/WPA3), Planung]] (AP2; Exam: mittel)

## IT-Systeme

### Dienste

- [[backupverfahren-3-2-1-generationenprinzip|Backupverfahren - Voll/inkrementell/differentiell, 3-2-1 und Generationenprinzip]] (AP2; Exam: hoch)
- [[cloud-services-saas-paas-iaas|Cloud-Services - IaaS/PaaS/SaaS, Vor- und Nachteile]] (Grundlagen; Exam: mittel)
- [[raid-grundlagen|RAID - Level 0/1/5/6/10, Nutzen und Grenzen]] (AP2; Exam: hoch)
- [[speichernetzwerktechnik-das-nas-san-iscsi-fc|Speichernetzwerktechnik - DAS, NAS, SAN, iSCSI, Fibre Channel]] (AP2; Exam: hoch)
- [[verschluesselung-hash-signatur|Verschluesselung, Hash und digitale Signatur - symmetrisch/asymmetrisch/hybrid]] (AP2; Exam: hoch)

### Grundlagen

- [[cia-triad-datenschutz-datensicherheit|Datensicherheit vs. Datenschutz und CIA-Triade (Vertraulichkeit, Integritaet, Verfuegbarkeit)]] (AP2; Exam: hoch)

### Virtualisierung

- [[virtualisierung-hypervisor-grundlagen|Virtualisierung & Hypervisor - Typ 1/Typ 2, Nutzen, typische Risiken]] (Grundlagen; Exam: mittel)

## WISO

- [[wiso-arbeitsrecht-sozialversicherung|WISO: Arbeitsrecht & Sozialversicherung - pruefungsnaher Ueberblick]] (Grundlagen; Exam: mittel)
- [[wiso-betrieb-markt-grundbegriffe|WISO: Betrieb & Markt - Grundbegriffe (Kosten, Umsatz, Gewinn, Unternehmensformen)]] (Grundlagen; Exam: mittel)

## Pruefung

### Altklausuren-Analysen

- [[sommer-2023-it-systeme-musteranalyse|Musteranalyse Sommer 2023: IT-Systeme (ITSE)]] (AP2; Exam: hoch)
- [[sommer-2023-powi-wiso-musteranalyse|Musteranalyse Sommer 2023: PoWi/WISO (ITSE)]] (AP2; Exam: mittel)
- [[sommer-2023-strom-musteranalyse|Musteranalyse Sommer 2023: Strom (ITSE)]] (AP2; Exam: hoch)
- [[sommer-2024-it-systeme-musteranalyse|Musteranalyse Sommer 2024: IT-Systeme (ITSE)]] (AP2; Exam: hoch)
- [[sommer-2024-powi-wiso-musteranalyse|Musteranalyse Sommer 2024: PoWi/WISO (ITSE)]] (AP2; Exam: mittel)
- [[sommer-2024-strom-musteranalyse|Musteranalyse Sommer 2024: Strom (ITSE)]] (AP2; Exam: hoch)
- [[winter-2023-2024-it-systeme-musteranalyse|Musteranalyse Winter 2023-2024: IT-Systeme (ITSE)]] (AP2; Exam: hoch)
- [[winter-2023-2024-powi-wiso-musteranalyse|Musteranalyse Winter 2023-2024: PoWi/WISO (ITSE)]] (AP2; Exam: mittel)
- [[winter-2023-2024-strom-musteranalyse|Musteranalyse Winter 2023-2024: Strom (ITSE)]] (AP2; Exam: hoch)

### Aufgabentypen

- [[komponenten-im-verteilerschrank-benennen|Aufgabentyp: Betriebsmittel im Verteilerschrank benennen]] (AP2; Exam: hoch)
- [[aufgabentyp-messprotokoll-vde0100-600|Aufgabentyp: Messprotokoll (VDE 0100-600) ausfuellen und bewerten]] (AP2; Exam: hoch)
- [[aufgabentyp-raid-backup|Aufgabentyp: RAID vs. Backup sauber abgrenzen und begruenden]] (AP2; Exam: hoch)
- [[aufgabentyp-subnetting|Aufgabentyp: Subnetting & IP-Plan in der Pruefung]] (AP2; Exam: hoch)
- [[aufgabentyp-voip-qos|Aufgabentyp: VoIP-Probleme analysieren (QoS, VLAN, Ports)]] (AP2; Exam: hoch)


## Kontext & Grundlagen (Voraussetzungen)
- (Ergaenzen: kurz und pruefungsnah)


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Typische Fehler & Stolperfallen
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
