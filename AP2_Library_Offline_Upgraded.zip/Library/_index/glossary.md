---
title: Glossary (Notenliste)
tags: []
priority: P2
exam_relevance: mittel
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: map
topic_area: pruefung
---
# Glossary (Notenliste)

Alphabetische Liste aller Notizen.

- [[komponenten-im-verteilerschrank-benennen|Aufgabentyp: Betriebsmittel im Verteilerschrank benennen]] - Subject: Pruefung, Level: AP2, Exam: hoch
- [[aufgabentyp-messprotokoll-vde0100-600|Aufgabentyp: Messprotokoll (VDE 0100-600) ausfuellen und bewerten]] - Subject: Pruefung, Level: AP2, Exam: hoch
- [[aufgabentyp-raid-backup|Aufgabentyp: RAID vs. Backup sauber abgrenzen und begruenden]] - Subject: Pruefung, Level: AP2, Exam: hoch
- [[aufgabentyp-subnetting|Aufgabentyp: Subnetting & IP-Plan in der Pruefung]] - Subject: Pruefung, Level: AP2, Exam: hoch
- [[aufgabentyp-voip-qos|Aufgabentyp: VoIP-Probleme analysieren (QoS, VLAN, Ports)]] - Subject: Pruefung, Level: AP2, Exam: hoch
- [[backupverfahren-3-2-1-generationenprinzip|Backupverfahren - Voll/inkrementell/differentiell, 3-2-1 und Generationenprinzip]] - Subject: IT-Systeme, Level: AP2, Exam: hoch
- [[batterie|Batterie - Grundlagen, Kenngroessen und Einsatz in IT/ET]] - Subject: Elektrotechnik, Level: Grundlagen, Exam: mittel
- [[cloud-services-saas-paas-iaas|Cloud-Services - IaaS/PaaS/SaaS, Vor- und Nachteile]] - Subject: IT-Systeme, Level: Grundlagen, Exam: mittel
- [[cia-triad-datenschutz-datensicherheit|Datensicherheit vs. Datenschutz und CIA-Triade (Vertraulichkeit, Integritaet, Verfuegbarkeit)]] - Subject: IT-Systeme, Level: AP2, Exam: hoch
- [[dhcp-dns|DHCP und DNS - Basics, typische Fehlersuche]] - Subject: Netzwerk, Level: AP2, Exam: hoch
- [[fuenf-sicherheitsregeln|Die 5 Sicherheitsregeln (DIN VDE) - sicher arbeiten]] - Subject: Elektrotechnik, Level: AP2, Exam: hoch
- [[diode|Diode - Einbahnstrasse fuer Strom (Grundprinzip, LED, Schutzdiode)]] - Subject: Elektrotechnik, Level: Grundlagen, Exam: niedrig
- [[emv-grundlagen|EMV - elektromagnetische Vertraeglichkeit (Grundidee, typische Massnahmen)]] - Subject: Elektrotechnik, Level: Grundlagen, Exam: niedrig
- [[erdung-potentialausgleich|Erdung und Potentialausgleich - Zweck, Aufbau, typische Fehler]] - Subject: Elektrotechnik, Level: AP2, Exam: hoch
- [[firewall-dmz-nat|Firewall-Techniken, DMZ und NAT - pruefungsnaher Ueberblick]] - Subject: Netzwerk, Level: AP2, Exam: hoch
- [[gleichrichter|Gleichrichter - AC zu DC (Brueckengleichrichter, Glaettung)]] - Subject: Elektrotechnik, Level: Grundlagen, Exam: niedrig
- [[installationszonen|Installationszonen (Wand) - wo Leitungen verlegt werden duerfen (Grundidee)]] - Subject: Elektrotechnik, Level: Grundlagen, Exam: mittel
- [[ip-adressierung-v4-v6|IP-Adressierung - IPv4 vs. IPv6 (Grundlagen, typische Aufgaben)]] - Subject: Netzwerk, Level: Grundlagen, Exam: hoch
- [[kondensator|Kondensator - Speichern, Glaetten, Filtern (Grundidee)]] - Subject: Elektrotechnik, Level: Grundlagen, Exam: niedrig
- [[leistung-energie-drehstrom-cosphi|Leistung, Energie, Drehstrom, cos(phi) und P-Q-S]] - Subject: Elektrotechnik, Level: AP2, Exam: hoch
- [[leitungsdimensionierung-querschnitt-spannungsfall|Leitungsdimensionierung - Querschnitt, Verlegeart, Spannungsfall (AP2-Schema)]] - Subject: Elektrotechnik, Level: AP2, Exam: hoch
- [[ls-leitungsschutzschalter|Leitungsschutzschalter (LS) - Aufgabe, Kennlinien B/C/D, Auswahl]] - Subject: Elektrotechnik, Level: AP2, Exam: hoch
- [[messgeraete-spannungspruefer-multimeter|Messgeraete: zweipoliger Spannungspruefer, Multimeter, Stromzange - richtig einsetzen]] - Subject: Elektrotechnik, Level: AP2, Exam: hoch
- [[sommer-2023-it-systeme-musteranalyse|Musteranalyse Sommer 2023: IT-Systeme (ITSE)]] - Subject: Pruefung, Level: AP2, Exam: hoch
- [[sommer-2023-powi-wiso-musteranalyse|Musteranalyse Sommer 2023: PoWi/WISO (ITSE)]] - Subject: Pruefung, Level: AP2, Exam: mittel
- [[sommer-2023-strom-musteranalyse|Musteranalyse Sommer 2023: Strom (ITSE)]] - Subject: Pruefung, Level: AP2, Exam: hoch
- [[sommer-2024-it-systeme-musteranalyse|Musteranalyse Sommer 2024: IT-Systeme (ITSE)]] - Subject: Pruefung, Level: AP2, Exam: hoch
- [[sommer-2024-powi-wiso-musteranalyse|Musteranalyse Sommer 2024: PoWi/WISO (ITSE)]] - Subject: Pruefung, Level: AP2, Exam: mittel
- [[sommer-2024-strom-musteranalyse|Musteranalyse Sommer 2024: Strom (ITSE)]] - Subject: Pruefung, Level: AP2, Exam: hoch
- [[winter-2023-2024-it-systeme-musteranalyse|Musteranalyse Winter 2023-2024: IT-Systeme (ITSE)]] - Subject: Pruefung, Level: AP2, Exam: hoch
- [[winter-2023-2024-powi-wiso-musteranalyse|Musteranalyse Winter 2023-2024: PoWi/WISO (ITSE)]] - Subject: Pruefung, Level: AP2, Exam: mittel
- [[winter-2023-2024-strom-musteranalyse|Musteranalyse Winter 2023-2024: Strom (ITSE)]] - Subject: Pruefung, Level: AP2, Exam: hoch
- [[netzformen-tn-tt-it|Netzformen TN/TT/IT - N, PE, PEN und typische Messwerte]] - Subject: Elektrotechnik, Level: AP2, Exam: hoch
- [[osi-tcpip-ethernet|Netzwerk-Grundlagen: OSI/TCP-IP, Ethernet, Frames, MAC und ARP]] - Subject: Netzwerk, Level: Grundlagen, Exam: hoch
- [[poe-standards-8023af-at-bt|PoE - IEEE 802.3af/at/bt, Leistungsklassen, typische Planung]] - Subject: Netzwerk, Level: AP2, Exam: mittel
- [[pruefung-nach-vde-0100-600|Pruefung nach DIN VDE 0100-600 - Ablauf, Messungen, Dokumentation]] - Subject: Elektrotechnik, Level: AP2, Exam: hoch
- [[raid-grundlagen|RAID - Level 0/1/5/6/10, Nutzen und Grenzen]] - Subject: IT-Systeme, Level: AP2, Exam: hoch
- [[rcd-fi-fehlerstromschutz|RCD/FI - Funktionsweise, IDeltan, Typen und Pruefung]] - Subject: Elektrotechnik, Level: AP2, Exam: hoch
- [[routing-grundlagen|Routing - Default Gateway, Routing-Tabelle, NAT (Ueberblick)]] - Subject: Netzwerk, Level: AP2, Exam: hoch
- [[schaltzeichen-und-stromlaufplaene|Schaltzeichen und Stromlaufplaene lesen - Basics fuer AP2]] - Subject: Elektrotechnik, Level: AP2, Exam: mittel
- [[schmelzsicherungen-neozed-diazed|Schmelzsicherungen (DIAZED/NEOZED) - Aufgabe, Einsatz, Vor- und Nachteile]] - Subject: Elektrotechnik, Level: AP2, Exam: mittel
- [[schutz-gegen-elektrischen-schlag|Schutz gegen elektrischen Schlag - Schutzmassnahmen und Grundbegriffe]] - Subject: Elektrotechnik, Level: AP2, Exam: hoch
- [[selektivitaet-sls|Selektivitaet und selektiver Leitungsschutzschalter (SLS) - Prinzip]] - Subject: Elektrotechnik, Level: AP2, Exam: mittel
- [[spannung-strom-ohm|Spannung, Strom, Widerstand und Ohmsches Gesetz]] - Subject: Elektrotechnik, Level: Grundlagen, Exam: hoch
- [[speichernetzwerktechnik-das-nas-san-iscsi-fc|Speichernetzwerktechnik - DAS, NAS, SAN, iSCSI, Fibre Channel]] - Subject: IT-Systeme, Level: AP2, Exam: hoch
- [[spule|Spule/Induktivitaet - Magnetfeld, Induktionsspannung, Anwendungen]] - Subject: Elektrotechnik, Level: Grundlagen, Exam: niedrig
- [[strukturierte-verkabelung|Strukturierte Verkabelung - Patchpanel, Dosen, Kategorien, Pruefungslogik]] - Subject: Netzwerk, Level: AP2, Exam: hoch
- [[subnetting-ipv4|Subnetting IPv4 - schnell und pruefungsfest]] - Subject: Netzwerk, Level: AP2, Exam: hoch
- [[switching-mac-table|Switching - MAC-Adress-Tabelle, Broadcast, STP (Grundidee)]] - Subject: Netzwerk, Level: AP2, Exam: hoch
- [[transformator|Transformator - Spannung anpassen, Trennung, Grundprinzip]] - Subject: Elektrotechnik, Level: Grundlagen, Exam: mittel
- [[transistor|Transistor - Schalten/Verstaerken (Kurzueberblick fuer ITSE)]] - Subject: Elektrotechnik, Level: Grundlagen, Exam: niedrig
- [[usv-grundlagen|USV (Unterbrechungsfreie Stromversorgung) - Zweck, Typen, Auswahl]] - Subject: Elektrotechnik, Level: AP2, Exam: mittel
- [[verschluesselung-hash-signatur|Verschluesselung, Hash und digitale Signatur - symmetrisch/asymmetrisch/hybrid]] - Subject: IT-Systeme, Level: AP2, Exam: hoch
- [[virtualisierung-hypervisor-grundlagen|Virtualisierung & Hypervisor - Typ 1/Typ 2, Nutzen, typische Risiken]] - Subject: IT-Systeme, Level: Grundlagen, Exam: mittel
- [[vlan-grundlagen-trunk-tagging|VLAN - Access/Trunk, Tagging (802.1Q), typische Fehler]] - Subject: Netzwerk, Level: AP2, Exam: hoch
- [[voip-grundlagen-sip-rtp-qos|VoIP - SIP, RTP, Codecs, QoS, Latenz/Jitter (AP2)]] - Subject: Netzwerk, Level: AP2, Exam: hoch
- [[vpn-grundlagen-ipsec-ssl|VPN - Site-to-Site vs. Remote, IPsec vs. SSL (Grundidee)]] - Subject: Netzwerk, Level: AP2, Exam: hoch
- [[wechselrichter|Wechselrichter - DC zu AC (Grundidee, Einsatz in USV/Photovoltaik)]] - Subject: Elektrotechnik, Level: Grundlagen, Exam: niedrig
- [[wechselspannung-grundlagen|Wechselspannung und Wechselstrom-Grundlagen]] - Subject: Elektrotechnik, Level: Grundlagen, Exam: mittel
- [[widerstand|Widerstand - Aufgabe, Bauformen, Kennzeichnung (Kurzueberblick)]] - Subject: Elektrotechnik, Level: Grundlagen, Exam: niedrig
- [[wiso-arbeitsrecht-sozialversicherung|WISO: Arbeitsrecht & Sozialversicherung - pruefungsnaher Ueberblick]] - Subject: WISO, Level: Grundlagen, Exam: mittel
- [[wiso-betrieb-markt-grundbegriffe|WISO: Betrieb & Markt - Grundbegriffe (Kosten, Umsatz, Gewinn, Unternehmensformen)]] - Subject: WISO, Level: Grundlagen, Exam: mittel
- [[wlan-80211-sicherheit|WLAN - 802.11 Grundlagen, Sicherheit (WPA2/WPA3), Planung]] - Subject: Netzwerk, Level: AP2, Exam: mittel

## Kontext & Grundlagen (Voraussetzungen)
- (Ergaenzen: kurz und pruefungsnah)


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Typische Fehler & Stolperfallen
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
