---
title: Consistency Checks
tags:
- pruefung
- pitfalls
- consistency
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: map
topic_area: pruefung
---
## Kontext & Grundlagen (Voraussetzungen)
Diese Liste sammelt Begriffe, die in AP2-Aufgaben haeufig verwechselt werden. Ziel: schneller Check, ob du das richtige Konzept nutzt.

## Pruefungsnahe Anwendung
Nutze die Liste beim Loesen von Szenarien: Wenn du merkst, dass Begriffe unscharf sind, wechsle in die passende Notiz und pruefe Definition + Einsatz.

## Typische Fehler & Stolperfallen
- Begriffe werden synonym genutzt, obwohl sie unterschiedliche Schichten/Layer betreffen.
- "RAID ersetzt Backup" (falsch) wird oft unreflektiert angenommen.

## Mini-Beispiel
Wenn eine Aufgabe nach "Sicherung" fragt: Erst klaeren ob Backup/Restore, Redundanz, oder Schutz (PE/LS/RCD) gemeint ist.

## Hauefige Verwechslungen (Kurzcheck)
- VLAN vs Subnet: VLAN ist Layer-2 Segmentierung, Subnet ist Layer-3 Adressraum.
- NAT vs Routing: NAT aendert Adressen, Routing entscheidet den Pfad.
- Switch (L2) vs Router (L3): Weiterleitung nach MAC vs nach IP.
- RAID vs Backup: RAID = Verfuegbarkeit/Redundanz, Backup = Wiederherstellung nach Fehler/Loeschung/Ransomware.
- TLS vs IPsec: TLS meist Ende-zu-Ende auf Anwendungsebene, IPsec auf Netzwerkebene (Tunnel/Transport).
- DHCP vs DNS: DHCP vergibt Konfig, DNS uebersetzt Namen.
- Port vs Protokoll: Port ist Nummer, Protokoll ist Regelwerk (TCP/UDP/ICMP).
- RCD (FI) vs LS: RCD = Fehlerstromschutz, LS = Ueberstromschutz.
