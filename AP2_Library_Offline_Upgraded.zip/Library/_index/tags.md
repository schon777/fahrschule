---
title: Tags (Index)
tags: []
priority: P2
exam_relevance: mittel
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: map
topic_area: pruefung
---
# Tags (Index)

Hinweis: Tags sind in YAML-Frontmatter gespeichert.

## elektrotechnik (29)

- [[komponenten-im-verteilerschrank-benennen|Aufgabentyp: Betriebsmittel im Verteilerschrank benennen]]
- [[aufgabentyp-messprotokoll-vde0100-600|Aufgabentyp: Messprotokoll (VDE 0100-600) ausfuellen und bewerten]]
- [[batterie|Batterie - Grundlagen, Kenngroessen und Einsatz in IT/ET]]
- [[fuenf-sicherheitsregeln|Die 5 Sicherheitsregeln (DIN VDE) - sicher arbeiten]]
- [[diode|Diode - Einbahnstrasse fuer Strom (Grundprinzip, LED, Schutzdiode)]]
- [[emv-grundlagen|EMV - elektromagnetische Vertraeglichkeit (Grundidee, typische Massnahmen)]]
- [[erdung-potentialausgleich|Erdung und Potentialausgleich - Zweck, Aufbau, typische Fehler]]
- [[gleichrichter|Gleichrichter - AC zu DC (Brueckengleichrichter, Glaettung)]]
- [[installationszonen|Installationszonen (Wand) - wo Leitungen verlegt werden duerfen (Grundidee)]]
- [[kondensator|Kondensator - Speichern, Glaetten, Filtern (Grundidee)]]
- [[leistung-energie-drehstrom-cosphi|Leistung, Energie, Drehstrom, cos(phi) und P-Q-S]]
- [[leitungsdimensionierung-querschnitt-spannungsfall|Leitungsdimensionierung - Querschnitt, Verlegeart, Spannungsfall (AP2-Schema)]]
- ... (17 weitere)

## pruefung (17)

- [[komponenten-im-verteilerschrank-benennen|Aufgabentyp: Betriebsmittel im Verteilerschrank benennen]]
- [[aufgabentyp-messprotokoll-vde0100-600|Aufgabentyp: Messprotokoll (VDE 0100-600) ausfuellen und bewerten]]
- [[aufgabentyp-raid-backup|Aufgabentyp: RAID vs. Backup sauber abgrenzen und begruenden]]
- [[aufgabentyp-subnetting|Aufgabentyp: Subnetting & IP-Plan in der Pruefung]]
- [[aufgabentyp-voip-qos|Aufgabentyp: VoIP-Probleme analysieren (QoS, VLAN, Ports)]]
- [[fuenf-sicherheitsregeln|Die 5 Sicherheitsregeln (DIN VDE) - sicher arbeiten]]
- [[erdung-potentialausgleich|Erdung und Potentialausgleich - Zweck, Aufbau, typische Fehler]]
- [[sommer-2023-it-systeme-musteranalyse|Musteranalyse Sommer 2023: IT-Systeme (ITSE)]]
- [[sommer-2023-powi-wiso-musteranalyse|Musteranalyse Sommer 2023: PoWi/WISO (ITSE)]]
- [[sommer-2023-strom-musteranalyse|Musteranalyse Sommer 2023: Strom (ITSE)]]
- [[sommer-2024-it-systeme-musteranalyse|Musteranalyse Sommer 2024: IT-Systeme (ITSE)]]
- [[sommer-2024-powi-wiso-musteranalyse|Musteranalyse Sommer 2024: PoWi/WISO (ITSE)]]
- ... (5 weitere)

## netzwerk (15)

- [[aufgabentyp-subnetting|Aufgabentyp: Subnetting & IP-Plan in der Pruefung]]
- [[aufgabentyp-voip-qos|Aufgabentyp: VoIP-Probleme analysieren (QoS, VLAN, Ports)]]
- [[dhcp-dns|DHCP und DNS - Basics, typische Fehlersuche]]
- [[firewall-dmz-nat|Firewall-Techniken, DMZ und NAT - pruefungsnaher Ueberblick]]
- [[ip-adressierung-v4-v6|IP-Adressierung - IPv4 vs. IPv6 (Grundlagen, typische Aufgaben)]]
- [[osi-tcpip-ethernet|Netzwerk-Grundlagen: OSI/TCP-IP, Ethernet, Frames, MAC und ARP]]
- [[poe-standards-8023af-at-bt|PoE - IEEE 802.3af/at/bt, Leistungsklassen, typische Planung]]
- [[routing-grundlagen|Routing - Default Gateway, Routing-Tabelle, NAT (Ueberblick)]]
- [[strukturierte-verkabelung|Strukturierte Verkabelung - Patchpanel, Dosen, Kategorien, Pruefungslogik]]
- [[subnetting-ipv4|Subnetting IPv4 - schnell und pruefungsfest]]
- [[switching-mac-table|Switching - MAC-Adress-Tabelle, Broadcast, STP (Grundidee)]]
- [[vlan-grundlagen-trunk-tagging|VLAN - Access/Trunk, Tagging (802.1Q), typische Fehler]]
- ... (3 weitere)

## ap2 (11)

- [[komponenten-im-verteilerschrank-benennen|Aufgabentyp: Betriebsmittel im Verteilerschrank benennen]]
- [[aufgabentyp-messprotokoll-vde0100-600|Aufgabentyp: Messprotokoll (VDE 0100-600) ausfuellen und bewerten]]
- [[aufgabentyp-subnetting|Aufgabentyp: Subnetting & IP-Plan in der Pruefung]]
- [[cloud-services-saas-paas-iaas|Cloud-Services - IaaS/PaaS/SaaS, Vor- und Nachteile]]
- [[leitungsdimensionierung-querschnitt-spannungsfall|Leitungsdimensionierung - Querschnitt, Verlegeart, Spannungsfall (AP2-Schema)]]
- [[pruefung-nach-vde-0100-600|Pruefung nach DIN VDE 0100-600 - Ablauf, Messungen, Dokumentation]]
- [[raid-grundlagen|RAID - Level 0/1/5/6/10, Nutzen und Grenzen]]
- [[schaltzeichen-und-stromlaufplaene|Schaltzeichen und Stromlaufplaene lesen - Basics fuer AP2]]
- [[subnetting-ipv4|Subnetting IPv4 - schnell und pruefungsfest]]
- [[virtualisierung-hypervisor-grundlagen|Virtualisierung & Hypervisor - Typ 1/Typ 2, Nutzen, typische Risiken]]
- [[wiso-arbeitsrecht-sozialversicherung|WISO: Arbeitsrecht & Sozialversicherung - pruefungsnaher Ueberblick]]

## it-systeme (11)

- [[aufgabentyp-raid-backup|Aufgabentyp: RAID vs. Backup sauber abgrenzen und begruenden]]
- [[backupverfahren-3-2-1-generationenprinzip|Backupverfahren - Voll/inkrementell/differentiell, 3-2-1 und Generationenprinzip]]
- [[cloud-services-saas-paas-iaas|Cloud-Services - IaaS/PaaS/SaaS, Vor- und Nachteile]]
- [[cia-triad-datenschutz-datensicherheit|Datensicherheit vs. Datenschutz und CIA-Triade (Vertraulichkeit, Integritaet, Verfuegbarkeit)]]
- [[sommer-2023-it-systeme-musteranalyse|Musteranalyse Sommer 2023: IT-Systeme (ITSE)]]
- [[sommer-2024-it-systeme-musteranalyse|Musteranalyse Sommer 2024: IT-Systeme (ITSE)]]
- [[winter-2023-2024-it-systeme-musteranalyse|Musteranalyse Winter 2023-2024: IT-Systeme (ITSE)]]
- [[raid-grundlagen|RAID - Level 0/1/5/6/10, Nutzen und Grenzen]]
- [[speichernetzwerktechnik-das-nas-san-iscsi-fc|Speichernetzwerktechnik - DAS, NAS, SAN, iSCSI, Fibre Channel]]
- [[verschluesselung-hash-signatur|Verschluesselung, Hash und digitale Signatur - symmetrisch/asymmetrisch/hybrid]]
- [[virtualisierung-hypervisor-grundlagen|Virtualisierung & Hypervisor - Typ 1/Typ 2, Nutzen, typische Risiken]]

## grundlagen (10)

- [[batterie|Batterie - Grundlagen, Kenngroessen und Einsatz in IT/ET]]
- [[emv-grundlagen|EMV - elektromagnetische Vertraeglichkeit (Grundidee, typische Massnahmen)]]
- [[erdung-potentialausgleich|Erdung und Potentialausgleich - Zweck, Aufbau, typische Fehler]]
- [[ip-adressierung-v4-v6|IP-Adressierung - IPv4 vs. IPv6 (Grundlagen, typische Aufgaben)]]
- [[leistung-energie-drehstrom-cosphi|Leistung, Energie, Drehstrom, cos(phi) und P-Q-S]]
- [[osi-tcpip-ethernet|Netzwerk-Grundlagen: OSI/TCP-IP, Ethernet, Frames, MAC und ARP]]
- [[spannung-strom-ohm|Spannung, Strom, Widerstand und Ohmsches Gesetz]]
- [[strukturierte-verkabelung|Strukturierte Verkabelung - Patchpanel, Dosen, Kategorien, Pruefungslogik]]
- [[wechselspannung-grundlagen|Wechselspannung und Wechselstrom-Grundlagen]]
- [[widerstand|Widerstand - Aufgabe, Bauformen, Kennzeichnung (Kurzueberblick)]]

## bauteile (9)

- [[batterie|Batterie - Grundlagen, Kenngroessen und Einsatz in IT/ET]]
- [[diode|Diode - Einbahnstrasse fuer Strom (Grundprinzip, LED, Schutzdiode)]]
- [[gleichrichter|Gleichrichter - AC zu DC (Brueckengleichrichter, Glaettung)]]
- [[kondensator|Kondensator - Speichern, Glaetten, Filtern (Grundidee)]]
- [[spule|Spule/Induktivitaet - Magnetfeld, Induktionsspannung, Anwendungen]]
- [[transformator|Transformator - Spannung anpassen, Trennung, Grundprinzip]]
- [[transistor|Transistor - Schalten/Verstaerken (Kurzueberblick fuer ITSE)]]
- [[wechselrichter|Wechselrichter - DC zu AC (Grundidee, Einsatz in USV/Photovoltaik)]]
- [[widerstand|Widerstand - Aufgabe, Bauformen, Kennzeichnung (Kurzueberblick)]]

## altklausur (9)

- [[sommer-2023-it-systeme-musteranalyse|Musteranalyse Sommer 2023: IT-Systeme (ITSE)]]
- [[sommer-2023-powi-wiso-musteranalyse|Musteranalyse Sommer 2023: PoWi/WISO (ITSE)]]
- [[sommer-2023-strom-musteranalyse|Musteranalyse Sommer 2023: Strom (ITSE)]]
- [[sommer-2024-it-systeme-musteranalyse|Musteranalyse Sommer 2024: IT-Systeme (ITSE)]]
- [[sommer-2024-powi-wiso-musteranalyse|Musteranalyse Sommer 2024: PoWi/WISO (ITSE)]]
- [[sommer-2024-strom-musteranalyse|Musteranalyse Sommer 2024: Strom (ITSE)]]
- [[winter-2023-2024-it-systeme-musteranalyse|Musteranalyse Winter 2023-2024: IT-Systeme (ITSE)]]
- [[winter-2023-2024-powi-wiso-musteranalyse|Musteranalyse Winter 2023-2024: PoWi/WISO (ITSE)]]
- [[winter-2023-2024-strom-musteranalyse|Musteranalyse Winter 2023-2024: Strom (ITSE)]]

## analyse (9)

- [[sommer-2023-it-systeme-musteranalyse|Musteranalyse Sommer 2023: IT-Systeme (ITSE)]]
- [[sommer-2023-powi-wiso-musteranalyse|Musteranalyse Sommer 2023: PoWi/WISO (ITSE)]]
- [[sommer-2023-strom-musteranalyse|Musteranalyse Sommer 2023: Strom (ITSE)]]
- [[sommer-2024-it-systeme-musteranalyse|Musteranalyse Sommer 2024: IT-Systeme (ITSE)]]
- [[sommer-2024-powi-wiso-musteranalyse|Musteranalyse Sommer 2024: PoWi/WISO (ITSE)]]
- [[sommer-2024-strom-musteranalyse|Musteranalyse Sommer 2024: Strom (ITSE)]]
- [[winter-2023-2024-it-systeme-musteranalyse|Musteranalyse Winter 2023-2024: IT-Systeme (ITSE)]]
- [[winter-2023-2024-powi-wiso-musteranalyse|Musteranalyse Winter 2023-2024: PoWi/WISO (ITSE)]]
- [[winter-2023-2024-strom-musteranalyse|Musteranalyse Winter 2023-2024: Strom (ITSE)]]

## itse (9)

- [[sommer-2023-it-systeme-musteranalyse|Musteranalyse Sommer 2023: IT-Systeme (ITSE)]]
- [[sommer-2023-powi-wiso-musteranalyse|Musteranalyse Sommer 2023: PoWi/WISO (ITSE)]]
- [[sommer-2023-strom-musteranalyse|Musteranalyse Sommer 2023: Strom (ITSE)]]
- [[sommer-2024-it-systeme-musteranalyse|Musteranalyse Sommer 2024: IT-Systeme (ITSE)]]
- [[sommer-2024-powi-wiso-musteranalyse|Musteranalyse Sommer 2024: PoWi/WISO (ITSE)]]
- [[sommer-2024-strom-musteranalyse|Musteranalyse Sommer 2024: Strom (ITSE)]]
- [[winter-2023-2024-it-systeme-musteranalyse|Musteranalyse Winter 2023-2024: IT-Systeme (ITSE)]]
- [[winter-2023-2024-powi-wiso-musteranalyse|Musteranalyse Winter 2023-2024: PoWi/WISO (ITSE)]]
- [[winter-2023-2024-strom-musteranalyse|Musteranalyse Winter 2023-2024: Strom (ITSE)]]

## sicherheit (8)

- [[cia-triad-datenschutz-datensicherheit|Datensicherheit vs. Datenschutz und CIA-Triade (Vertraulichkeit, Integritaet, Verfuegbarkeit)]]
- [[fuenf-sicherheitsregeln|Die 5 Sicherheitsregeln (DIN VDE) - sicher arbeiten]]
- [[firewall-dmz-nat|Firewall-Techniken, DMZ und NAT - pruefungsnaher Ueberblick]]
- [[messgeraete-spannungspruefer-multimeter|Messgeraete: zweipoliger Spannungspruefer, Multimeter, Stromzange - richtig einsetzen]]
- [[schutz-gegen-elektrischen-schlag|Schutz gegen elektrischen Schlag - Schutzmassnahmen und Grundbegriffe]]
- [[vpn-grundlagen-ipsec-ssl|VPN - Site-to-Site vs. Remote, IPsec vs. SSL (Grundidee)]]
- [[verschluesselung-hash-signatur|Verschluesselung, Hash und digitale Signatur - symmetrisch/asymmetrisch/hybrid]]
- [[wlan-80211-sicherheit|WLAN - 802.11 Grundlagen, Sicherheit (WPA2/WPA3), Planung]]

## strom (4)

- [[sommer-2023-strom-musteranalyse|Musteranalyse Sommer 2023: Strom (ITSE)]]
- [[sommer-2024-strom-musteranalyse|Musteranalyse Sommer 2024: Strom (ITSE)]]
- [[winter-2023-2024-strom-musteranalyse|Musteranalyse Winter 2023-2024: Strom (ITSE)]]
- [[spannung-strom-ohm|Spannung, Strom, Widerstand und Ohmsches Gesetz]]

## schutztechnik (4)

- [[ls-leitungsschutzschalter|Leitungsschutzschalter (LS) - Aufgabe, Kennlinien B/C/D, Auswahl]]
- [[rcd-fi-fehlerstromschutz|RCD/FI - Funktionsweise, IDeltan, Typen und Pruefung]]
- [[schmelzsicherungen-neozed-diazed|Schmelzsicherungen (DIAZED/NEOZED) - Aufgabe, Einsatz, Vor- und Nachteile]]
- [[selektivitaet-sls|Selektivitaet und selektiver Leitungsschutzschalter (SLS) - Prinzip]]

## erdung (3)

- [[erdung-potentialausgleich|Erdung und Potentialausgleich - Zweck, Aufbau, typische Fehler]]
- [[netzformen-tn-tt-it|Netzformen TN/TT/IT - N, PE, PEN und typische Messwerte]]
- [[schutz-gegen-elektrischen-schlag|Schutz gegen elektrischen Schlag - Schutzmassnahmen und Grundbegriffe]]

## schutz (3)

- [[diode|Diode - Einbahnstrasse fuer Strom (Grundprinzip, LED, Schutzdiode)]]
- [[erdung-potentialausgleich|Erdung und Potentialausgleich - Zweck, Aufbau, typische Fehler]]
- [[spule|Spule/Induktivitaet - Magnetfeld, Induktionsspannung, Anwendungen]]

## usv (3)

- [[batterie|Batterie - Grundlagen, Kenngroessen und Einsatz in IT/ET]]
- [[usv-grundlagen|USV (Unterbrechungsfreie Stromversorgung) - Zweck, Typen, Auswahl]]
- [[wechselrichter|Wechselrichter - DC zu AC (Grundidee, Einsatz in USV/Photovoltaik)]]

## powi-wiso (3)

- [[sommer-2023-powi-wiso-musteranalyse|Musteranalyse Sommer 2023: PoWi/WISO (ITSE)]]
- [[sommer-2024-powi-wiso-musteranalyse|Musteranalyse Sommer 2024: PoWi/WISO (ITSE)]]
- [[winter-2023-2024-powi-wiso-musteranalyse|Musteranalyse Winter 2023-2024: PoWi/WISO (ITSE)]]

## ohm (2)

- [[spannung-strom-ohm|Spannung, Strom, Widerstand und Ohmsches Gesetz]]
- [[widerstand|Widerstand - Aufgabe, Bauformen, Kennzeichnung (Kurzueberblick)]]

## widerstand (2)

- [[spannung-strom-ohm|Spannung, Strom, Widerstand und Ohmsches Gesetz]]
- [[widerstand|Widerstand - Aufgabe, Bauformen, Kennzeichnung (Kurzueberblick)]]

## formeln (2)

- [[leistung-energie-drehstrom-cosphi|Leistung, Energie, Drehstrom, cos(phi) und P-Q-S]]
- [[spannung-strom-ohm|Spannung, Strom, Widerstand und Ohmsches Gesetz]]

## energie (2)

- [[batterie|Batterie - Grundlagen, Kenngroessen und Einsatz in IT/ET]]
- [[leistung-energie-drehstrom-cosphi|Leistung, Energie, Drehstrom, cos(phi) und P-Q-S]]

## wechselspannung (2)

- [[transformator|Transformator - Spannung anpassen, Trennung, Grundprinzip]]
- [[wechselspannung-grundlagen|Wechselspannung und Wechselstrom-Grundlagen]]

## rcd (2)

- [[rcd-fi-fehlerstromschutz|RCD/FI - Funktionsweise, IDeltan, Typen und Pruefung]]
- [[schutz-gegen-elektrischen-schlag|Schutz gegen elektrischen Schlag - Schutzmassnahmen und Grundbegriffe]]

## ip (2)

- [[ip-adressierung-v4-v6|IP-Adressierung - IPv4 vs. IPv6 (Grundlagen, typische Aufgaben)]]
- [[schutz-gegen-elektrischen-schlag|Schutz gegen elektrischen Schlag - Schutzmassnahmen und Grundbegriffe]]

## filter (2)

- [[emv-grundlagen|EMV - elektromagnetische Vertraeglichkeit (Grundidee, typische Massnahmen)]]
- [[kondensator|Kondensator - Speichern, Glaetten, Filtern (Grundidee)]]

## energieversorgung (2)

- [[leitungsdimensionierung-querschnitt-spannungsfall|Leitungsdimensionierung - Querschnitt, Verlegeart, Spannungsfall (AP2-Schema)]]
- [[usv-grundlagen|USV (Unterbrechungsfreie Stromversorgung) - Zweck, Typen, Auswahl]]

## messen (2)

- [[messgeraete-spannungspruefer-multimeter|Messgeraete: zweipoliger Spannungspruefer, Multimeter, Stromzange - richtig einsetzen]]
- [[pruefung-nach-vde-0100-600|Pruefung nach DIN VDE 0100-600 - Ablauf, Messungen, Dokumentation]]

## vde0100-600 (2)

- [[aufgabentyp-messprotokoll-vde0100-600|Aufgabentyp: Messprotokoll (VDE 0100-600) ausfuellen und bewerten]]
- [[pruefung-nach-vde-0100-600|Pruefung nach DIN VDE 0100-600 - Ablauf, Messungen, Dokumentation]]

## messprotokoll (2)

- [[aufgabentyp-messprotokoll-vde0100-600|Aufgabentyp: Messprotokoll (VDE 0100-600) ausfuellen und bewerten]]
- [[pruefung-nach-vde-0100-600|Pruefung nach DIN VDE 0100-600 - Ablauf, Messungen, Dokumentation]]

## sicherung (2)

- [[ls-leitungsschutzschalter|Leitungsschutzschalter (LS) - Aufgabe, Kennlinien B/C/D, Auswahl]]
- [[schmelzsicherungen-neozed-diazed|Schmelzsicherungen (DIAZED/NEOZED) - Aufgabe, Einsatz, Vor- und Nachteile]]

## elektroinstallation (2)

- [[installationszonen|Installationszonen (Wand) - wo Leitungen verlegt werden duerfen (Grundidee)]]
- [[schaltzeichen-und-stromlaufplaene|Schaltzeichen und Stromlaufplaene lesen - Basics fuer AP2]]

## mac (2)

- [[osi-tcpip-ethernet|Netzwerk-Grundlagen: OSI/TCP-IP, Ethernet, Frames, MAC und ARP]]
- [[switching-mac-table|Switching - MAC-Adress-Tabelle, Broadcast, STP (Grundidee)]]

## ipv4 (2)

- [[ip-adressierung-v4-v6|IP-Adressierung - IPv4 vs. IPv6 (Grundlagen, typische Aufgaben)]]
- [[subnetting-ipv4|Subnetting IPv4 - schnell und pruefungsfest]]

## subnetting (2)

- [[aufgabentyp-subnetting|Aufgabentyp: Subnetting & IP-Plan in der Pruefung]]
- [[subnetting-ipv4|Subnetting IPv4 - schnell und pruefungsfest]]

## switching (2)

- [[switching-mac-table|Switching - MAC-Adress-Tabelle, Broadcast, STP (Grundidee)]]
- [[vlan-grundlagen-trunk-tagging|VLAN - Access/Trunk, Tagging (802.1Q), typische Fehler]]

## nat (2)

- [[firewall-dmz-nat|Firewall-Techniken, DMZ und NAT - pruefungsnaher Ueberblick]]
- [[routing-grundlagen|Routing - Default Gateway, Routing-Tabelle, NAT (Ueberblick)]]

## vlan (2)

- [[aufgabentyp-voip-qos|Aufgabentyp: VoIP-Probleme analysieren (QoS, VLAN, Ports)]]
- [[vlan-grundlagen-trunk-tagging|VLAN - Access/Trunk, Tagging (802.1Q), typische Fehler]]

## planung (2)

- [[poe-standards-8023af-at-bt|PoE - IEEE 802.3af/at/bt, Leistungsklassen, typische Planung]]
- [[wlan-80211-sicherheit|WLAN - 802.11 Grundlagen, Sicherheit (WPA2/WPA3), Planung]]

## voip (2)

- [[aufgabentyp-voip-qos|Aufgabentyp: VoIP-Probleme analysieren (QoS, VLAN, Ports)]]
- [[voip-grundlagen-sip-rtp-qos|VoIP - SIP, RTP, Codecs, QoS, Latenz/Jitter (AP2)]]

## qos (2)

- [[aufgabentyp-voip-qos|Aufgabentyp: VoIP-Probleme analysieren (QoS, VLAN, Ports)]]
- [[voip-grundlagen-sip-rtp-qos|VoIP - SIP, RTP, Codecs, QoS, Latenz/Jitter (AP2)]]

## backup (2)

- [[aufgabentyp-raid-backup|Aufgabentyp: RAID vs. Backup sauber abgrenzen und begruenden]]
- [[backupverfahren-3-2-1-generationenprinzip|Backupverfahren - Voll/inkrementell/differentiell, 3-2-1 und Generationenprinzip]]

## raid (2)

- [[aufgabentyp-raid-backup|Aufgabentyp: RAID vs. Backup sauber abgrenzen und begruenden]]
- [[raid-grundlagen|RAID - Level 0/1/5/6/10, Nutzen und Grenzen]]

## wiso (2)

- [[wiso-arbeitsrecht-sozialversicherung|WISO: Arbeitsrecht & Sozialversicherung - pruefungsnaher Ueberblick]]
- [[wiso-betrieb-markt-grundbegriffe|WISO: Betrieb & Markt - Grundbegriffe (Kosten, Umsatz, Gewinn, Unternehmensformen)]]

## spannung (1)

- [[spannung-strom-ohm|Spannung, Strom, Widerstand und Ohmsches Gesetz]]

## leistung (1)

- [[leistung-energie-drehstrom-cosphi|Leistung, Energie, Drehstrom, cos(phi) und P-Q-S]]

## drehstrom (1)

- [[leistung-energie-drehstrom-cosphi|Leistung, Energie, Drehstrom, cos(phi) und P-Q-S]]

## cosphi (1)

- [[leistung-energie-drehstrom-cosphi|Leistung, Energie, Drehstrom, cos(phi) und P-Q-S]]

## wechselstrom (1)

- [[wechselspannung-grundlagen|Wechselspannung und Wechselstrom-Grundlagen]]

## effektivwert (1)

- [[wechselspannung-grundlagen|Wechselspannung und Wechselstrom-Grundlagen]]

## frequenz (1)

- [[wechselspannung-grundlagen|Wechselspannung und Wechselstrom-Grundlagen]]

## impedanz (1)

- [[wechselspannung-grundlagen|Wechselspannung und Wechselstrom-Grundlagen]]

## potentialausgleich (1)

- [[erdung-potentialausgleich|Erdung und Potentialausgleich - Zweck, Aufbau, typische Fehler]]

## pe (1)

- [[erdung-potentialausgleich|Erdung und Potentialausgleich - Zweck, Aufbau, typische Fehler]]

## vde (1)

- [[fuenf-sicherheitsregeln|Die 5 Sicherheitsregeln (DIN VDE) - sicher arbeiten]]

## arbeitsablauf (1)

- [[fuenf-sicherheitsregeln|Die 5 Sicherheitsregeln (DIN VDE) - sicher arbeiten]]

## schutzmassnahmen (1)

- [[schutz-gegen-elektrischen-schlag|Schutz gegen elektrischen Schlag - Schutzmassnahmen und Grundbegriffe]]

## schutzklasse (1)

- [[schutz-gegen-elektrischen-schlag|Schutz gegen elektrischen Schlag - Schutzmassnahmen und Grundbegriffe]]

## batterie (1)

- [[batterie|Batterie - Grundlagen, Kenngroessen und Einsatz in IT/ET]]

## diode (1)

- [[diode|Diode - Einbahnstrasse fuer Strom (Grundprinzip, LED, Schutzdiode)]]

## gleichrichtung (1)

- [[diode|Diode - Einbahnstrasse fuer Strom (Grundprinzip, LED, Schutzdiode)]]

## gleichrichter (1)

- [[gleichrichter|Gleichrichter - AC zu DC (Brueckengleichrichter, Glaettung)]]

## netzteil (1)

- [[gleichrichter|Gleichrichter - AC zu DC (Brueckengleichrichter, Glaettung)]]

## gleichspannung (1)

- [[gleichrichter|Gleichrichter - AC zu DC (Brueckengleichrichter, Glaettung)]]

## kondensator (1)

- [[kondensator|Kondensator - Speichern, Glaetten, Filtern (Grundidee)]]

## kapazitaet (1)

- [[kondensator|Kondensator - Speichern, Glaetten, Filtern (Grundidee)]]

## spule (1)

- [[spule|Spule/Induktivitaet - Magnetfeld, Induktionsspannung, Anwendungen]]

## induktivitaet (1)

- [[spule|Spule/Induktivitaet - Magnetfeld, Induktionsspannung, Anwendungen]]

## magnetfeld (1)

- [[spule|Spule/Induktivitaet - Magnetfeld, Induktionsspannung, Anwendungen]]

## transformator (1)

- [[transformator|Transformator - Spannung anpassen, Trennung, Grundprinzip]]

## trafo (1)

- [[transformator|Transformator - Spannung anpassen, Trennung, Grundprinzip]]

## schutztrennung (1)

- [[transformator|Transformator - Spannung anpassen, Trennung, Grundprinzip]]

## transistor (1)

- [[transistor|Transistor - Schalten/Verstaerken (Kurzueberblick fuer ITSE)]]

## schalten (1)

- [[transistor|Transistor - Schalten/Verstaerken (Kurzueberblick fuer ITSE)]]

## elektronik (1)

- [[transistor|Transistor - Schalten/Verstaerken (Kurzueberblick fuer ITSE)]]

## wechselrichter (1)

- [[wechselrichter|Wechselrichter - DC zu AC (Grundidee, Einsatz in USV/Photovoltaik)]]

## dcdc (1)

- [[wechselrichter|Wechselrichter - DC zu AC (Grundidee, Einsatz in USV/Photovoltaik)]]

## acdc (1)

- [[wechselrichter|Wechselrichter - DC zu AC (Grundidee, Einsatz in USV/Photovoltaik)]]

## querschnitt (1)

- [[leitungsdimensionierung-querschnitt-spannungsfall|Leitungsdimensionierung - Querschnitt, Verlegeart, Spannungsfall (AP2-Schema)]]

## spannungsfall (1)

- [[leitungsdimensionierung-querschnitt-spannungsfall|Leitungsdimensionierung - Querschnitt, Verlegeart, Spannungsfall (AP2-Schema)]]

## verlegeart (1)

- [[leitungsdimensionierung-querschnitt-spannungsfall|Leitungsdimensionierung - Querschnitt, Verlegeart, Spannungsfall (AP2-Schema)]]

## dimensionierung (1)

- [[leitungsdimensionierung-querschnitt-spannungsfall|Leitungsdimensionierung - Querschnitt, Verlegeart, Spannungsfall (AP2-Schema)]]

## stromversorgung (1)

- [[usv-grundlagen|USV (Unterbrechungsfreie Stromversorgung) - Zweck, Typen, Auswahl]]

## it-infrastruktur (1)

- [[usv-grundlagen|USV (Unterbrechungsfreie Stromversorgung) - Zweck, Typen, Auswahl]]

## pruefen (1)

- [[pruefung-nach-vde-0100-600|Pruefung nach DIN VDE 0100-600 - Ablauf, Messungen, Dokumentation]]

## messgeraete (1)

- [[messgeraete-spannungspruefer-multimeter|Messgeraete: zweipoliger Spannungspruefer, Multimeter, Stromzange - richtig einsetzen]]

## spannungspruefer (1)

- [[messgeraete-spannungspruefer-multimeter|Messgeraete: zweipoliger Spannungspruefer, Multimeter, Stromzange - richtig einsetzen]]

## multimeter (1)

- [[messgeraete-spannungspruefer-multimeter|Messgeraete: zweipoliger Spannungspruefer, Multimeter, Stromzange - richtig einsetzen]]

## stromzange (1)

- [[messgeraete-spannungspruefer-multimeter|Messgeraete: zweipoliger Spannungspruefer, Multimeter, Stromzange - richtig einsetzen]]

## ls (1)

- [[ls-leitungsschutzschalter|Leitungsschutzschalter (LS) - Aufgabe, Kennlinien B/C/D, Auswahl]]

## kurzschluss (1)

- [[ls-leitungsschutzschalter|Leitungsschutzschalter (LS) - Aufgabe, Kennlinien B/C/D, Auswahl]]

## ueberlast (1)

- [[ls-leitungsschutzschalter|Leitungsschutzschalter (LS) - Aufgabe, Kennlinien B/C/D, Auswahl]]

## fi (1)

- [[rcd-fi-fehlerstromschutz|RCD/FI - Funktionsweise, IDeltan, Typen und Pruefung]]

## fehlerstrom (1)

- [[rcd-fi-fehlerstromschutz|RCD/FI - Funktionsweise, IDeltan, Typen und Pruefung]]

## personenschutz (1)

- [[rcd-fi-fehlerstromschutz|RCD/FI - Funktionsweise, IDeltan, Typen und Pruefung]]

## schmelzsicherung (1)

- [[schmelzsicherungen-neozed-diazed|Schmelzsicherungen (DIAZED/NEOZED) - Aufgabe, Einsatz, Vor- und Nachteile]]

## neozed (1)

- [[schmelzsicherungen-neozed-diazed|Schmelzsicherungen (DIAZED/NEOZED) - Aufgabe, Einsatz, Vor- und Nachteile]]

## diazed (1)

- [[schmelzsicherungen-neozed-diazed|Schmelzsicherungen (DIAZED/NEOZED) - Aufgabe, Einsatz, Vor- und Nachteile]]

## selektivitaet (1)

- [[selektivitaet-sls|Selektivitaet und selektiver Leitungsschutzschalter (SLS) - Prinzip]]

## sls (1)

- [[selektivitaet-sls|Selektivitaet und selektiver Leitungsschutzschalter (SLS) - Prinzip]]

## verteilung (1)

- [[selektivitaet-sls|Selektivitaet und selektiver Leitungsschutzschalter (SLS) - Prinzip]]

## emv (1)

- [[emv-grundlagen|EMV - elektromagnetische Vertraeglichkeit (Grundidee, typische Massnahmen)]]

## abschirmung (1)

- [[emv-grundlagen|EMV - elektromagnetische Vertraeglichkeit (Grundidee, typische Massnahmen)]]

## installationszonen (1)

- [[installationszonen|Installationszonen (Wand) - wo Leitungen verlegt werden duerfen (Grundidee)]]

## verlegung (1)

- [[installationszonen|Installationszonen (Wand) - wo Leitungen verlegt werden duerfen (Grundidee)]]

## Pruefungsnahe Anwendung (1)

- [[installationszonen|Installationszonen (Wand) - wo Leitungen verlegt werden duerfen (Grundidee)]]

## schaltzeichen (1)

- [[schaltzeichen-und-stromlaufplaene|Schaltzeichen und Stromlaufplaene lesen - Basics fuer AP2]]

## stromlaufplan (1)

- [[schaltzeichen-und-stromlaufplaene|Schaltzeichen und Stromlaufplaene lesen - Basics fuer AP2]]

## planlesen (1)

- [[schaltzeichen-und-stromlaufplaene|Schaltzeichen und Stromlaufplaene lesen - Basics fuer AP2]]

## netzformen (1)

- [[netzformen-tn-tt-it|Netzformen TN/TT/IT - N, PE, PEN und typische Messwerte]]

## tn (1)

- [[netzformen-tn-tt-it|Netzformen TN/TT/IT - N, PE, PEN und typische Messwerte]]

## tt (1)

- [[netzformen-tn-tt-it|Netzformen TN/TT/IT - N, PE, PEN und typische Messwerte]]

## it (1)

- [[netzformen-tn-tt-it|Netzformen TN/TT/IT - N, PE, PEN und typische Messwerte]]

## pen (1)

- [[netzformen-tn-tt-it|Netzformen TN/TT/IT - N, PE, PEN und typische Messwerte]]

## osi (1)

- [[osi-tcpip-ethernet|Netzwerk-Grundlagen: OSI/TCP-IP, Ethernet, Frames, MAC und ARP]]

## tcpip (1)

- [[osi-tcpip-ethernet|Netzwerk-Grundlagen: OSI/TCP-IP, Ethernet, Frames, MAC und ARP]]

## ethernet (1)

- [[osi-tcpip-ethernet|Netzwerk-Grundlagen: OSI/TCP-IP, Ethernet, Frames, MAC und ARP]]

## arp (1)

- [[osi-tcpip-ethernet|Netzwerk-Grundlagen: OSI/TCP-IP, Ethernet, Frames, MAC und ARP]]

## ipv6 (1)

- [[ip-adressierung-v4-v6|IP-Adressierung - IPv4 vs. IPv6 (Grundlagen, typische Aufgaben)]]

## rechnen (1)

- [[subnetting-ipv4|Subnetting IPv4 - schnell und pruefungsfest]]

## verkabelung (1)

- [[strukturierte-verkabelung|Strukturierte Verkabelung - Patchpanel, Dosen, Kategorien, Pruefungslogik]]

## patchpanel (1)

- [[strukturierte-verkabelung|Strukturierte Verkabelung - Patchpanel, Dosen, Kategorien, Pruefungslogik]]

## cat (1)

- [[strukturierte-verkabelung|Strukturierte Verkabelung - Patchpanel, Dosen, Kategorien, Pruefungslogik]]

## fiber (1)

- [[strukturierte-verkabelung|Strukturierte Verkabelung - Patchpanel, Dosen, Kategorien, Pruefungslogik]]

## broadcast (1)

- [[switching-mac-table|Switching - MAC-Adress-Tabelle, Broadcast, STP (Grundidee)]]

## stp (1)

- [[switching-mac-table|Switching - MAC-Adress-Tabelle, Broadcast, STP (Grundidee)]]

## routing (1)

- [[routing-grundlagen|Routing - Default Gateway, Routing-Tabelle, NAT (Ueberblick)]]

## gateway (1)

- [[routing-grundlagen|Routing - Default Gateway, Routing-Tabelle, NAT (Ueberblick)]]

## routingtabelle (1)

- [[routing-grundlagen|Routing - Default Gateway, Routing-Tabelle, NAT (Ueberblick)]]

## 8021q (1)

- [[vlan-grundlagen-trunk-tagging|VLAN - Access/Trunk, Tagging (802.1Q), typische Fehler]]

## trunk (1)

- [[vlan-grundlagen-trunk-tagging|VLAN - Access/Trunk, Tagging (802.1Q), typische Fehler]]

## access (1)

- [[vlan-grundlagen-trunk-tagging|VLAN - Access/Trunk, Tagging (802.1Q), typische Fehler]]

## vpn (1)

- [[vpn-grundlagen-ipsec-ssl|VPN - Site-to-Site vs. Remote, IPsec vs. SSL (Grundidee)]]

## ipsec (1)

- [[vpn-grundlagen-ipsec-ssl|VPN - Site-to-Site vs. Remote, IPsec vs. SSL (Grundidee)]]

## ssl (1)

- [[vpn-grundlagen-ipsec-ssl|VPN - Site-to-Site vs. Remote, IPsec vs. SSL (Grundidee)]]

## tunnel (1)

- [[vpn-grundlagen-ipsec-ssl|VPN - Site-to-Site vs. Remote, IPsec vs. SSL (Grundidee)]]

## poe (1)

- [[poe-standards-8023af-at-bt|PoE - IEEE 802.3af/at/bt, Leistungsklassen, typische Planung]]

## 8023af (1)

- [[poe-standards-8023af-at-bt|PoE - IEEE 802.3af/at/bt, Leistungsklassen, typische Planung]]

## 8023at (1)

- [[poe-standards-8023af-at-bt|PoE - IEEE 802.3af/at/bt, Leistungsklassen, typische Planung]]

## 8023bt (1)

- [[poe-standards-8023af-at-bt|PoE - IEEE 802.3af/at/bt, Leistungsklassen, typische Planung]]

## power (1)

- [[poe-standards-8023af-at-bt|PoE - IEEE 802.3af/at/bt, Leistungsklassen, typische Planung]]

## sip (1)

- [[voip-grundlagen-sip-rtp-qos|VoIP - SIP, RTP, Codecs, QoS, Latenz/Jitter (AP2)]]

## rtp (1)

- [[voip-grundlagen-sip-rtp-qos|VoIP - SIP, RTP, Codecs, QoS, Latenz/Jitter (AP2)]]

## codecs (1)

- [[voip-grundlagen-sip-rtp-qos|VoIP - SIP, RTP, Codecs, QoS, Latenz/Jitter (AP2)]]

## latenz (1)

- [[voip-grundlagen-sip-rtp-qos|VoIP - SIP, RTP, Codecs, QoS, Latenz/Jitter (AP2)]]

## jitter (1)

- [[voip-grundlagen-sip-rtp-qos|VoIP - SIP, RTP, Codecs, QoS, Latenz/Jitter (AP2)]]

## mos (1)

- [[voip-grundlagen-sip-rtp-qos|VoIP - SIP, RTP, Codecs, QoS, Latenz/Jitter (AP2)]]

## wlan (1)

- [[wlan-80211-sicherheit|WLAN - 802.11 Grundlagen, Sicherheit (WPA2/WPA3), Planung]]

## 80211 (1)

- [[wlan-80211-sicherheit|WLAN - 802.11 Grundlagen, Sicherheit (WPA2/WPA3), Planung]]

## wpa2 (1)

- [[wlan-80211-sicherheit|WLAN - 802.11 Grundlagen, Sicherheit (WPA2/WPA3), Planung]]

## wpa3 (1)

- [[wlan-80211-sicherheit|WLAN - 802.11 Grundlagen, Sicherheit (WPA2/WPA3), Planung]]

## firewall (1)

- [[firewall-dmz-nat|Firewall-Techniken, DMZ und NAT - pruefungsnaher Ueberblick]]

## dmz (1)

- [[firewall-dmz-nat|Firewall-Techniken, DMZ und NAT - pruefungsnaher Ueberblick]]

## spi (1)

- [[firewall-dmz-nat|Firewall-Techniken, DMZ und NAT - pruefungsnaher Ueberblick]]

## dpi (1)

- [[firewall-dmz-nat|Firewall-Techniken, DMZ und NAT - pruefungsnaher Ueberblick]]

## dienste (1)

- [[dhcp-dns|DHCP und DNS - Basics, typische Fehlersuche]]

## dhcp (1)

- [[dhcp-dns|DHCP und DNS - Basics, typische Fehlersuche]]

## dns (1)

- [[dhcp-dns|DHCP und DNS - Basics, typische Fehlersuche]]

## fehlersuche (1)

- [[dhcp-dns|DHCP und DNS - Basics, typische Fehlersuche]]

## datenschutz (1)

- [[cia-triad-datenschutz-datensicherheit|Datensicherheit vs. Datenschutz und CIA-Triade (Vertraulichkeit, Integritaet, Verfuegbarkeit)]]

## datensicherheit (1)

- [[cia-triad-datenschutz-datensicherheit|Datensicherheit vs. Datenschutz und CIA-Triade (Vertraulichkeit, Integritaet, Verfuegbarkeit)]]

## cia (1)

- [[cia-triad-datenschutz-datensicherheit|Datensicherheit vs. Datenschutz und CIA-Triade (Vertraulichkeit, Integritaet, Verfuegbarkeit)]]

## integritaet (1)

- [[cia-triad-datenschutz-datensicherheit|Datensicherheit vs. Datenschutz und CIA-Triade (Vertraulichkeit, Integritaet, Verfuegbarkeit)]]

## verfuegbarkeit (1)

- [[cia-triad-datenschutz-datensicherheit|Datensicherheit vs. Datenschutz und CIA-Triade (Vertraulichkeit, Integritaet, Verfuegbarkeit)]]

## datensicherung (1)

- [[backupverfahren-3-2-1-generationenprinzip|Backupverfahren - Voll/inkrementell/differentiell, 3-2-1 und Generationenprinzip]]

## 3-2-1 (1)

- [[backupverfahren-3-2-1-generationenprinzip|Backupverfahren - Voll/inkrementell/differentiell, 3-2-1 und Generationenprinzip]]

## inkrementell (1)

- [[backupverfahren-3-2-1-generationenprinzip|Backupverfahren - Voll/inkrementell/differentiell, 3-2-1 und Generationenprinzip]]

## differentiell (1)

- [[backupverfahren-3-2-1-generationenprinzip|Backupverfahren - Voll/inkrementell/differentiell, 3-2-1 und Generationenprinzip]]

## generationenprinzip (1)

- [[backupverfahren-3-2-1-generationenprinzip|Backupverfahren - Voll/inkrementell/differentiell, 3-2-1 und Generationenprinzip]]

## speicher (1)

- [[raid-grundlagen|RAID - Level 0/1/5/6/10, Nutzen und Grenzen]]

## redundanz (1)

- [[raid-grundlagen|RAID - Level 0/1/5/6/10, Nutzen und Grenzen]]

## cloud (1)

- [[cloud-services-saas-paas-iaas|Cloud-Services - IaaS/PaaS/SaaS, Vor- und Nachteile]]

## iaas (1)

- [[cloud-services-saas-paas-iaas|Cloud-Services - IaaS/PaaS/SaaS, Vor- und Nachteile]]

## paas (1)

- [[cloud-services-saas-paas-iaas|Cloud-Services - IaaS/PaaS/SaaS, Vor- und Nachteile]]

## saas (1)

- [[cloud-services-saas-paas-iaas|Cloud-Services - IaaS/PaaS/SaaS, Vor- und Nachteile]]

## storage (1)

- [[speichernetzwerktechnik-das-nas-san-iscsi-fc|Speichernetzwerktechnik - DAS, NAS, SAN, iSCSI, Fibre Channel]]

## das (1)

- [[speichernetzwerktechnik-das-nas-san-iscsi-fc|Speichernetzwerktechnik - DAS, NAS, SAN, iSCSI, Fibre Channel]]

## nas (1)

- [[speichernetzwerktechnik-das-nas-san-iscsi-fc|Speichernetzwerktechnik - DAS, NAS, SAN, iSCSI, Fibre Channel]]

## san (1)

- [[speichernetzwerktechnik-das-nas-san-iscsi-fc|Speichernetzwerktechnik - DAS, NAS, SAN, iSCSI, Fibre Channel]]

## iscsi (1)

- [[speichernetzwerktechnik-das-nas-san-iscsi-fc|Speichernetzwerktechnik - DAS, NAS, SAN, iSCSI, Fibre Channel]]

## fibre-channel (1)

- [[speichernetzwerktechnik-das-nas-san-iscsi-fc|Speichernetzwerktechnik - DAS, NAS, SAN, iSCSI, Fibre Channel]]

## verschluesselung (1)

- [[verschluesselung-hash-signatur|Verschluesselung, Hash und digitale Signatur - symmetrisch/asymmetrisch/hybrid]]

## hash (1)

- [[verschluesselung-hash-signatur|Verschluesselung, Hash und digitale Signatur - symmetrisch/asymmetrisch/hybrid]]

## signatur (1)

- [[verschluesselung-hash-signatur|Verschluesselung, Hash und digitale Signatur - symmetrisch/asymmetrisch/hybrid]]

## rsa (1)

- [[verschluesselung-hash-signatur|Verschluesselung, Hash und digitale Signatur - symmetrisch/asymmetrisch/hybrid]]

## aes (1)

- [[verschluesselung-hash-signatur|Verschluesselung, Hash und digitale Signatur - symmetrisch/asymmetrisch/hybrid]]

## virtualisierung (1)

- [[virtualisierung-hypervisor-grundlagen|Virtualisierung & Hypervisor - Typ 1/Typ 2, Nutzen, typische Risiken]]

## hypervisor (1)

- [[virtualisierung-hypervisor-grundlagen|Virtualisierung & Hypervisor - Typ 1/Typ 2, Nutzen, typische Risiken]]

## server (1)

- [[virtualisierung-hypervisor-grundlagen|Virtualisierung & Hypervisor - Typ 1/Typ 2, Nutzen, typische Risiken]]

## arbeitsrecht (1)

- [[wiso-arbeitsrecht-sozialversicherung|WISO: Arbeitsrecht & Sozialversicherung - pruefungsnaher Ueberblick]]

## sozialversicherung (1)

- [[wiso-arbeitsrecht-sozialversicherung|WISO: Arbeitsrecht & Sozialversicherung - pruefungsnaher Ueberblick]]

## ausbildung (1)

- [[wiso-arbeitsrecht-sozialversicherung|WISO: Arbeitsrecht & Sozialversicherung - pruefungsnaher Ueberblick]]

## bwl (1)

- [[wiso-betrieb-markt-grundbegriffe|WISO: Betrieb & Markt - Grundbegriffe (Kosten, Umsatz, Gewinn, Unternehmensformen)]]

## kosten (1)

- [[wiso-betrieb-markt-grundbegriffe|WISO: Betrieb & Markt - Grundbegriffe (Kosten, Umsatz, Gewinn, Unternehmensformen)]]

## umsatz (1)

- [[wiso-betrieb-markt-grundbegriffe|WISO: Betrieb & Markt - Grundbegriffe (Kosten, Umsatz, Gewinn, Unternehmensformen)]]

## gewinn (1)

- [[wiso-betrieb-markt-grundbegriffe|WISO: Betrieb & Markt - Grundbegriffe (Kosten, Umsatz, Gewinn, Unternehmensformen)]]

## unternehmensformen (1)

- [[wiso-betrieb-markt-grundbegriffe|WISO: Betrieb & Markt - Grundbegriffe (Kosten, Umsatz, Gewinn, Unternehmensformen)]]

## verteilerschrank (1)

- [[komponenten-im-verteilerschrank-benennen|Aufgabentyp: Betriebsmittel im Verteilerschrank benennen]]

## betriebsmittel (1)

- [[komponenten-im-verteilerschrank-benennen|Aufgabentyp: Betriebsmittel im Verteilerschrank benennen]]

## ip-plan (1)

- [[aufgabentyp-subnetting|Aufgabentyp: Subnetting & IP-Plan in der Pruefung]]

## ports (1)

- [[aufgabentyp-voip-qos|Aufgabentyp: VoIP-Probleme analysieren (QoS, VLAN, Ports)]]

## begruendung (1)

- [[aufgabentyp-raid-backup|Aufgabentyp: RAID vs. Backup sauber abgrenzen und begruenden]]


## Kontext & Grundlagen (Voraussetzungen)
- (Ergaenzen: kurz und pruefungsnah)


## Typische Fehler & Stolperfallen
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
