---
title: VLAN - Access/Trunk, Tagging (802.1Q), typische Fehler
tags:
- netzwerk
- vlan
- switching
- 8021q
- trunk
- access
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Wiederholung/Stichpunkte.txt
- internal:IT/Ernstmeier/Wiederholung/(A)StrVerkab_VLAN_RAID_VoIP_neu_Logo.doc.pdf
- internal:Unterricht
- internal:Altklausur-implizit
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
VLANs sind in AP2 sehr beliebt, weil sie Switching, Adressierung und Fehleranalyse verbinden. Voraussetzungen:
- [[osi-tcpip-ethernet|Layer 2 Grundlagen]]
- [[subnetting-ipv4|Subnetting]]
- MAC/Broadcast-Domain-Konzept

## Definition und Zweck
Ein **VLAN** trennt ein physisches Switch-Netz logisch in mehrere **Broadcast-Domains**. Vorteile:
- Segmentierung (Sicherheit, Uebersicht)
- getrennte Netze (z.B. Voice, Client, Server)
- weniger Broadcastverkehr pro Segment

## Access vs. Trunk (pruefungsnah)
- **Access-Port**: gehoert zu genau einem VLAN; Frames sind untagged.
- **Trunk-Port**: transportiert mehrere VLANs; Frames werden i.d.R. mit **802.1Q** getaggt.
Optional: Native VLAN (untagged) - nur wenn Aufgabe darauf eingeht.

## Routing zwischen VLANs
VLANs sind L2-Segmente. Kommunikation zwischen VLANs braucht **Routing** (Router/L3-Switch).  
Siehe [[routing-grundlagen|Routing]].

## Typische Pruefungsfallen
- Access/Trunk verwechselt -> Geraete sehen" kein Netz.
- VLAN-ID stimmt nicht an beiden Seiten.
- IP-Plan passt nicht zum VLAN (falsches Subnetz).
- Voice-VLAN/QoS bei VoIP ignorieren (siehe [[voip-grundlagen-sip-rtp-qos|VoIP]]).

## Checkliste (Kurz)
- VLAN-IDs konsistent?
- Portmodus korrekt?
- Trunk erlaubt VLAN?
- IP/Subnetz zum VLAN?

## Siehe auch
- [[switching-mac-table|Switching]]
- [[routing-grundlagen|Routing]]
- [[voip-grundlagen-sip-rtp-qos|VoIP]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Typische Fehler & Stolperfallen
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
