---
title: DHCP und DNS - Basics, typische Fehlersuche
tags:
- netzwerk
- dienste
- dhcp
- dns
- fehlersuche
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Wiederholung/Stichpunkte.txt
- internal:Unterricht
- internal:Altklausur-implizit
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
In Pruefungen ist DHCP/DNS oft der Hidden Boss": IP ist da, aber Name geht nicht; oder Clients bekommen keine Adresse. Voraussetzungen:
- [[subnetting-ipv4|Subnetting]]
- Default Gateway (siehe [[routing-grundlagen|Routing]])

## DHCP (Dynamic Host Configuration Protocol)
DHCP vergibt automatisch:
- IP-Adresse
- Subnetzmaske/Prefix
- Default Gateway
- DNS-Server
Ablauf (vereinfacht): Discover -> Offer -> Request -> Acknowledge.

Typische Fehler:
- DHCP-Server nicht erreichbar (VLAN/Relay fehlt)
- Pool erschoepft
- falsche Option (Gateway/DNS)

## DNS (Domain Name System)
DNS uebersetzt Namen <-> IP:
- A/AAAA Records (IPv4/IPv6)
- CNAME (Alias)
Pruefungslogik: Wenn IP-Ping geht, aber Name nicht -> DNS.

## Checkliste (Kurz)
- Client hat IP? (ipconfig/ifconfig)
- Gateway korrekt?
- DNS-Server gesetzt?
- Namensaufloesung testen (nslookup/dig)

## Siehe auch
- [[routing-grundlagen|Routing]]
- [[vlan-grundlagen-trunk-tagging|VLAN]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Typische Fehler & Stolperfallen
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
