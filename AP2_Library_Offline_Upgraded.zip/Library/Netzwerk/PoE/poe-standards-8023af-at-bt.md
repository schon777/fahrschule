---
title: PoE - IEEE 802.3af/at/bt, Leistungsklassen, typische Planung
tags:
- netzwerk
- poe
- 8023af
- 8023at
- 8023bt
- power
- planung
priority: P1+P2
exam_relevance: mittel
sources:
- internal:KI Ergebnisse/AP2_2026_ITSE_ET_Themencheckliste.md
- internal:IT/Ernstmeier/Wiederholung/Stichpunkte.txt
- internal:Unterricht
- internal:Altklausur-implizit
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
PoE kommt in AP2 oft im Zusammenhang mit VoIP-Telefonen, Access Points oder Kameras. Voraussetzungen:
- Grundidee Ethernet (siehe [[osi-tcpip-ethernet|Ethernet]])
- Leistung/Spannung (siehe [[leistung-energie-drehstrom-cosphi|Leistung]])

## Definition und Zweck
**Power over Ethernet (PoE)** ermoeglicht die Stromversorgung von Endgeraeten ueber das Netzwerkkabel. Vorteile:
- weniger Netzteile/Steckdosen
- zentrale Versorgung (USV kann PoE-Switch schuetzen)
- flexible Montage (APs, Kameras)

## Standards (Grundidee)
- **802.3af (PoE)**: Basisklasse
- **802.3at (PoE+)**: mehr Leistung
- **802.3bt (PoE++/4PPoE)**: deutlich mehr Leistung (z.B. leistungsfaehige APs)

In Pruefungen reicht meist: af < at < bt" und dass der Switch ein **PoE-Budget** hat.

## Planung (AP2-typisch)
- Geraeteanzahl x Leistungsbedarf -> PoE-Budget pruefen
- Kabelqualitaet/Verkabelung (siehe [[strukturierte-verkabelung|Strukturierte Verkabelung]])
- USV/Redundanz beruecksichtigen

## Typische Fehler & Stolperfallen
- PoE-Budget ignorieren (Switch kann das schon").
- Falscher Injektor/Standard.
- Zu lange/unguenstige Verkabelung ohne Konzept.

## Siehe auch
- [[voip-grundlagen-sip-rtp-qos|VoIP]]
- [[usv-grundlagen|USV]]
- [[strukturierte-verkabelung|Strukturierte Verkabelung]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
