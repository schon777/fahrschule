---
title: VPN - Site-to-Site vs. Remote, IPsec vs. SSL (Grundidee)
tags:
- netzwerk
- vpn
- ipsec
- ssl
- sicherheit
- tunnel
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Wiederholung/Stichpunkte.txt
- internal:Unterricht
- internal:Altklausur-implizit
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
VPN ist in AP2 oft Teil von Standorte verbinden" oder Homeoffice". Voraussetzungen:
- Routing/Adressierung (siehe [[routing-grundlagen|Routing]])
- Grundidee Verschluesselung (siehe [[verschluesselung-hash-signatur|Verschluesselung]])

## Definition und Zweck
Ein **VPN** baut einen verschluesselten Tunnel ueber ein unsicheres Netz (meist Internet), um Vertraulichkeit/Integritaet zu gewaehrleisten.

## Typische VPN-Arten
- **Remote-Access VPN**: einzelner Client verbindet sich ins Firmennetz.
- **Site-to-Site VPN**: zwei Netze/Standorte werden dauerhaft verbunden.

## IPsec vs. SSL-VPN (Grundidee)
- **IPsec**: oft auf Netzwerkebene (L3), Site-to-Site typisch.
- **SSL/TLS-VPN**: oft fuer Remote Access, kann webbasiert oder als Client laufen.
In Pruefungen reicht meist: beide verschluesseln, unterscheiden sich in Einsatz und Implementierung.

## Typische Fehler & Stolperfallen
- VPN als Ersatz fuer Firewall sehen (trotz Tunnel braucht es Regeln).
- Adresskonflikte zwischen Standorten ignorieren.
- Routing im Tunnel vergessen (Netze muessen bekannt sein).

## Siehe auch
- [[routing-grundlagen|Routing]]
- [[firewall-dmz-nat|Firewall]]
- [[verschluesselung-hash-signatur|Verschluesselung]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
