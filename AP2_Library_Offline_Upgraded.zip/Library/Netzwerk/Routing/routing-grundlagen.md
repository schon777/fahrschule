---
title: Routing - Default Gateway, Routing-Tabelle, NAT (Ueberblick)
tags:
- netzwerk
- routing
- gateway
- routingtabelle
- nat
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Wiederholung/Stichpunkte.txt
- internal:Unterricht
- internal:Altklausur-implizit
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Routing wird in Pruefungen haeufig in Form von Warum geht Internet nicht?" oder Wie kommen Subnetze zusammen?" abgefragt. Voraussetzungen:
- [[subnetting-ipv4|Subnetting]]
- Unterschied Switch (L2) vs. Router (L3)

## Default Gateway (Kernidee)
Hosts senden alles, was **nicht** im eigenen Subnetz liegt, an das **Default Gateway** (Router). Der Router entscheidet anhand der Routing-Tabelle, wohin das Paket  geht.

## Routing-Tabelle (Prinzip)
Eine Routing-Tabelle enthaelt Eintraege wie:
- Zielnetz (Prefix)
- Next Hop / Interface
- Metrik/Bevorzugung
Wichtiges Prinzip: **Longest Prefix Match** (der spezifischste Eintrag gewinnt).

## NAT (Kurz)
NAT wird oft in Verbindung mit Internetzugang genannt:
- **SNAT/Masquerading**: interne private IPs -> eine oeffentliche IP
- **DNAT/Port Forwarding**: externe Anfragen -> interner Dienst

## Pruefungsnahe Anwendung: typische Pruefungslogik
- IP passt, Ping im eigenen Netz geht, Internet nicht" -> Gateway/DNS/NAT pruefen.
- Zwei VLANs sollen miteinander reden" -> Routing zwischen VLANs (Router-on-a-stick / L3-Switch).

## Typische Fehler & Stolperfallen
- Gateway in falschem Netz.
- Subnetzmaske falsch -> Host denkt Ziel sei lokal und ARPt ins Leere.
- DNS-Probleme als Routingproblem" fehlinterpretieren.

## Checkliste (Kurz)
- IP/Subnetz korrekt?
- Gateway erreichbar?
- Routing-Tabelle vorhanden?
- DNS ok?

## Siehe auch
- [[subnetting-ipv4|Subnetting]]
- [[dhcp-dns|DHCP & DNS]]
- [[vlan-grundlagen-trunk-tagging|VLAN]]
- [[firewall-dmz-nat|Firewall/DMZ/NAT]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
