---
title: IP-Adressierung - IPv4 vs. IPv6 (Grundlagen, typische Aufgaben)
tags:
- netzwerk
- ip
- ipv4
- ipv6
- grundlagen
priority: P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Subnetting/subnetting.pdf
- internal:IT/Ernstmeier/IPv6/ipv6.pdf
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
In AP2 tauchen IP-Aufgaben extrem haeufig auf: Subnetting, Adressplaene, Fehlersuche. Voraussetzungen:
- Binaer/Dezimal-Umrechnung (fuer Subnetting)
- Unterschied Host/Netzanteil (Prefix/Subnetzmaske)

## IPv4 - Kernpunkte
- 32 Bit, meist in 4 Oktetten (z.B. 192.168.10.5)
- Subnetzmaske / Prefix bestimmt Netzgroesse (z.B. /24)
- Private Bereiche (RFC1918) sind in internen Netzen ueblich

## IPv6 - Kernpunkte (pruefungsnah)
- 128 Bit, hexadezimale Schreibweise (z.B. 2001:db8::1)
- Prefixe wie /64 sind Standard fuer viele LANs
- Link-Local (fe80::/10) existiert immer auf Interfaces
- Viele Mechanismen (SLAAC, Neighbor Discovery) ersetzen/ergaenzen IPv4-Konzepte

## Typische AP2-Aufgaben
- IPv4: Netzadresse, Broadcast, Hostbereich, Anzahl Hosts (siehe [[subnetting-ipv4|Subnetting]])
- IPv6: Adressschreibweise kuerzen/expandieren, Prefix interpretieren, Unterschiede erklaeren

## Typische Fehler & Stolperfallen
- IPv6 ::" mehrfach verwenden (nur einmal erlaubt).
- IPv4 /31 /32 Sonderfaelle (nur wenn Aufgabe darauf zielt).
- DNS/Default Gateway vergessen.

## Siehe auch
- [[subnetting-ipv4|Subnetting]]
- [[dhcp-dns|DHCP & DNS]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
