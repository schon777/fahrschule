---
title: Subnetting IPv4 - schnell und pruefungsfest
tags:
- netzwerk
- subnetting
- ipv4
- rechnen
- ap2
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Subnetting/subnetting.pdf
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Subnetting ist ein Klassiker: Adressplan, VLANs, Standortnetze, Fehlersuche. Voraussetzungen:
- Binaerdarstellung von Oktetten (0-255)
- Begriff Prefix/Subnetzmaske

## Standardfragen in AP2
- Netzadresse? Broadcast? Hostbereich?
- Wie viele Hosts passen in ein Netz?
- Wie viele Subnetze entstehen bei neuer Maske?
- Ist IP X in Netz Y?

## Vorgehensmethode (schnell)
1) Prefix bestimmen (z.B. /27)
2) Schrittweite im interessanten Oktett" berechnen  
   Beispiel: /27 -> Maske 255.255.255.224 -> Schrittweite 256-224 = 32
3) Netze laufen in 32er-Schritten: 0, 32, 64, 96, ...
4) Netzadresse = Start, Broadcast = naechster Start - 1
5) Hostbereich = Netz+1 bis Broadcast-1

## Mini-Beispiel
IP: 192.168.10.77/27  
Schrittweite 32 -> Netze: 0-31, 32-63, 64-95, ...  
77 liegt im Netz 64-95  
Netzadresse: 192.168.10.64  
Broadcast: 192.168.10.95  
Hosts: 65-94

## Typische Fehler & Stolperfallen
- Broadcast vergessen (bei IPv4 relevant).
- /24 als Standard" annehmen, obwohl Aufgabe andere Maske hat.
- Schrittweite im falschen Oktett berechnen.

## Checkliste (Kurz)
- Maske/Prefix notieren.
- Schrittweite berechnen.
- Netz/BC/Hosts sauber angeben.

## Siehe auch
- [[routing-grundlagen|Routing]]
- [[vlan-grundlagen-trunk-tagging|VLAN]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)
