---
title: 'Netzwerk-Grundlagen: OSI/TCP-IP, Ethernet, Frames, MAC und ARP'
tags:
- netzwerk
- grundlagen
- osi
- tcpip
- ethernet
- mac
- arp
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Wiederholung/Stichpunkte.txt
- internal:Unterricht
- internal:Altklausur-implizit
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
In AP2 ist Netzwerktechnik oft der Unterbau" fuer konkrete Aufgaben (VLAN, VoIP, VPN, Fehleranalyse). Voraussetzungen:
- IP-Adresse vs. MAC-Adresse
- Unterschied Layer 2 (Switching) vs. Layer 3 (Routing)
- Grundidee Ports/Frames/Packets

## OSI- und TCP/IP-Modell (pruefungsnah)
OSI (7 Schichten) ist ein Denkmodell. In der Praxis reichen meist:
- **Layer 1**: Physik (Kupfer/Fiber, Steckertypen)
- **Layer 2**: Ethernet, MAC, Switching
- **Layer 3**: IP, Routing
- **Layer 4**: TCP/UDP
- **Layer 7**: Anwendungen (HTTP, DNS, SIP ...)

## Ethernet-Grundlagen
- Ethernet uebertraegt Daten in **Frames**.
- Ein Frame enthaelt Quell- und Ziel-**MAC-Adresse** (Layer 2) und typischerweise ein IP-Paket als Nutzlast.

## MAC-Adresse und ARP
- **MAC**: Hardwareadresse, lokal im Layer-2-Segment relevant.
- **ARP**: loest IP -> MAC auf (im selben Broadcast-Domain/VLAN).  
  Beispiel: Host will an 192.168.1.1 senden -> ARP fragt Wer hat 192.168.1.1?" -> erhaelt MAC -> sendet Frame.

## Pruefungsnahe Anwendung: Fehlerbilder (typisch in Pruefungen)
- Falsches VLAN/Broadcast-Domain -> ARP erreicht Ziel nicht.
- Gateway falsch -> Kommunikation nur im eigenen Subnetz.
- Duplex/Speed-Probleme (Layer 1/2) -> Paketverluste.

## Typische Fehler & Stolperfallen
- MAC und IP verwechseln.
- ARP ausserhalb des eigenen Netzes erwarten (ARP ist lokal).
- Switch routet" (ein normaler L2-Switch routet nicht).

## Checkliste (Kurz)
- Ist es ein Layer-2- oder Layer-3-Problem?
- ARP/MAC-Tabelle plausibel?
- Gateway/Subnetz korrekt?

## Siehe auch
- [[switching-mac-table|Switching & MAC-Table]]
- [[routing-grundlagen|Routing]]
- [[subnetting-ipv4|Subnetting]]
- [[vlan-grundlagen-trunk-tagging|VLAN]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
