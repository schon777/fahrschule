---
title: Strukturierte Verkabelung - Patchpanel, Dosen, Kategorien, Pruefungslogik
tags:
- netzwerk
- grundlagen
- verkabelung
- patchpanel
- cat
- fiber
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Wiederholung/Stichpunkte.txt
- internal:IT/Ernstmeier/Wiederholung/Strukturierte Verkabelung.pdf
- internal:Unterricht
- internal:Altklausur-implizit
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Strukturierte Verkabelung ist ein typisches AP2-Thema (Planung, Benennung von Betriebsmitteln, Fehlersuche). Voraussetzungen:
- Unterschied Permanent Link vs. Patchkabel (Grundidee)
- Komponenten im Rack (Patchpanel, Switch, Dose)

## Grundidee
Strukturierte Verkabelung trennt in klar definierte Bestandteile:
- **Kabel** (Verlegekabel, meist massiv)
- **Anschlusspunkte** (Datendosen, Patchpanel)
- **Patchkabel** (flexibel) fuer Verbindungen zu Endgeraeten/Switch

Ziel: standardisierte, wartbare Infrastruktur.

## Kategorien (Kurz)
In Pruefungen reicht oft die Idee: Hoehere Kategorie -> hoehere Bandbreite/Qualitaet (z.B. Cat 5e / 6 / 6A). Wenn die Aufgabe konkrete Werte nennt, danach arbeiten.

## Patchpanel & Beschriftung (pruefungsnah)
- Ports nummerieren, Dosen zuordnen
- Dokumentation: welcher Port gehoert zu welchem Raum/Platz?
- Erdung/Schirmkonzept (siehe [[emv-grundlagen|EMV]] und [[erdung-potentialausgleich|PA]])

## Typische Aufgaben
- Komponenten im Rack benennen
- Patchen nach Plan
- Fehlersuche: falsches Patchkabel, vertauschte Ports, falsches VLAN

## Typische Fehler & Stolperfallen
- Verlegekabel als Patchkabel benutzen (mechanisch ungeeignet).
- Schirmung ohne PA-Konzept.
- Keine Dokumentation/Beschriftung.

## Siehe auch
- [[switching-mac-table|Switching]]
- [[vlan-grundlagen-trunk-tagging|VLAN]]
- [[komponenten-im-verteilerschrank-benennen|Aufgabentyp: Betriebsmittel benennen]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
