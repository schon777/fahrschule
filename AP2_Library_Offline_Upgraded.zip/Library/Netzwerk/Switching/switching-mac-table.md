---
title: Switching - MAC-Adress-Tabelle, Broadcast, STP (Grundidee)
tags:
- netzwerk
- switching
- mac
- broadcast
- stp
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Wiederholung/Stichpunkte.txt
- internal:Unterricht
- internal:Altklausur-implizit
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Switching ist in AP2 oft Voraussetzung fuer VLAN, VoIP und Fehleranalyse. Voraussetzungen:
- [[osi-tcpip-ethernet|Ethernet/MAC/ARP]]
- Begriff Broadcast-Domain"

## MAC-Adress-Tabelle (Learning)
Ein Switch lernt MAC-Adressen dynamisch:
- Kommt ein Frame an Port X mit Quell-MAC A -> Switch merkt sich A -> Port X".
- Bei Ziel-MAC bekannt -> unicast an den passenden Port.
- Ziel unbekannt -> Flooding (an alle Ports im VLAN ausser Eingangsport).

## Broadcast und Unicast (pruefungsnah)
- Broadcast (FF:FF:FF:FF:FF:FF) geht an alle Ports im VLAN.
- Zu viele Broadcasts oder Schleifen koennen das Netz lahmlegen.

## STP (Spanning Tree Protocol) - Grundidee
STP verhindert Layer-2-Schleifen, indem es Ports blockiert und so eine logische Baumstruktur herstellt. In Pruefungen wird oft nur das Konzept gefragt (Warum STP?"), nicht die Details.

## Pruefungsnahe Anwendung: Typische Fehlerbilder
- Loop ohne STP -> Broadcast Storm.
- MAC flapping (MAC-Adresse wandert" zwischen Ports) -> Hinweis auf Loop oder falsches Patchen.
- Falsche Portkonfiguration (Access/Trunk) -> VLAN-Probleme.

## Typische Fehler & Stolperfallen
- Denken, ein Switch trennt Broadcasts (tut er nicht ohne VLAN).
- STP mit Routing verwechseln.

## Siehe auch
- [[vlan-grundlagen-trunk-tagging|VLAN]]
- [[strukturierte-verkabelung|Strukturierte Verkabelung]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
