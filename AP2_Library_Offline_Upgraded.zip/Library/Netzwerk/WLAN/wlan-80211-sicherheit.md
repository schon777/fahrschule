---
title: WLAN - 802.11 Grundlagen, Sicherheit (WPA2/WPA3), Planung
tags:
- netzwerk
- wlan
- '80211'
- wpa2
- wpa3
- sicherheit
- planung
priority: P2
exam_relevance: mittel
sources:
- internal:IT/Ernstmeier/Wiederholung/Stichpunkte.txt
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
WLAN wird in AP2 haeufig ueber Planung/Fehlersuche abgefragt: Warum schlechter Empfang?", Welche Verschluesselung?". Voraussetzungen:
- Funk ist geteiltes Medium (Kollisionen/CSMA/CA als Grundidee)
- IP-Adressierung (siehe [[ip-adressierung-v4-v6|IP]])

## Grundlagen (kurz)
WLAN nutzt 2,4 GHz und 5 GHz (und je nach Standard weitere Baender). Typische Aspekte:
- Kanalplanung (Ueberlappung vermeiden)
- Sendeleistung/Abdeckung
- Roaming (mehrere APs)

## Sicherheit
- **WPA2-Personal (PSK)**: haeufig in kleinen Netzen.
- **WPA2/WPA3-Enterprise (802.1X)**: zentrale Authentisierung (RADIUS).
Merksatz: *Fuer Unternehmen ist 802.1X/Enterprise oft die saubere" Loesung.*

## Pruefungsnahe Anwendung: typische Fehlerbilder
- falsches Passwort/Key
- DHCP-Probleme im WLAN
- Kanalueberlappung/Interferenzen
- falsches VLAN/SSID-Zuordnung

## Typische Fehler & Stolperfallen
- WEP nennen (veraltet/unsicher).
- MAC-Filter ist sicher" - ist nur schwache Zusatzmassnahme.
- Funkabdeckung ohne Site-Survey raten".

## Siehe auch
- [[dhcp-dns|DHCP]]
- [[vlan-grundlagen-trunk-tagging|VLAN]]


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
