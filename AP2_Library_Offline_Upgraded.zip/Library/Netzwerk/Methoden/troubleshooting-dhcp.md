---
title: Troubleshooting DHCP
tags:
- netzwerk
- methode
- dhcp
- troubleshooting
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: methode
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
DHCP verteilt IP-Konfiguration. Fehler zeigen sich als: keine IP, APIPA/169.254.x.x, falsches Gateway, kein DNS.

## Pruefungsnahe Anwendung
Eingrenzung nach Layer:
L1: Link/Port
L2: VLAN/Trunk
L3: DHCP Relay/Gateway
Dienst: DHCP-Server/Scope

## Typische Fehler & Stolperfallen
- Client im falschen VLAN.
- DHCP-Server erreichbar, aber Scope leer/disabled.
- DHCP Relay fehlt bei getrennten VLANs.

## Mini-Beispiel
Client bekommt 169.254.x.x -> pruefe Link, VLAN, dann DHCP-Server/Relay.

## Schrittfolge
1) Link am Client (LED, Speed/Duplex)
2) IP am Client (keine/169.254/falsch?)
3) VLAN/Portkonfig (Access VLAN korrekt?)
4) DHCP-Server erreichbar? (Ping/Route)
5) Scope/Lease Pool ok?
6) Relay (ip helper) wenn Server in anderem VLAN
7) Test: neue Lease anfordern
