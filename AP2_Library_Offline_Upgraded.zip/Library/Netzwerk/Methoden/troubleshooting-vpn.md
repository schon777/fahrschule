---
title: Troubleshooting VPN
tags:
- netzwerk
- methode
- vpn
- troubleshooting
priority: P2
exam_relevance: mittel
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: methode
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
VPN-Probleme sind oft: Tunnel steht, aber kein Zugriff; oder Auth scheitert; oder Routing/Firewall blockt.

## Pruefungsnahe Anwendung
Arbeite in Ebenen: Tunnelaufbau -> IP-Parameter -> Routing -> Policies -> Dienste.

## Typische Fehler & Stolperfallen
- "VPN connected" wird mit "Zugriff funktioniert" gleichgesetzt.
- Ueberlappende Subnetze auf beiden Seiten.

## Mini-Beispiel
Tunnel up, aber kein Zugriff: pruefe Routen und Firewall-Regeln.

## Schrittfolge
1) Tunnelstatus/Logs (Handshake, Auth)
2) IP/Subnetze (keine Overlaps)
3) Routing: Routen auf beiden Seiten vorhanden?
4) Firewall/ACL: Verkehr erlaubt (richtige Richtungen)
5) DNS im VPN: Namensaufloesung ggf. split DNS
6) Test: Ping IP, dann Dienstport (z.B. TCP)
