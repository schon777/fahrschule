---
title: Checkliste VLAN-Plan
tags:
- netzwerk
- methode
- vlan
- checkliste
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: methode
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
VLANs trennen Broadcast-Domaenen (Layer 2). In AP2 geht es oft um Abteilungen, Sicherheit, VoIP, WLAN.

## Pruefungsnahe Anwendung
Arbeite die Checkliste durch und dokumentiere das Ergebnis als VLAN-Plan + Adressplan.

## Typische Fehler & Stolperfallen
- VLAN und IP-Subnetz werden nicht sauber zugeordnet.
- Trunks fehlen oder erlauben falsche VLANs.

## Mini-Beispiel
VLAN 10 Office, VLAN 20 VoIP, VLAN 30 Guest. Trunk zum AP: erlaubt 20,30; Access-Port PC: VLAN10.

## Checkliste
1) Anforderungen sammeln (Abteilungen, Dienste, Sicherheitszonen)
2) VLAN-Liste (ID, Name, Zweck)
3) Pro VLAN: Subnetz, Gateway, DHCP, DNS
4) Switchports: Access vs Trunk, Allowed VLANs
5) Inter-VLAN Routing (wo? Router/L3-Switch)
6) Sicherheitsregeln (ACL/Firewall)
7) Tests: DHCP, Ping GW, DNS, Zugriff zwischen VLANs
