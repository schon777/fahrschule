---
title: Troubleshooting DNS
tags:
- netzwerk
- methode
- dns
- troubleshooting
priority: P1
exam_relevance: hoch
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: methode
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
DNS ist Namensaufloesung. Fehler: Namen gehen nicht, IP geht schon; oder bestimmte Domains nicht.

## Pruefungsnahe Anwendung
Trenne "Netz ok" von "DNS kaputt": Teste erst IP-Konnektivitaet, dann Resolver.

## Typische Fehler & Stolperfallen
- DNS und Internetzugang werden gleichgesetzt.
- Client nutzt falschen DNS (DHCP falsch / manuell gesetzt).

## Mini-Beispiel
Ping 8.8.8.8 ok, ping example.com fail -> DNS Problem.

## Schrittfolge
1) IP-Konnektivitaet testen (Ping Gateway, Ping externe IP)
2) DNS-Server IP pruefen (DHCP Option, manuell)
3) Resolver-Test (nslookup/dig)
4) Weiterleitung/Forwarder, Zonen, Cache pruefen
5) Firewall/ACL fuer DNS (UDP/TCP 53) pruefen
