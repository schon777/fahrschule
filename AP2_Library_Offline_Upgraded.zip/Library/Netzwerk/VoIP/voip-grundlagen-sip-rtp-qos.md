---
title: VoIP - SIP, RTP, Codecs, QoS, Latenz/Jitter (AP2)
tags:
- netzwerk
- voip
- sip
- rtp
- qos
- codecs
- latenz
- jitter
- mos
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/VoIP/Leitfragen.txt
- internal:IT/Ernstmeier/VoIP/Aufgaben VoIP_neu_Logo.pdf
- internal:IT/Ernstmeier/VoIP/VoIP_neu (1).pptx
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
VoIP ist ein haeufiges AP2-Thema (auch in Wiederholungslisten). Voraussetzungen:
- [[osi-tcpip-ethernet|TCP/UDP-Grundlagen]]
- [[vlan-grundlagen-trunk-tagging|VLAN]] (Voice-VLAN)
- Grundidee QoS (Priorisierung)

## Bausteine einer VoIP-Verbindung
- **Signalisierung**: baut Gespraeche auf/ab (typisch **SIP**).
- **Medienuebertragung**: transportiert die Sprache (typisch **RTP** ueber UDP).
Merksatz: *SIP spricht ueber das Gespraech, RTP transportiert die Sprache.*

## Sprache digitalisieren (Kurz)
Analogsignal -> Abtastung/Quantisierung -> Codec komprimiert (z.B. G.711, G.729, Opus - je nach Kontext). Wichtig ist: Codec beeinflusst Bandbreite und Qualitaet.

## Qualitaet: Latenz, Jitter, Paketverlust
- **Latenz**: Verzoegerung; zu hoch -> Echo/Versatz".
- **Jitter**: Schwankung der Verzoegerung; wird mit **Jitter-Buffer** abgefangen.
- Paketverlust wirkt sofort hoerbar.

Messgroesse: **MOS** (Mean Opinion Score) - Qualitaetsbewertung (Grundidee reicht meist).

## QoS in AP2 (praktisch)
- Voice-Traffic priorisieren (VLAN/QoS)
- genuegend Bandbreite
- stabile Switching/Routing-Konfiguration

## Typische Fehler & Stolperfallen
- SIP und RTP verwechseln.
- TCP fuer RTP annehmen" (RTP laeuft typischerweise ueber UDP).
- QoS ignorieren, obwohl Aufgabe nach Sprachqualitaet fragt.

## Checkliste (Kurz)
- Signalisierung (SIP) ok?
- RTP-Ports/UDP ok?
- VLAN/QoS korrekt?
- Latenz/Jitter im Rahmen?

## Siehe auch
- [[vlan-grundlagen-trunk-tagging|VLAN]]
- [[poe-standards-8023af-at-bt|PoE]]
- [[firewall-dmz-nat|Firewall/Ports]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
