---
title: Firewall-Techniken, DMZ und NAT - pruefungsnaher Ueberblick
tags:
- netzwerk
- sicherheit
- firewall
- dmz
- nat
- spi
- dpi
priority: P1+P2
exam_relevance: hoch
sources:
- internal:IT/Ernstmeier/Firewalltechnicken/Inhalt.txt
- internal:IT/Ernstmeier/Firewalltechnicken/Firewalls.pdf
- internal:Unterricht
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: netzwerk
---
## Kontext & Grundlagen (Voraussetzungen)
Firewalls werden in AP2 oft ueber Konzepte (DMZ) und Filterarten (Paketfilter, Stateful) abgefragt. Voraussetzungen:
- TCP/UDP-Ports
- Routing/NAT-Grundlagen (siehe [[routing-grundlagen|Routing]])

## Firewall-Grundidee
Eine Firewall kontrolliert Verkehr anhand von Regeln (Quell/Ziel-IP, Port, Protokoll, Zustand). Ziel:
- Angriffsflaeche reduzieren
- Segmente trennen
- Protokollzugriff steuern

## Typische Firewall-Techniken (Kurz)
- **Paketfilter**: filtert nach Headerdaten (IP/Port/Protokoll).
- **Stateful Packet Inspection (SPI)**: merkt sich Verbindungszustaende und laesst passende Rueckpakete zu.
- **Application Layer Gateway / Proxy**: versteht Anwendungen (Layer 7) besser.
- **Deep Packet Inspection (DPI)**: analysiert Inhalte tiefer (je nach System).

## DMZ (Demilitarized Zone)
Eine **DMZ** ist ein Zwischen-Netz fuer oeffentlich erreichbare Dienste (Web, Mail), getrennt vom internen LAN. Ziel: Kompromittierung begrenzen.

## NAT (Ueberblick)
- **SNAT/Masquerading**: interne Adressen nach aussen.
- **DNAT/Port Forwarding**: externe Anfragen zu internem Server.

## Typische Fehler & Stolperfallen
- DMZ mit einfacher Portfreigabe" gleichsetzen.
- NAT = Sicherheit" - NAT ist Adressumsetzung; Sicherheit kommt durch Regeln.
- Ports vergessen (z.B. SIP/RTP bei VoIP - siehe [[voip-grundlagen-sip-rtp-qos|VoIP]]).

## Siehe auch
- [[routing-grundlagen|Routing]]
- [[vpn-grundlagen-ipsec-ssl|VPN]]
- [[voip-grundlagen-sip-rtp-qos|VoIP]]


## Pruefungsnahe Anwendung
- (Ergaenzen: kurz und pruefungsnah)


## Mini-Beispiel
- (Ergaenzen: kurz und pruefungsnah)
