---
title: Gaps README
tags:
- gaps
- quality
priority: P2
exam_relevance: mittel
sources:
- internal:generated
last_updated: '2026-02-19'
confidence: medium
license: internal
type: note
topic_area: pruefung
---
## Kontext & Grundlagen (Voraussetzungen)
Gaps sind bewusst dokumentierte Wissensluecken oder unsichere Stellen.

## Pruefungsnahe Anwendung
Wenn beim Loesen einer Aufgabe ein Begriff fehlt: erst Gap Note erstellen, dann spaeter gezielt nacharbeiten.

## Typische Fehler & Stolperfallen
- Luecke wird ignoriert und durch Raten ersetzt.
- Gap wird nicht mit Tags versehen und ist spaeter nicht auffindbar.

## Mini-Beispiel
Wenn "NYCWY" auftaucht und unklar: Gap Note anlegen mit Kontext der Aufgabe.

## Vorgehen
- gap-<slug>.md erstellen
- Kontext der Frage, warum relevant, was genau fehlt
- moegliche Quellen (Metadaten)
