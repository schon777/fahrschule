# REPORT (AP2 Library Upgrade)

Date: 2026-02-19
Scope: Upgrade of AP2_Library_Offline.zip + Excel sync (AP2_Lernliste.xlsx)

## Top changes
- Normalized ALL Markdown files: unified YAML (title/tags/priority/exam_relevance/sources/last_updated/confidence/license/type/topic_area) and required sections.
- Added Bezeichnungen lexikon (cable/network/LWL/abbreviations) for random exam terms.
- Added templates for troubleshooting and documentation.
- Added Netzwerk method cards (VLAN plan + DHCP/DNS/VPN troubleshooting).
- Added Questionbank (Mehrfachangabe): 90 questions (30 Netzwerk, 30 Elektrotechnik, 30 IT-Systeme).
- Updated Excel: Lernliste expanded + new sheets (Questionbank, Glossar, Aliases_Mapping, Dashboard) + Inventar mapping.

## Counts
- Markdown total: 181
- Lernliste entries (notes/index/templates/lexikon/methoden + QB README): 91
- Questionbank questions: 90
- Glossar entries: 31

## Gaps / low-confidence
- Newly generated lexikon/method/question content uses internal:generated as source and confidence=medium.
- If you want higher confidence: add licensed external sources (e.g., Wikipedia CC BY-SA) and map them in /Library/_external/.

## Files added (high level)
- /Library/Bezeichnungen/ (lexikon)
- /Library/_templates/ (answer/document templates)
- /Library/Netzwerk/Methoden/ (checklists/troubleshooting)
- /Library/_questionbank/ (questions)
- /Library/_external/ (license-safe reference maps)
- /Library/_gaps/ (gap workflow)

## Notes
- All Markdown content is ASCII-only.
- Multiple-choice: options are neutral; answers are in Klartext under "Loesung".
